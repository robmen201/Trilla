"use client"
import { TrillaSearchPage } from "@/components/trilla-search-page"

export default function Home() {
  return <TrillaSearchPage />
}
