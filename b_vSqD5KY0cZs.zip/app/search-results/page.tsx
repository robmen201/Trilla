"use client"

import { Suspense, useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { RealTimeFlightResults } from "@/components/real-time-flight-results"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { ArrowLeftRight, Search, ChevronDown, User, Clock, BarChart3, Sparkles } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// City options for From and To
const fromCities = [
  { code: "JFK", name: "New York", airport: "John F. Kennedy Intl" },
  { code: "LAX", name: "Los Angeles", airport: "Los Angeles Intl" },
  { code: "MIA", name: "Miami", airport: "Miami Intl" },
  { code: "ORD", name: "Chicago", airport: "O'Hare Intl" },
]

const toCities = [
  { code: "LHR", name: "London", airport: "Heathrow" },
  { code: "CDG", name: "Paris", airport: "Charles de Gaulle" },
  { code: "NRT", name: "Tokyo", airport: "Narita Intl" },
  { code: "SYD", name: "Sydney", airport: "Kingsford Smith" },
]

// Loyalty programs data
const loyaltyPrograms = [
  {
    id: "united",
    name: "MileagePlus Gold",
    airline: "United Airlines",
    status: "Gold",
    color: "bg-blue-600",
    progress: { current: 35000, needed: 15000, total: 50000 },
  },
  {
    id: "american",
    name: "AAdvantage Platinum",
    airline: "American Airlines",
    status: "Platinum",
    color: "bg-red-600",
    progress: { current: 75000, needed: 0, total: 75000 },
  },
  {
    id: "delta",
    name: "SkyMiles Silver",
    airline: "Delta Air Lines",
    status: "Silver",
    color: "bg-red-500",
    progress: { current: 25000, needed: 25000, total: 50000 },
  },
  {
    id: "alaska",
    name: "Mileage Plan MVP",
    airline: "Alaska Airlines",
    status: "MVP",
    color: "bg-green-600",
    progress: { current: 40000, needed: 35000, total: 75000 },
  },
]

function SearchResultsContent() {
  const searchParams = useSearchParams()
  const router = useRouter()

  // Search state - start completely empty
  const [fromCity, setFromCity] = useState("")
  const [toCity, setToCity] = useState("")
  const [departDate, setDepartDate] = useState<Date>()
  const [returnDate, setReturnDate] = useState<Date>()
  const [passengers, setPassengers] = useState("1")
  const [travelClass, setTravelClass] = useState("ECONOMY")
  const [selectedLoyalty, setSelectedLoyalty] = useState(loyaltyPrograms[0])
  const [isLoyaltyOpen, setIsLoyaltyOpen] = useState(false)

  // Initialize from URL params - only if they match our available cities
  useEffect(() => {
    const origin = searchParams.get("origin")
    const destination = searchParams.get("destination")
    const departure = searchParams.get("departureDate")
    const returnD = searchParams.get("returnDate")
    const adults = searchParams.get("adults")
    const tClass = searchParams.get("travelClass")

    // Only set if the cities exist in our predefined lists
    if (origin && fromCities.some((city) => city.code === origin)) setFromCity(origin)
    if (destination && toCities.some((city) => city.code === destination)) setToCity(destination)
    if (departure) setDepartDate(new Date(departure))
    if (returnD) setReturnDate(new Date(returnD))
    if (adults) setPassengers(adults)
    if (tClass) setTravelClass(tClass)
  }, [])

  const handleSearch = () => {
    if (!fromCity || !toCity || !departDate) return

    const params = new URLSearchParams({
      origin: fromCity,
      destination: toCity,
      departureDate: format(departDate, "yyyy-MM-dd"),
      adults: passengers,
      travelClass,
    })

    if (returnDate) {
      params.append("returnDate", format(returnDate, "yyyy-MM-dd"))
    }

    router.push(`/search-results?${params.toString()}`)
  }

  const getFromCityDisplay = () => {
    const city = fromCities.find((c) => c.code === fromCity)
    return city ? `${city.name} (${city.code})` : ""
  }

  const getToCityDisplay = () => {
    const city = toCities.find((c) => c.code === toCity)
    return city ? `${city.name} (${city.code})` : ""
  }

  const currentSearchParams = {
    origin: fromCity,
    destination: toCity,
    departureDate: departDate ? format(departDate, "yyyy-MM-dd") : "",
    returnDate: returnDate ? format(returnDate, "yyyy-MM-dd") : undefined,
    adults: Number.parseInt(passengers),
    travelClass,
  }

  return (
    <main className="min-h-screen bg-gray-50">
      {/* Ultra Compact Header - 50% Smaller */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 py-2">
          <div className="flex items-center justify-between">
            {/* Left: Logo */}
            <div className="flex items-center space-x-1">
              <Link href="/" className="flex items-center space-x-1">
                <span className="text-lg font-bold text-teal-500">TRILLA</span>
              </Link>
              <BarChart3 className="h-3 w-3 text-teal-400" />
              <Sparkles className="h-3 w-3 text-teal-400" />
            </div>

            {/* Center: Ultra Compact Search Form */}
            <div className="flex-1 max-w-xl mx-4">
              {/* Mini Trip Type Tabs */}
              <div className="flex space-x-4 mb-1">
                <button className="text-teal-600 border-b border-teal-500 pb-0.5 text-xs font-medium">
                  Round Trip
                </button>
                <button className="text-gray-500 hover:text-gray-700 text-xs">One Way</button>
                <button className="text-gray-500 hover:text-gray-700 text-xs">Multi City</button>
                <button className="text-gray-500 hover:text-gray-700 text-xs">Rewards</button>
              </div>

              {/* Mini Search Form */}
              <div className="border border-teal-300 rounded-md p-2 bg-white">
                <div className="flex items-center space-x-2">
                  {/* From */}
                  <div className="flex-1 min-w-0">
                    <div className="text-xs text-gray-500 mb-0.5">From</div>
                    <Select value={fromCity} onValueChange={setFromCity}>
                      <SelectTrigger className="border-0 p-0 h-auto shadow-none">
                        <div className="flex items-center justify-between w-full">
                          <span className="text-xs font-medium text-gray-900 truncate">
                            {getFromCityDisplay() || "Select city"}
                          </span>
                          <ChevronDown className="h-2.5 w-2.5 text-gray-400 flex-shrink-0 ml-1" />
                        </div>
                      </SelectTrigger>
                      <SelectContent>
                        {fromCities.map((city) => (
                          <SelectItem key={city.code} value={city.code}>
                            <div>
                              <div className="font-medium text-sm">
                                {city.name} ({city.code})
                              </div>
                              <div className="text-xs text-gray-500">{city.airport}</div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Swap */}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-4 w-4 p-0 hover:bg-teal-50"
                    onClick={() => {
                      const temp = fromCity
                      setFromCity(toCity)
                      setToCity(temp)
                    }}
                  >
                    <ArrowLeftRight className="h-2.5 w-2.5 text-teal-500" />
                  </Button>

                  {/* To */}
                  <div className="flex-1 min-w-0">
                    <div className="text-xs text-gray-500 mb-0.5">To</div>
                    <Select value={toCity} onValueChange={setToCity}>
                      <SelectTrigger className="border-0 p-0 h-auto shadow-none">
                        <div className="flex items-center justify-between w-full">
                          <span className="text-xs font-medium text-gray-900 truncate">
                            {getToCityDisplay() || "Select city"}
                          </span>
                          <ChevronDown className="h-2.5 w-2.5 text-gray-400 flex-shrink-0 ml-1" />
                        </div>
                      </SelectTrigger>
                      <SelectContent>
                        {toCities.map((city) => (
                          <SelectItem key={city.code} value={city.code}>
                            <div>
                              <div className="font-medium text-sm">
                                {city.name} ({city.code})
                              </div>
                              <div className="text-xs text-gray-500">{city.airport}</div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Dates */}
                  <div className="flex-1 min-w-0">
                    <div className="text-xs text-gray-500 mb-0.5">Departure Dates</div>
                    <div className="flex items-center space-x-1">
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="ghost"
                            className="p-0 h-auto text-xs font-medium text-gray-900 hover:bg-transparent"
                          >
                            {departDate ? format(departDate, "MMM dd, yyyy") : "Select"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={departDate}
                            onSelect={setDepartDate}
                            initialFocus
                            disabled={(date) => date < new Date()}
                          />
                        </PopoverContent>
                      </Popover>
                      <span className="text-gray-400 text-xs">-</span>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="ghost"
                            className="p-0 h-auto text-xs font-medium text-gray-900 hover:bg-transparent"
                          >
                            {returnDate ? format(returnDate, "MMM dd, yyyy") : "Select"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={returnDate}
                            onSelect={setReturnDate}
                            initialFocus
                            disabled={(date) => date < (departDate || new Date())}
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>

                  {/* Search Button */}
                  <Button
                    onClick={handleSearch}
                    className="bg-teal-500 hover:bg-teal-600 text-white rounded-full h-6 w-6 p-0"
                    disabled={!fromCity || !toCity || !departDate}
                  >
                    <Search className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Right: Mini Controls */}
            <div className="flex items-center space-x-2">
              <Select value={travelClass} onValueChange={setTravelClass}>
                <SelectTrigger className="border-0 shadow-none h-auto p-0">
                  <div className="flex items-center space-x-1">
                    <span className="text-xs text-gray-700 font-medium">{travelClass}</span>
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ECONOMY">Economy</SelectItem>
                  <SelectItem value="PREMIUM_ECONOMY">Premium Economy</SelectItem>
                  <SelectItem value="BUSINESS">Business</SelectItem>
                  <SelectItem value="FIRST">First</SelectItem>
                </SelectContent>
              </Select>

              <Select value={passengers} onValueChange={setPassengers}>
                <SelectTrigger className="border-0 shadow-none h-auto p-0">
                  <div className="flex items-center space-x-1">
                    <span className="text-xs text-gray-700 font-medium">{passengers} Traveler</span>
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Traveler</SelectItem>
                  <SelectItem value="2">2 Travelers</SelectItem>
                  <SelectItem value="3">3 Travelers</SelectItem>
                  <SelectItem value="4">4 Travelers</SelectItem>
                </SelectContent>
              </Select>

              <Link href="/dashboard">
                <Button className="bg-teal-500 hover:bg-teal-600 text-white rounded-full px-3 py-2 h-8">
                  <User className="h-3 w-3 mr-1" />
                  <div className="text-xs">
                    <div className="font-medium">Hi Nathan</div>
                    <div className="text-xs opacity-90">My Wallet</div>
                  </div>
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 py-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Popover open={isLoyaltyOpen} onOpenChange={setIsLoyaltyOpen}>
                <PopoverTrigger asChild>
                  <Button variant="ghost" className="p-0 h-auto">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{selectedLoyalty.name}</div>
                      <div className="text-sm text-red-500 font-medium">
                        Next status: {selectedLoyalty.progress.needed.toLocaleString()} miles
                      </div>
                    </div>
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80 p-3" align="start">
                  <div className="space-y-2">
                    <div className="text-sm font-medium mb-2">Select Loyalty Program</div>
                    {loyaltyPrograms.map((program) => (
                      <div
                        key={program.id}
                        className={`p-2 rounded-md border cursor-pointer transition-all ${
                          selectedLoyalty.id === program.id
                            ? "border-teal-500 bg-teal-50"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                        onClick={() => {
                          setSelectedLoyalty(program)
                          setIsLoyaltyOpen(false)
                        }}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${program.color}`}></div>
                            <span className="font-medium text-xs">{program.name}</span>
                          </div>
                          <Badge variant="outline" className="text-xs h-4">
                            {program.status}
                          </Badge>
                        </div>
                        <div className="text-xs text-gray-600 mb-1">{program.airline}</div>
                        <div className="w-full bg-gray-200 rounded-full h-1">
                          <div
                            className={`h-1 rounded-full ${program.color}`}
                            style={{ width: `${(program.progress.current / program.progress.total) * 100}%` }}
                          ></div>
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          {program.progress.current.toLocaleString()} / {program.progress.total.toLocaleString()} miles
                        </div>
                      </div>
                    ))}
                    <Button variant="outline" className="w-full text-xs h-7 bg-transparent">
                      + Add New Program
                    </Button>
                  </div>
                </PopoverContent>
              </Popover>
            </div>

            <div className="flex items-center space-x-6">
              <div className="text-center">
                <div className="text-sm text-gray-500">Lowest Price</div>
                <div className="text-xl font-bold text-gray-900">$760</div>
              </div>

              <div className="text-center bg-teal-50 px-4 py-2 rounded-lg border-2 border-teal-400">
                <div className="text-sm text-teal-700 font-medium">Most Miles</div>
                <div className="text-xl font-bold text-teal-700">3,458</div>
              </div>

              <div className="text-center">
                <div className="text-sm text-gray-500">Starting from</div>
                <div className="text-xl font-bold text-gray-400">60,000</div>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">Price (Lowest)</span>
                <ChevronDown className="h-4 w-4 text-gray-400" />
              </div>
              <Button variant="outline" size="sm" className="text-gray-600 bg-transparent">
                More Filters
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Results Content */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        {fromCity && toCity && departDate ? (
          <RealTimeFlightResults searchParams={currentSearchParams} />
        ) : (
          <Card>
            <CardContent className="p-8 text-center">
              <div className="h-12 w-12 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="h-6 w-6 text-teal-600" />
              </div>
              <h3 className="text-lg font-medium mb-2">Ready to Search</h3>
              <p className="text-gray-600 mb-4">
                Select your departure city, destination, and travel dates to find the best flights.
              </p>
              <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
                <Clock className="h-4 w-4" />
                <span>Real-time prices and award availability</span>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </main>
  )
}

export default function SearchResultsPage() {
  return (
    <Suspense fallback={<div>Loading search results...</div>}>
      <SearchResultsContent />
    </Suspense>
  )
}
