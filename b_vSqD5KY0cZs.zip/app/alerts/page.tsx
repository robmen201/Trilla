import { PriceAlerts } from "@/components/price-alerts"
import { FlightTrackingSetup } from "@/components/flight-tracking-setup"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Bell } from "lucide-react"
import Link from "next/link"

export default function AlertsPage() {
  return (
    <main className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/search-results">
          <Button variant="ghost" className="pl-0">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Results
          </Button>
        </Link>
        <div className="flex items-center gap-2 mt-2">
          <h1 className="text-3xl font-bold">Smart Alerts</h1>
          <Bell className="h-6 w-6 text-primary" />
        </div>
        <p className="text-muted-foreground">Get notified when better deals become available for your flights</p>
      </div>

      <Tabs defaultValue="alerts" className="space-y-6">
        <TabsList>
          <TabsTrigger value="alerts">Current Alerts</TabsTrigger>
          <TabsTrigger value="tracking">Flight Tracking</TabsTrigger>
        </TabsList>

        <TabsContent value="alerts">
          <PriceAlerts />
        </TabsContent>

        <TabsContent value="tracking">
          <FlightTrackingSetup />
        </TabsContent>
      </Tabs>
    </main>
  )
}
