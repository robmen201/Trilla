"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Plane, Sparkles, TrendingUp, CreditCard } from "lucide-react"
import Link from "next/link"
import { PaymentOptions, creditCards } from "@/components/payment-options"
import { RedemptionGuide } from "@/components/redemption-guide"
import { useSearchParams } from "next/navigation"
import { useState, useEffect } from "react"

export default function CheckoutPage({ params }: { params: { id: string } }) {
  const flightId = params.id
  const searchParams = useSearchParams()
  const paymentMethod = searchParams.get("method") || "cash"
  const [activeTab, setActiveTab] = useState(paymentMethod)
  const [selectedCard, setSelectedCard] = useState("chase")

  // Sync tab with URL parameter
  useEffect(() => {
    setActiveTab(paymentMethod)
  }, [paymentMethod])

  // Build the back URL with search parameters
  const buildBackUrl = () => {
    const backParams = new URLSearchParams({
      origin: "JFK",
      destination: "LHR",
      departureDate: "2024-06-25",
      returnDate: "2024-07-05",
      adults: "1",
      travelClass: "BUSINESS",
    })
    return `/search-results?${backParams.toString()}`
  }

  // Updated flight data to match search results exactly - ONLY CHANGED THE MILES AMOUNTS
  const getFlightData = (id: string) => {
    const flights = {
      "1": {
        airline: "Lufthansa",
        alliance: "Star Alliance",
        cabins: {
          business: { milesPrice: 55000, price: 3200 },
        },
      },
      "2": {
        airline: "British Airways",
        alliance: "Oneworld Alliance",
        cabins: {
          business: { milesPrice: 60000, price: 3200 },
        },
      },
      "3": {
        airline: "Virgin Atlantic",
        alliance: "SkyTeam Alliance",
        cabins: {
          business: { milesPrice: 55000, price: 3200 },
        },
      },
    }
    return flights[id] || flights["1"]
  }

  const flightData = getFlightData(flightId)
  const cabinData = flightData.cabins.business

  // Get selected card data
  const selectedCardData = creditCards.find((card) => card.id === selectedCard) || creditCards[0]

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href={buildBackUrl()}>
            <Button variant="ghost" className="pl-0">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Results
            </Button>
          </Link>
          <h1 className="text-3xl font-bold mt-2">Complete Your Booking</h1>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Left side - Payment Options */}
          <div className="flex-1 lg:w-2/3">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="w-full">
                <TabsTrigger value="cash" className="flex-1">
                  Pay with Cash
                </TabsTrigger>
                <TabsTrigger value="miles" className="flex-1">
                  Pay with Miles/Points
                </TabsTrigger>
              </TabsList>
              <TabsContent value="cash">
                <Card>
                  <CardHeader>
                    <CardTitle>Payment Options</CardTitle>
                    <CardDescription>Choose the best card for maximum rewards</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <PaymentOptions selectedCard={selectedCard} onCardChange={setSelectedCard} />
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="miles">
                <Card>
                  <CardHeader>
                    <CardTitle>Miles/Points Redemption</CardTitle>
                    <CardDescription>Complete your award booking</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <RedemptionGuide />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Right side - Booking Summary */}
          <div className="lg:w-1/3">
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle>Booking Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3 pb-4 border-b">
                  <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                    <Plane className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="font-medium">{flightData.airline}</div>
                    <div className="text-sm text-muted-foreground">{flightData.alliance}</div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Outbound Flight</h3>
                  <div className="grid grid-cols-3 gap-2 text-sm">
                    <div>
                      <div className="font-medium">8:30 AM</div>
                      <div className="text-muted-foreground">Jun 25</div>
                      <div>JFK</div>
                    </div>
                    <div className="flex flex-col items-center justify-center">
                      <div className="text-xs text-muted-foreground">7h 15m</div>
                      <div className="relative w-full">
                        <div className="border-t border-dashed border-gray-300 absolute w-full top-1/2"></div>
                        <Plane className="h-3 w-3 absolute right-0 top-1/2 -translate-y-1/2" />
                      </div>
                      <div className="text-xs text-muted-foreground">Nonstop</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">10:45 PM</div>
                      <div className="text-muted-foreground">Jun 25</div>
                      <div>LHR</div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Return Flight</h3>
                  <div className="grid grid-cols-3 gap-2 text-sm">
                    <div>
                      <div className="font-medium">11:30 AM</div>
                      <div className="text-muted-foreground">Jul 5</div>
                      <div>LHR</div>
                    </div>
                    <div className="flex flex-col items-center justify-center">
                      <div className="text-xs text-muted-foreground">8h 10m</div>
                      <div className="relative w-full">
                        <div className="border-t border-dashed border-gray-300 absolute w-full top-1/2"></div>
                        <Plane className="h-3 w-3 absolute right-0 top-1/2 -translate-y-1/2" />
                      </div>
                      <div className="text-xs text-muted-foreground">Nonstop</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">2:40 PM</div>
                      <div className="text-muted-foreground">Jul 5</div>
                      <div>JFK</div>
                    </div>
                  </div>
                </div>

                {activeTab === "miles" ? (
                  <div className="pt-4 border-t">
                    <div className="flex justify-between font-bold text-lg">
                      <span>Total Miles Needed</span>
                      <span>{cabinData.milesPrice.toLocaleString()} miles</span>
                    </div>
                    <div className="text-sm text-muted-foreground text-right">+ $5.60 taxes</div>
                  </div>
                ) : (
                  <div className="pt-4 border-t">
                    <div className="flex justify-between mb-2">
                      <span>Base fare</span>
                      <span>${cabinData.price}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span>Taxes & fees</span>
                      <span>$100.00</span>
                    </div>
                    <div className="flex justify-between font-bold text-lg pt-2 border-t mt-2">
                      <span>Total</span>
                      <span>${cabinData.price + 100}</span>
                    </div>
                  </div>
                )}

                <div className="text-sm text-muted-foreground text-right">
                  or {cabinData.milesPrice.toLocaleString()} miles + $5.60
                </div>

                {/* Only show Miles & Points earning for CASH bookings */}
                {activeTab === "cash" && (
                  <div className="mt-4 pt-4 border-t bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-4">
                    <h3 className="font-medium mb-3 flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-primary" />
                      Miles & Points You'll Earn
                    </h3>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                            <Plane className="h-3 w-3 text-blue-600" />
                          </div>
                          <div>
                            <div className="text-sm font-medium">British Airways Avios</div>
                            <div className="text-xs text-muted-foreground">Base + Gold status bonus</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-blue-600">10,374</div>
                          <div className="text-xs text-muted-foreground">miles</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center">
                            <CreditCard className="h-3 w-3 text-purple-600" />
                          </div>
                          <div>
                            <div className="text-sm font-medium">{selectedCardData.pointsName}</div>
                            <div className="text-xs text-muted-foreground">
                              {selectedCardData.points} points on travel
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-purple-600">
                            {selectedCardData.pointsValue.toLocaleString()}
                          </div>
                          <div className="text-xs text-muted-foreground">points</div>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-green-200">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                              <TrendingUp className="h-3 w-3 text-green-600" />
                            </div>
                            <div>
                              <div className="text-sm font-medium text-green-800">Total Rewards Value</div>
                              <div className="text-xs text-green-600">Estimated cash value</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-green-600 text-lg">
                              ${Math.round(10374 * 0.015 + selectedCardData.pointsValue * selectedCardData.pointsWorth)}
                            </div>
                            <div className="text-xs text-green-600">in rewards</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 p-2 bg-white/50 rounded border border-green-200">
                      <p className="text-xs text-green-700 text-center">
                        💡 Your Business Class booking earns {selectedCardData.points.replace("x", "x more")} points
                        than Economy
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full"
                  onClick={() => {
                    if (activeTab === "cash") {
                      const airlineUrl = "https://www.britishairways.com"
                      if (
                        confirm(
                          "You will be redirected to the airline website to complete your cash booking. Continue?",
                        )
                      ) {
                        window.open(airlineUrl, "_blank")
                      }
                    } else {
                      alert("Miles booking completed! You will receive confirmation via email.")
                    }
                  }}
                >
                  {activeTab === "cash" ? "Continue to Airline" : "Complete Miles Booking"}
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
