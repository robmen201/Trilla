"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Plane, Clock, MapPin, Star, CreditCard, Coins } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function VenezuelaDealsPage() {
  const [activeTab, setActiveTab] = useState("all")

  const cashDeals = [
    {
      id: "ve-cash-1",
      airline: "Copa Airlines",
      route: "MIA → CCS",
      destination: "Caracas",
      price: 385,
      originalPrice: 580,
      savings: 195,
      duration: "3h 45m",
      stops: "1 stop",
      dates: "Aug 20 - Aug 27",
      dealType: "Caribbean Special",
      urgency: "3 seats left",
      features: ["Free checked bag", "Meal included", "Entertainment"],
    },
    {
      id: "ve-cash-2",
      airline: "American",
      route: "JFK → CCS",
      destination: "Caracas",
      price: 420,
      originalPrice: 650,
      savings: 230,
      duration: "6h 30m",
      stops: "1 stop",
      dates: "Sep 10 - Sep 17",
      dealType: "Flash Sale",
      urgency: "Ends in 4 hours",
      features: ["Priority boarding", "Extra legroom", "WiFi available"],
    },
    {
      id: "ve-cash-3",
      airline: "Avianca",
      route: "LAX → VLN",
      destination: "Valencia",
      price: 465,
      originalPrice: 720,
      savings: 255,
      duration: "8h 15m",
      stops: "2 stops",
      dates: "Oct 5 - Oct 12",
      dealType: "Adventure Deal",
      urgency: "Limited time",
      features: ["Flexible dates", "Free cancellation", "Seat selection"],
    },
  ]

  const milesDeals = [
    {
      id: "ve-miles-1",
      airline: "United",
      route: "MIA → CCS",
      destination: "Caracas",
      miles: 45000,
      originalMiles: 70000,
      savings: 25000,
      cashValue: 675,
      milesValue: 1.5,
      duration: "3h 30m",
      stops: "1 stop",
      dates: "Aug 25 - Sep 1",
      dealType: "MileagePlus Saver",
      urgency: "Award seats available",
      features: ["Business class", "Priority check-in", "Lounge access"],
    },
    {
      id: "ve-miles-2",
      airline: "Chase UR",
      route: "JFK → CCS",
      destination: "Caracas",
      miles: 38000,
      originalMiles: 60000,
      savings: 22000,
      cashValue: 570,
      milesValue: 1.6,
      duration: "6h 15m",
      stops: "1 stop",
      dates: "Sep 15 - Sep 22",
      dealType: "Transfer Bonus",
      urgency: "Sweet spot",
      features: ["Premium economy", "Fast track", "Meal upgrade"],
    },
    {
      id: "ve-miles-3",
      airline: "Amex MR",
      route: "ORD → MAR",
      destination: "Maracaibo",
      miles: 52000,
      originalMiles: 80000,
      savings: 28000,
      cashValue: 780,
      milesValue: 1.7,
      duration: "9h 45m",
      stops: "2 stops",
      dates: "Oct 8 - Oct 15",
      dealType: "Points Transfer",
      urgency: "Excellent value",
      features: ["First class", "Lounge access", "Concierge service"],
    },
  ]

  const allDeals = [...cashDeals, ...milesDeals]
  const displayDeals = activeTab === "cash" ? cashDeals : activeTab === "miles" ? milesDeals : allDeals

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div className="text-2xl font-bold">
              <span className="text-teal-500">TRILL</span>
              <span className="text-gray-800">A</span>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="relative h-64 overflow-hidden">
        <Image src="/images/destinations/venezuela.jpg" alt="Venezuela" fill className="object-cover" />
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl font-bold mb-2">Hot Deals to Venezuela</h1>
            <p className="text-xl">Discover pristine beaches and natural wonders</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Filter Tabs */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant={activeTab === "all" ? "default" : "outline"}
            onClick={() => setActiveTab("all")}
            className={activeTab === "all" ? "bg-teal-500 hover:bg-teal-600" : ""}
          >
            All Deals ({allDeals.length})
          </Button>
          <Button
            variant={activeTab === "cash" ? "default" : "outline"}
            onClick={() => setActiveTab("cash")}
            className={activeTab === "cash" ? "bg-teal-500 hover:bg-teal-600" : ""}
          >
            <CreditCard className="h-4 w-4 mr-2" />
            Cash Deals ({cashDeals.length})
          </Button>
          <Button
            variant={activeTab === "miles" ? "default" : "outline"}
            onClick={() => setActiveTab("miles")}
            className={activeTab === "miles" ? "bg-teal-500 hover:bg-teal-600" : ""}
          >
            <Coins className="h-4 w-4 mr-2" />
            Miles & Points ({milesDeals.length})
          </Button>
        </div>

        {/* Deals Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayDeals.map((deal) => (
            <Card key={deal.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Plane className="h-5 w-5 text-teal-500" />
                    <span className="font-semibold">{deal.airline}</span>
                  </div>
                  <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                    {deal.dealType}
                  </Badge>
                </div>
                <div className="text-sm text-gray-600">{deal.route}</div>
                <CardTitle className="text-lg">{deal.destination}</CardTitle>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Price */}
                <div className="flex items-center justify-between">
                  <div>
                    {"price" in deal ? (
                      <>
                        <div className="text-2xl font-bold text-teal-600">${deal.price}</div>
                        <div className="text-sm text-gray-500 line-through">${deal.originalPrice}</div>
                        <div className="text-sm text-green-600">Save ${deal.savings}</div>
                      </>
                    ) : (
                      <>
                        <div className="text-2xl font-bold text-purple-600">{deal.miles.toLocaleString()} pts</div>
                        <div className="text-sm text-gray-500 line-through">
                          {deal.originalMiles.toLocaleString()} pts
                        </div>
                        <div className="text-sm text-green-600">Save {deal.savings.toLocaleString()} pts</div>
                        <div className="text-xs text-purple-600">{deal.milesValue}¢ per point value</div>
                      </>
                    )}
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-sm text-gray-600">
                      <Clock className="h-4 w-4" />
                      {deal.duration}
                    </div>
                    <div className="text-sm text-gray-600">{deal.stops}</div>
                  </div>
                </div>

                {/* Dates */}
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="h-4 w-4" />
                  {deal.dates}
                </div>

                {/* Urgency */}
                <div className="text-sm font-medium text-red-600">{deal.urgency}</div>

                {/* Features */}
                <div className="space-y-1">
                  {deal.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                      <Star className="h-3 w-3 text-yellow-500" />
                      {feature}
                    </div>
                  ))}
                </div>

                {/* Book Button */}
                <Button className="w-full bg-teal-500 hover:bg-teal-600">Book This Deal</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}
