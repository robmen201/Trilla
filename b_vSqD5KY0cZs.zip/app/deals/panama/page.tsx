"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Plane, Clock, MapPin, Star, CreditCard, Coins } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function PanamaDealsPage() {
  const [activeTab, setActiveTab] = useState("all")

  const cashDeals = [
    {
      id: "pa-cash-1",
      airline: "Copa Airlines",
      route: "MIA → PTY",
      destination: "Panama City",
      price: 285,
      originalPrice: 420,
      savings: 135,
      duration: "2h 45m",
      stops: "Nonstop",
      dates: "Aug 25 - Sep 1",
      dealType: "Canal Special",
      urgency: "6 seats left",
      features: ["Free checked bag", "Meal included", "City tour"],
    },
    {
      id: "pa-cash-2",
      airline: "American",
      route: "JFK → PTY",
      destination: "Panama City",
      price: 340,
      originalPrice: 520,
      savings: 180,
      duration: "5h 30m",
      stops: "1 stop",
      dates: "Sep 15 - Sep 22",
      dealType: "Flash Sale",
      urgency: "Ends in 5 hours",
      features: ["Priority boarding", "Extra legroom", "WiFi available"],
    },
    {
      id: "pa-cash-3",
      airline: "United",
      route: "LAX → PTY",
      destination: "Panama City",
      price: 395,
      originalPrice: 600,
      savings: 205,
      duration: "7h 15m",
      stops: "1 stop",
      dates: "Oct 10 - Oct 17",
      dealType: "Adventure Deal",
      urgency: "Limited time",
      features: ["Flexible dates", "Free cancellation", "Seat selection"],
    },
  ]

  const milesDeals = [
    {
      id: "pa-miles-1",
      airline: "United",
      route: "MIA → PTY",
      destination: "Panama City",
      miles: 25000,
      originalMiles: 40000,
      savings: 15000,
      cashValue: 375,
      milesValue: 1.5,
      duration: "2h 30m",
      stops: "Nonstop",
      dates: "Aug 28 - Sep 4",
      dealType: "MileagePlus Saver",
      urgency: "Award seats available",
      features: ["Business class", "Priority check-in", "Lounge access"],
    },
    {
      id: "pa-miles-2",
      airline: "Chase UR",
      route: "JFK → PTY",
      destination: "Panama City",
      miles: 22000,
      originalMiles: 35000,
      savings: 13000,
      cashValue: 330,
      milesValue: 1.6,
      duration: "5h 15m",
      stops: "1 stop",
      dates: "Sep 18 - Sep 25",
      dealType: "Transfer Bonus",
      urgency: "Sweet spot",
      features: ["Premium economy", "Fast track", "Meal upgrade"],
    },
    {
      id: "pa-miles-3",
      airline: "Amex MR",
      route: "ORD → PTY",
      destination: "Panama City",
      miles: 32000,
      originalMiles: 50000,
      savings: 18000,
      cashValue: 480,
      milesValue: 1.7,
      duration: "6h 45m",
      stops: "1 stop",
      dates: "Oct 12 - Oct 19",
      dealType: "Points Transfer",
      urgency: "Excellent value",
      features: ["First class", "Lounge access", "Concierge service"],
    },
  ]

  const allDeals = [...cashDeals, ...milesDeals]
  const displayDeals = activeTab === "cash" ? cashDeals : activeTab === "miles" ? milesDeals : allDeals

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div className="text-2xl font-bold">
              <span className="text-teal-500">TRILL</span>
              <span className="text-gray-800">A</span>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="relative h-64 overflow-hidden">
        <Image src="/images/destinations/panama.jpg" alt="Panama" fill className="object-cover" />
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl font-bold mb-2">Hot Deals to Panama</h1>
            <p className="text-xl">Experience modern cities and natural beauty</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Filter Tabs */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant={activeTab === "all" ? "default" : "outline"}
            onClick={() => setActiveTab("all")}
            className={activeTab === "all" ? "bg-teal-500 hover:bg-teal-600" : ""}
          >
            All Deals ({allDeals.length})
          </Button>
          <Button
            variant={activeTab === "cash" ? "default" : "outline"}
            onClick={() => setActiveTab("cash")}
            className={activeTab === "cash" ? "bg-teal-500 hover:bg-teal-600" : ""}
          >
            <CreditCard className="h-4 w-4 mr-2" />
            Cash Deals ({cashDeals.length})
          </Button>
          <Button
            variant={activeTab === "miles" ? "default" : "outline"}
            onClick={() => setActiveTab("miles")}
            className={activeTab === "miles" ? "bg-teal-500 hover:bg-teal-600" : ""}
          >
            <Coins className="h-4 w-4 mr-2" />
            Miles & Points ({milesDeals.length})
          </Button>
        </div>

        {/* Deals Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayDeals.map((deal) => (
            <Card key={deal.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Plane className="h-5 w-5 text-teal-500" />
                    <span className="font-semibold">{deal.airline}</span>
                  </div>
                  <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                    {deal.dealType}
                  </Badge>
                </div>
                <div className="text-sm text-gray-600">{deal.route}</div>
                <CardTitle className="text-lg">{deal.destination}</CardTitle>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Price */}
                <div className="flex items-center justify-between">
                  <div>
                    {"price" in deal ? (
                      <>
                        <div className="text-2xl font-bold text-teal-600">${deal.price}</div>
                        <div className="text-sm text-gray-500 line-through">${deal.originalPrice}</div>
                        <div className="text-sm text-green-600">Save ${deal.savings}</div>
                      </>
                    ) : (
                      <>
                        <div className="text-2xl font-bold text-purple-600">{deal.miles.toLocaleString()} pts</div>
                        <div className="text-sm text-gray-500 line-through">
                          {deal.originalMiles.toLocaleString()} pts
                        </div>
                        <div className="text-sm text-green-600">Save {deal.savings.toLocaleString()} pts</div>
                        <div className="text-xs text-purple-600">{deal.milesValue}¢ per point value</div>
                      </>
                    )}
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-sm text-gray-600">
                      <Clock className="h-4 w-4" />
                      {deal.duration}
                    </div>
                    <div className="text-sm text-gray-600">{deal.stops}</div>
                  </div>
                </div>

                {/* Dates */}
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="h-4 w-4" />
                  {deal.dates}
                </div>

                {/* Urgency */}
                <div className="text-sm font-medium text-red-600">{deal.urgency}</div>

                {/* Features */}
                <div className="space-y-1">
                  {deal.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                      <Star className="h-3 w-3 text-yellow-500" />
                      {feature}
                    </div>
                  ))}
                </div>

                {/* Book Button */}
                <Button className="w-full bg-teal-500 hover:bg-teal-600">Book This Deal</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}
