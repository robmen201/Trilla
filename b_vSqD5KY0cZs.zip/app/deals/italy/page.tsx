"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Plane, Clock, MapPin, Star, CreditCard, Coins } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function ItalyDealsPage() {
  const [activeTab, setActiveTab] = useState("all")

  const cashDeals = [
    {
      id: "it-cash-1",
      airline: "Alitalia",
      route: "JFK → FCO",
      destination: "Rome",
      price: 485,
      originalPrice: 720,
      savings: 235,
      duration: "8h 30m",
      stops: "Nonstop",
      dates: "Sep 15 - Sep 22",
      dealType: "Autumn Special",
      urgency: "5 seats left",
      features: ["Free checked bag", "Meal service", "Entertainment system"],
    },
    {
      id: "it-cash-2",
      airline: "Delta",
      route: "LAX → MXP",
      destination: "Milan",
      price: 520,
      originalPrice: 780,
      savings: 260,
      duration: "11h 45m",
      stops: "1 stop",
      dates: "Oct 8 - Oct 15",
      dealType: "Fashion Week",
      urgency: "Ends tomorrow",
      features: ["Priority boarding", "Extra legroom", "Lounge access"],
    },
    {
      id: "it-cash-3",
      airline: "United",
      route: "ORD → VCE",
      destination: "Venice",
      price: 565,
      originalPrice: 850,
      savings: 285,
      duration: "9h 20m",
      stops: "Nonstop",
      dates: "Nov 12 - Nov 19",
      dealType: "Off-Season",
      urgency: "Limited availability",
      features: ["Flexible booking", "Free cancellation", "Seat selection"],
    },
  ]

  const milesDeals = [
    {
      id: "it-miles-1",
      airline: "American",
      route: "JFK → FCO",
      destination: "Rome",
      miles: 60000,
      originalMiles: 85000,
      savings: 25000,
      cashValue: 900,
      milesValue: 1.5,
      duration: "8h 15m",
      stops: "Nonstop",
      dates: "Sep 20 - Sep 27",
      dealType: "AAdvantage Saver",
      urgency: "Award availability",
      features: ["Business class", "Priority check-in", "Lounge access"],
    },
    {
      id: "it-miles-2",
      airline: "Chase UR",
      route: "LAX → MXP",
      destination: "Milan",
      miles: 55000,
      originalMiles: 80000,
      savings: 25000,
      cashValue: 825,
      milesValue: 1.6,
      duration: "11h 30m",
      stops: "1 stop",
      dates: "Oct 10 - Oct 17",
      dealType: "Transfer Partner",
      urgency: "Great value",
      features: ["Premium economy", "Fast track", "Meal upgrade"],
    },
    {
      id: "it-miles-3",
      airline: "Virgin Atlantic",
      route: "JFK → FCO",
      destination: "Rome",
      miles: 75000,
      originalMiles: 110000,
      savings: 35000,
      cashValue: 1125,
      milesValue: 1.8,
      duration: "8h 45m",
      stops: "Nonstop",
      dates: "Nov 15 - Nov 22",
      dealType: "Upper Class",
      urgency: "Premium award",
      features: ["First class", "Chauffeur service", "Fine dining"],
    },
  ]

  const allDeals = [...cashDeals, ...milesDeals]
  const displayDeals = activeTab === "cash" ? cashDeals : activeTab === "miles" ? milesDeals : allDeals

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div className="text-2xl font-bold">
              <span className="text-teal-500">TRILL</span>
              <span className="text-gray-800">A</span>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="relative h-64 overflow-hidden">
        <Image src="/images/destinations/italy.jpg" alt="Italy" fill className="object-cover" />
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl font-bold mb-2">Hot Deals to Italy</h1>
            <p className="text-xl">Experience art, culture, and culinary excellence</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Filter Tabs */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant={activeTab === "all" ? "default" : "outline"}
            onClick={() => setActiveTab("all")}
            className={activeTab === "all" ? "bg-teal-500 hover:bg-teal-600" : ""}
          >
            All Deals ({allDeals.length})
          </Button>
          <Button
            variant={activeTab === "cash" ? "default" : "outline"}
            onClick={() => setActiveTab("cash")}
            className={activeTab === "cash" ? "bg-teal-500 hover:bg-teal-600" : ""}
          >
            <CreditCard className="h-4 w-4 mr-2" />
            Cash Deals ({cashDeals.length})
          </Button>
          <Button
            variant={activeTab === "miles" ? "default" : "outline"}
            onClick={() => setActiveTab("miles")}
            className={activeTab === "miles" ? "bg-teal-500 hover:bg-teal-600" : ""}
          >
            <Coins className="h-4 w-4 mr-2" />
            Miles & Points ({milesDeals.length})
          </Button>
        </div>

        {/* Deals Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayDeals.map((deal) => (
            <Card key={deal.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Plane className="h-5 w-5 text-teal-500" />
                    <span className="font-semibold">{deal.airline}</span>
                  </div>
                  <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                    {deal.dealType}
                  </Badge>
                </div>
                <div className="text-sm text-gray-600">{deal.route}</div>
                <CardTitle className="text-lg">{deal.destination}</CardTitle>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Price */}
                <div className="flex items-center justify-between">
                  <div>
                    {"price" in deal ? (
                      <>
                        <div className="text-2xl font-bold text-teal-600">${deal.price}</div>
                        <div className="text-sm text-gray-500 line-through">${deal.originalPrice}</div>
                        <div className="text-sm text-green-600">Save ${deal.savings}</div>
                      </>
                    ) : (
                      <>
                        <div className="text-2xl font-bold text-purple-600">{deal.miles.toLocaleString()} pts</div>
                        <div className="text-sm text-gray-500 line-through">
                          {deal.originalMiles.toLocaleString()} pts
                        </div>
                        <div className="text-sm text-green-600">Save {deal.savings.toLocaleString()} pts</div>
                        <div className="text-xs text-purple-600">{deal.milesValue}¢ per point value</div>
                      </>
                    )}
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-sm text-gray-600">
                      <Clock className="h-4 w-4" />
                      {deal.duration}
                    </div>
                    <div className="text-sm text-gray-600">{deal.stops}</div>
                  </div>
                </div>

                {/* Dates */}
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="h-4 w-4" />
                  {deal.dates}
                </div>

                {/* Urgency */}
                <div className="text-sm font-medium text-red-600">{deal.urgency}</div>

                {/* Features */}
                <div className="space-y-1">
                  {deal.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                      <Star className="h-3 w-3 text-yellow-500" />
                      {feature}
                    </div>
                  ))}
                </div>

                {/* Book Button */}
                <Button className="w-full bg-teal-500 hover:bg-teal-600">Book This Deal</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}
