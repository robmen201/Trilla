"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Plane, Clock, Flame, CreditCard, Coins } from "lucide-react"
import Link from "next/link"

export default function HotDealsPage() {
  const cashDeals = [
    {
      id: 1,
      route: "Miami → New York",
      airports: "MIA → JFK",
      price: "$70",
      originalPrice: "$180",
      savings: "61% OFF",
      airline: "JetBlue",
      duration: "3h 15m",
      dates: "Mar 15 - Mar 22",
      timeLeft: "2 days left",
      badge: "FLASH SALE",
    },
    {
      id: 2,
      route: "Los Angeles → Chicago",
      airports: "LAX → ORD",
      price: "$95",
      originalPrice: "$220",
      savings: "57% OFF",
      airline: "Southwest",
      duration: "4h 20m",
      dates: "Mar 18 - Mar 25",
      timeLeft: "5 days left",
      badge: "LIMITED TIME",
    },
    {
      id: 3,
      route: "Chicago → Miami",
      airports: "ORD → MIA",
      price: "$85",
      originalPrice: "$195",
      savings: "56% OFF",
      airline: "American",
      duration: "3h 45m",
      dates: "Mar 20 - Mar 27",
      timeLeft: "1 week left",
      badge: "HOT DEAL",
    },
    {
      id: 4,
      route: "New York → Los Angeles",
      airports: "JFK → LAX",
      price: "$125",
      originalPrice: "$280",
      savings: "55% OFF",
      airline: "Delta",
      duration: "6h 30m",
      dates: "Mar 22 - Mar 29",
      timeLeft: "3 days left",
      badge: "WEEKEND SPECIAL",
    },
  ]

  const milesDeals = [
    {
      id: 1,
      route: "Miami → Chicago",
      airports: "MIA → ORD",
      miles: "15,000",
      program: "Chase Points",
      originalMiles: "25,000",
      savings: "40% OFF",
      airline: "United",
      duration: "3h 30m",
      dates: "Mar 16 - Mar 23",
      timeLeft: "4 days left",
      badge: "POINTS SAVER",
    },
    {
      id: 2,
      route: "New York → London",
      airports: "JFK → LHR",
      miles: "35,000",
      program: "American Miles",
      originalMiles: "60,000",
      savings: "42% OFF",
      airline: "British Airways",
      duration: "7h 15m",
      dates: "Mar 25 - Apr 1",
      timeLeft: "1 week left",
      badge: "TRANSATLANTIC",
    },
    {
      id: 3,
      route: "Los Angeles → Tokyo",
      airports: "LAX → NRT",
      miles: "45,000",
      program: "United Miles",
      originalMiles: "80,000",
      savings: "44% OFF",
      airline: "ANA",
      duration: "11h 45m",
      dates: "Apr 5 - Apr 12",
      timeLeft: "2 weeks left",
      badge: "ASIA SPECIAL",
    },
    {
      id: 4,
      route: "Chicago → Paris",
      airports: "ORD → CDG",
      miles: "38,000",
      program: "Chase Sapphire",
      originalMiles: "65,000",
      savings: "42% OFF",
      airline: "Air France",
      duration: "8h 20m",
      dates: "Apr 8 - Apr 15",
      timeLeft: "10 days left",
      badge: "EUROPE DEAL",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-gray-600 hover:text-teal-600">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="text-2xl font-bold">
              <span className="text-teal-500">TRILL</span>
              <span className="text-gray-800">A</span>
            </div>
          </div>

          <Link href="/dashboard">
            <div className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors">
              <div className="text-sm">
                <div className="font-medium text-gray-800">Hi Nathan</div>
                <div className="text-gray-500">My Wallet</div>
              </div>
            </div>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Flame className="h-8 w-8 text-orange-500" />
            <h1 className="text-4xl font-bold text-gray-800">Hot Deals</h1>
            <Flame className="h-8 w-8 text-orange-500" />
          </div>
          <p className="text-xl text-gray-600">Exclusive offers you won't find anywhere else</p>
        </div>

        {/* Horizontal Layout - Cash Deals and Miles & Points Side by Side */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Cash Deals Section */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <CreditCard className="h-6 w-6 text-teal-500" />
              <h2 className="text-2xl font-bold text-gray-800">Cash Deals</h2>
            </div>
            <div className="space-y-6">
              {cashDeals.map((deal) => (
                <Card
                  key={deal.id}
                  className="overflow-hidden hover:shadow-lg transition-shadow border-2 hover:border-teal-200 h-80"
                >
                  <CardContent className="p-6 h-full flex flex-col justify-between">
                    <div className="flex justify-between items-start mb-4">
                      <Badge variant="destructive" className="bg-orange-500 hover:bg-orange-600">
                        {deal.badge}
                      </Badge>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-teal-600">{deal.price}</div>
                        <div className="text-sm text-gray-500 line-through">{deal.originalPrice}</div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <h3 className="text-xl font-semibold text-gray-800 mb-1">{deal.route}</h3>
                      <p className="text-gray-600 text-sm">{deal.airports}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-4 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <Plane className="h-4 w-4" />
                        {deal.airline}
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        {deal.duration}
                      </div>
                    </div>

                    <div className="flex justify-between items-center mb-4">
                      <span className="text-sm text-gray-600">{deal.dates}</span>
                      <Badge variant="outline" className="text-orange-600 border-orange-200">
                        {deal.savings}
                      </Badge>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-red-600">{deal.timeLeft}</span>
                      <Button className="bg-teal-500 hover:bg-teal-600">Book Now</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Miles & Points Section */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <Coins className="h-6 w-6 text-purple-500" />
              <h2 className="text-2xl font-bold text-gray-800">Miles & Points</h2>
            </div>
            <div className="space-y-6">
              {milesDeals.map((deal) => (
                <Card
                  key={deal.id}
                  className="overflow-hidden hover:shadow-lg transition-shadow border-2 hover:border-purple-200 h-80"
                >
                  <CardContent className="p-6 h-full flex flex-col justify-between">
                    <div className="flex justify-between items-start mb-4">
                      <Badge className="bg-purple-500 hover:bg-purple-600">{deal.badge}</Badge>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-purple-600">{deal.miles}</div>
                        <div className="text-sm text-gray-500 line-through">{deal.originalMiles}</div>
                        <div className="text-xs text-purple-600">{deal.program}</div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <h3 className="text-xl font-semibold text-gray-800 mb-1">{deal.route}</h3>
                      <p className="text-gray-600 text-sm">{deal.airports}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-4 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <Plane className="h-4 w-4" />
                        {deal.airline}
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        {deal.duration}
                      </div>
                    </div>

                    <div className="flex justify-between items-center mb-4">
                      <span className="text-sm text-gray-600">{deal.dates}</span>
                      <Badge variant="outline" className="text-purple-600 border-purple-200">
                        {deal.savings}
                      </Badge>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-red-600">{deal.timeLeft}</span>
                      <Button className="bg-purple-500 hover:bg-purple-600">Redeem Points</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
