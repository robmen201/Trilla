"use client"

import { useState } from "react"
import { AdminDashboard } from "@/components/admin-dashboard"
import { UserDashboard } from "@/components/user-dashboard"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, Shield, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function DashboardPage() {
  const [userRole, setUserRole] = useState<"user" | "admin" | null>(null)

  if (!userRole) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-96">
          <CardContent className="p-8 text-center">
            <div className="mb-6">
              <div className="text-2xl font-bold mb-2">
                <span className="text-teal-500">TRILL</span>
                <span className="text-gray-800">A</span>
              </div>
              <p className="text-gray-600">Choose your dashboard access level</p>
            </div>

            <div className="space-y-4">
              <Button
                onClick={() => setUserRole("user")}
                className="w-full bg-teal-500 hover:bg-teal-600 text-white h-12"
              >
                <Users className="mr-3 h-5 w-5" />
                User Dashboard
                <Badge className="ml-auto bg-orange-200 text-orange-800">Nathan</Badge>
              </Button>

              <Button
                onClick={() => setUserRole("admin")}
                variant="outline"
                className="w-full h-12 border-red-200 hover:bg-red-50"
              >
                <Shield className="mr-3 h-5 w-5" />
                Admin Control Panel
                <Badge className="ml-auto bg-red-100 text-red-800">Super Admin</Badge>
              </Button>
            </div>

            <div className="mt-6 pt-6 border-t">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Search
                </Button>
              </Link>
            </div>

            <div className="mt-4 text-xs text-gray-500">
              <p>💡 Tip: Click "Admin Control Panel" to see the new admin dashboard!</p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (userRole === "admin") {
    return <AdminDashboard />
  }

  return <UserDashboard />
}
