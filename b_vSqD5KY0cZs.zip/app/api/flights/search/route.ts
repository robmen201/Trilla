import { type NextRequest, NextResponse } from "next/server"

// Enhanced mock flight data generator with multiple route scenarios
const getFlightScenarios = () => {
  return {
    // Scenario 1: JFK to LHR (New York to London)
    "JFK-LHR": [
      {
        id: "jfk-lhr-1",
        airline: "British Airways",
        airlineName: "British Airways",
        alliance: "Oneworld",
        flightNumber: "BA112",
        departTime: "8:30 PM",
        arriveTime: "7:45 AM+1",
        duration: "6h 15m",
        stops: 0,
        cabins: {
          economy: {
            name: "World Traveller",
            price: 850,
            milesPrice: 60000,
            milesValue: 1.42,
            potentialMiles: 4250,
            statusMultiplier: 1.0,
            benefits: ["Personal item", "Seat selection for fee", "Standard meal"],
            baggage: "Carry-on: Free, Checked: $60",
            confidence: 85,
            isEstimated: false,
          },
          business: {
            name: "Club World",
            price: 3200,
            milesPrice: 120000,
            milesValue: 2.67,
            potentialMiles: 12800,
            statusMultiplier: 2.0,
            benefits: ["Lie-flat seat", "Lounge access", "Premium dining", "Priority everything"],
            baggage: "Carry-on: Free, Checked: Free (2 bags)",
            confidence: 85,
            isEstimated: false,
          },
        },
        aiRecommendation: {
          isRecommended: true,
          score: 95,
          reason: "Excellent value with your Gold status benefits",
          savings: 850,
          urgency: "high" as const,
          priceChange: 120,
          preferredMethod: "miles" as const,
          cashVsMilesAdvice: "Use miles - exceptional 2.67¢ value!",
        },
        bestCreditCard: "Chase Sapphire Reserve",
        cardBonus: "3x",
      },
      {
        id: "jfk-lhr-2",
        airline: "Virgin Atlantic",
        airlineName: "Virgin Atlantic",
        alliance: "None",
        flightNumber: "VS3",
        departTime: "7:30 PM",
        arriveTime: "6:45 AM+1",
        duration: "6h 15m",
        stops: 0,
        cabins: {
          economy: {
            name: "Economy",
            price: 780,
            milesPrice: 55000,
            milesValue: 1.42,
            potentialMiles: 3900,
            statusMultiplier: 1.0,
            benefits: ["Personal item", "Seat selection for fee", "Complimentary meal"],
            baggage: "Carry-on: Free, Checked: $25",
            confidence: 80,
            isEstimated: false,
          },
          business: {
            name: "Upper Class",
            price: 2850,
            milesPrice: 110000,
            milesValue: 2.59,
            potentialMiles: 11400,
            statusMultiplier: 2.0,
            benefits: ["Lie-flat seat", "Clubhouse access", "Premium dining", "Onboard bar"],
            baggage: "Carry-on: Free, Checked: Free (2 bags)",
            confidence: 80,
            isEstimated: false,
          },
        },
        aiRecommendation: {
          isRecommended: false,
          score: 88,
          reason: "Good value but slightly higher cost",
          savings: 320,
          urgency: "medium" as const,
          priceChange: -25,
          preferredMethod: "cash" as const,
          cashVsMilesAdvice: "Pay cash - decent value at current rates",
        },
        bestCreditCard: "Amex Gold",
        cardBonus: "3x",
      },
      {
        id: "jfk-lhr-3",
        airline: "Lufthansa",
        airlineName: "Lufthansa",
        alliance: "Star Alliance",
        flightNumber: "LH400",
        departTime: "2:15 PM",
        arriveTime: "5:30 AM+1",
        duration: "8h 15m",
        stops: 0,
        cabins: {
          economy: {
            name: "Economy",
            price: 920,
            milesPrice: 55000,
            milesValue: 1.67,
            potentialMiles: 4600,
            statusMultiplier: 1.0,
            benefits: ["Personal entertainment", "German cuisine", "Amenity kit"],
            baggage: "Carry-on: Free, Checked: $35",
            confidence: 90,
            isEstimated: false,
          },
          business: {
            name: "Business Class",
            price: 4200,
            milesPrice: 85000,
            milesValue: 4.94,
            potentialMiles: 16800,
            statusMultiplier: 2.0,
            benefits: ["Lie-flat seat", "Senator Lounge", "Premium dining", "Priority service"],
            baggage: "Carry-on: Free, Checked: Free (2 bags)",
            confidence: 90,
            isEstimated: false,
          },
        },
        aiRecommendation: {
          isRecommended: true,
          score: 96,
          reason: "Amazing value - transfer Chase points to United for Lufthansa",
          savings: 1950,
          urgency: "high" as const,
          priceChange: 150,
          preferredMethod: "miles" as const,
          cashVsMilesAdvice: "Use miles - Amazing value at 4.94¢ per mile!",
        },
        bestCreditCard: "Chase Sapphire Reserve",
        cardBonus: "3x",
      },
    ],

    // Scenario 2: LAX to NRT (Los Angeles to Tokyo)
    "LAX-NRT": [
      {
        id: "lax-nrt-1",
        airline: "Japan Airlines",
        airlineName: "Japan Airlines",
        alliance: "Oneworld",
        flightNumber: "JL62",
        departTime: "11:50 AM",
        arriveTime: "3:35 PM+1",
        duration: "11h 45m",
        stops: 0,
        cabins: {
          economy: {
            name: "Economy Class",
            price: 1200,
            milesPrice: 80000,
            milesValue: 1.5,
            potentialMiles: 6000,
            statusMultiplier: 1.0,
            benefits: ["Personal entertainment", "Japanese cuisine", "Amenity kit"],
            baggage: "Carry-on: Free, Checked: Free (1 bag)",
            confidence: 90,
            isEstimated: false,
          },
          business: {
            name: "JAL Sky Suite",
            price: 4500,
            milesPrice: 160000,
            milesValue: 2.81,
            potentialMiles: 18000,
            statusMultiplier: 2.0,
            benefits: ["Lie-flat seat", "Sakura Lounge", "Kaiseki dining", "Priority service"],
            baggage: "Carry-on: Free, Checked: Free (2 bags)",
            confidence: 90,
            isEstimated: false,
          },
        },
        aiRecommendation: {
          isRecommended: true,
          score: 96,
          reason: "Outstanding value for transpacific route",
          savings: 1200,
          urgency: "high" as const,
          priceChange: 200,
          preferredMethod: "miles" as const,
          cashVsMilesAdvice: "Use miles - excellent 2.81¢ value for business!",
        },
        bestCreditCard: "Chase Sapphire Reserve",
        cardBonus: "3x",
      },
      {
        id: "lax-nrt-2",
        airline: "All Nippon Airways",
        airlineName: "All Nippon Airways",
        alliance: "Star Alliance",
        flightNumber: "NH175",
        departTime: "1:55 PM",
        arriveTime: "5:40 PM+1",
        duration: "11h 45m",
        stops: 0,
        cabins: {
          economy: {
            name: "Economy",
            price: 1150,
            milesPrice: 75000,
            milesValue: 1.53,
            potentialMiles: 5750,
            statusMultiplier: 1.0,
            benefits: ["Personal entertainment", "Japanese hospitality", "Quality meals"],
            baggage: "Carry-on: Free, Checked: Free (1 bag)",
            confidence: 85,
            isEstimated: false,
          },
          business: {
            name: "The Room",
            price: 4200,
            milesPrice: 150000,
            milesValue: 2.8,
            potentialMiles: 16800,
            statusMultiplier: 2.0,
            benefits: ["Private suite", "ANA Lounge", "Multi-course dining", "Concierge service"],
            baggage: "Carry-on: Free, Checked: Free (2 bags)",
            confidence: 85,
            isEstimated: false,
          },
        },
        aiRecommendation: {
          isRecommended: false,
          score: 92,
          reason: "Excellent service but slightly higher miles cost",
          savings: 950,
          urgency: "medium" as const,
          priceChange: 50,
          preferredMethod: "miles" as const,
          cashVsMilesAdvice: "Use miles - great 2.80¢ value for The Room!",
        },
        bestCreditCard: "Amex Platinum",
        cardBonus: "5x",
      },
    ],

    // Scenario 3: MIA to CDG (Miami to Paris)
    "MIA-CDG": [
      {
        id: "mia-cdg-1",
        airline: "Air France",
        airlineName: "Air France",
        alliance: "SkyTeam",
        flightNumber: "AF90",
        departTime: "10:25 PM",
        arriveTime: "2:15 PM+1",
        duration: "8h 50m",
        stops: 0,
        cabins: {
          economy: {
            name: "Economy",
            price: 920,
            milesPrice: 65000,
            milesValue: 1.42,
            potentialMiles: 4600,
            statusMultiplier: 1.0,
            benefits: ["Personal entertainment", "French cuisine", "Wine selection"],
            baggage: "Carry-on: Free, Checked: $50",
            confidence: 80,
            isEstimated: false,
          },
          business: {
            name: "La Première",
            price: 3800,
            milesPrice: 140000,
            milesValue: 2.71,
            potentialMiles: 15200,
            statusMultiplier: 2.0,
            benefits: ["Lie-flat seat", "Air France Lounge", "Michelin-star dining", "Limousine service"],
            baggage: "Carry-on: Free, Checked: Free (2 bags)",
            confidence: 80,
            isEstimated: false,
          },
        },
        aiRecommendation: {
          isRecommended: true,
          score: 93,
          reason: "Great value with French luxury experience",
          savings: 1100,
          urgency: "high" as const,
          priceChange: 150,
          preferredMethod: "miles" as const,
          cashVsMilesAdvice: "Use miles - excellent 2.71¢ value for La Première!",
        },
        bestCreditCard: "Amex Gold",
        cardBonus: "3x",
      },
    ],

    // Scenario 4: ORD to SYD (Chicago to Sydney)
    "ORD-SYD": [
      {
        id: "ord-syd-1",
        airline: "United Airlines",
        airlineName: "United Airlines",
        alliance: "Star Alliance",
        flightNumber: "UA870",
        departTime: "10:45 PM",
        arriveTime: "6:20 AM+2",
        duration: "17h 35m",
        stops: 1,
        cabins: {
          economy: {
            name: "Economy",
            price: 1450,
            milesPrice: 90000,
            milesValue: 1.61,
            potentialMiles: 7250,
            statusMultiplier: 1.0,
            benefits: ["Personal entertainment", "Meals included", "Amenity kit"],
            baggage: "Carry-on: Free, Checked: Free (1 bag)",
            confidence: 75,
            isEstimated: true,
          },
          business: {
            name: "Polaris Business",
            price: 5200,
            milesPrice: 180000,
            milesValue: 2.89,
            potentialMiles: 20800,
            statusMultiplier: 2.0,
            benefits: ["Lie-flat seat", "Polaris Lounge", "Multi-course dining", "Bedding"],
            baggage: "Carry-on: Free, Checked: Free (2 bags)",
            confidence: 75,
            isEstimated: true,
          },
        },
        aiRecommendation: {
          isRecommended: true,
          score: 94,
          reason: "Excellent long-haul value with your status",
          savings: 1800,
          urgency: "high" as const,
          priceChange: 300,
          preferredMethod: "miles" as const,
          cashVsMilesAdvice: "Use miles - outstanding 2.89¢ value for Polaris!",
        },
        bestCreditCard: "Chase Sapphire Reserve",
        cardBonus: "3x",
      },
      {
        id: "ord-syd-2",
        airline: "Qantas",
        airlineName: "Qantas",
        alliance: "Oneworld",
        flightNumber: "QF94",
        departTime: "3:20 PM",
        arriveTime: "10:05 PM+1",
        duration: "15h 45m",
        stops: 0,
        cabins: {
          economy: {
            name: "Economy",
            price: 1380,
            milesPrice: 85000,
            milesValue: 1.62,
            potentialMiles: 6900,
            statusMultiplier: 1.0,
            benefits: ["Personal entertainment", "Australian cuisine", "Amenity kit"],
            baggage: "Carry-on: Free, Checked: Free (1 bag)",
            confidence: 85,
            isEstimated: false,
          },
          business: {
            name: "Business Suite",
            price: 4800,
            milesPrice: 170000,
            milesValue: 2.82,
            potentialMiles: 19200,
            statusMultiplier: 2.0,
            benefits: ["Lie-flat suite", "Qantas Lounge", "Neil Perry menu", "Priority boarding"],
            baggage: "Carry-on: Free, Checked: Free (2 bags)",
            confidence: 85,
            isEstimated: false,
          },
        },
        aiRecommendation: {
          isRecommended: false,
          score: 89,
          reason: "Great nonstop option but higher cost",
          savings: 1200,
          urgency: "medium" as const,
          priceChange: 100,
          preferredMethod: "miles" as const,
          cashVsMilesAdvice: "Use miles - good 2.82¢ value for Business Suite!",
        },
        bestCreditCard: "Amex Platinum",
        cardBonus: "5x",
      },
    ],
  }
}

const getMockFlightData = (searchParams: any) => {
  const scenarios = getFlightScenarios()
  const routeKey = `${searchParams.origin}-${searchParams.destination}`

  // Get flights for the specific route, or return empty array if route not found
  const routeFlights = scenarios[routeKey as keyof typeof scenarios] || []

  // Update flight data with actual search parameters
  return routeFlights.map((flight) => ({
    ...flight,
    origin: searchParams.origin,
    destination: searchParams.destination,
    date: searchParams.departureDate,
  }))
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate required parameters
    const { origin, destination, departureDate, adults = 1 } = body

    if (!origin || !destination || !departureDate) {
      return NextResponse.json(
        { error: "Missing required parameters: origin, destination, departureDate" },
        { status: 400 },
      )
    }

    // Prepare search parameters
    const searchParams = {
      origin: origin.toUpperCase(),
      destination: destination.toUpperCase(),
      departureDate,
      adults: Number.parseInt(adults),
      returnDate: body.returnDate,
      children: body.children ? Number.parseInt(body.children) : undefined,
      travelClass: body.travelClass,
    }

    console.log("Searching flights with params:", searchParams)

    // Get flights for the specific route
    const flights = getMockFlightData(searchParams)

    console.log(`Returning ${flights.length} flights for ${origin} -> ${destination}`)

    return NextResponse.json({
      success: true,
      flights,
      searchParams,
      timestamp: new Date().toISOString(),
      dataSource: "mock",
    })
  } catch (error) {
    console.error("Flight search API error:", error)

    return NextResponse.json(
      {
        error: "Failed to search flights",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)

  const origin = searchParams.get("origin")
  const destination = searchParams.get("destination")
  const departureDate = searchParams.get("departureDate")

  if (!origin || !destination || !departureDate) {
    return NextResponse.json({ error: "Missing required query parameters" }, { status: 400 })
  }

  try {
    const flightSearchParams = {
      origin: origin.toUpperCase(),
      destination: destination.toUpperCase(),
      departureDate,
      adults: Number.parseInt(searchParams.get("adults") || "1"),
      returnDate: searchParams.get("returnDate") || undefined,
      travelClass: searchParams.get("travelClass") || undefined,
    }

    const flights = getMockFlightData(flightSearchParams)

    return NextResponse.json({
      success: true,
      flights,
      searchParams: flightSearchParams,
      timestamp: new Date().toISOString(),
      dataSource: "mock",
    })
  } catch (error) {
    console.error("Flight search API error:", error)

    return NextResponse.json(
      {
        error: "Failed to search flights",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
