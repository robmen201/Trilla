import { type NextRequest, NextResponse } from "next/server"
import { redisClient } from "@/lib/redis-client"

export interface UserFeedback {
  flightId: string
  airline: string
  route: string
  cabin: string
  actualMilesPrice?: number
  actualCashPrice?: number
  wasAvailable: boolean
  userEmail?: string
  timestamp: string
  notes?: string
}

export async function POST(request: NextRequest) {
  try {
    const feedback: UserFeedback = await request.json()

    // Validate required fields
    if (!feedback.flightId || !feedback.airline || !feedback.route) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Add timestamp
    feedback.timestamp = new Date().toISOString()

    // Store feedback in Redis
    const feedbackKey = `feedback:${feedback.flightId}:${Date.now()}`
    await redisClient.set(feedbackKey, JSON.stringify(feedback), 86400 * 30) // 30 days

    // Update aggregated feedback for this route
    const routeKey = `feedback:route:${feedback.route}:${feedback.airline}:${feedback.cabin}`
    const existingData = await redisClient.get(routeKey)

    let aggregatedData = {
      totalReports: 0,
      averageMilesPrice: 0,
      averageCashPrice: 0,
      availabilityRate: 0,
      lastUpdated: feedback.timestamp,
    }

    if (existingData) {
      aggregatedData = JSON.parse(existingData)
    }

    // Update aggregated data
    aggregatedData.totalReports += 1

    if (feedback.actualMilesPrice) {
      aggregatedData.averageMilesPrice = Math.round(
        (aggregatedData.averageMilesPrice * (aggregatedData.totalReports - 1) + feedback.actualMilesPrice) /
          aggregatedData.totalReports,
      )
    }

    if (feedback.actualCashPrice) {
      aggregatedData.averageCashPrice = Math.round(
        (aggregatedData.averageCashPrice * (aggregatedData.totalReports - 1) + feedback.actualCashPrice) /
          aggregatedData.totalReports,
      )
    }

    aggregatedData.availabilityRate = Math.round(
      ((aggregatedData.availabilityRate * (aggregatedData.totalReports - 1) + (feedback.wasAvailable ? 1 : 0)) /
        aggregatedData.totalReports) *
        100,
    )

    aggregatedData.lastUpdated = feedback.timestamp

    // Store updated aggregated data
    await redisClient.set(routeKey, JSON.stringify(aggregatedData), 86400 * 90) // 90 days

    console.log("User feedback stored:", feedback)

    return NextResponse.json({
      success: true,
      message: "Feedback received successfully",
      feedbackId: feedbackKey,
    })
  } catch (error) {
    console.error("User feedback API error:", error)

    return NextResponse.json(
      {
        error: "Failed to process feedback",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const route = searchParams.get("route")
  const airline = searchParams.get("airline")
  const cabin = searchParams.get("cabin")

  if (!route || !airline || !cabin) {
    return NextResponse.json({ error: "Missing required query parameters: route, airline, cabin" }, { status: 400 })
  }

  try {
    const routeKey = `feedback:route:${route}:${airline}:${cabin}`
    const aggregatedData = await redisClient.get(routeKey)

    if (!aggregatedData) {
      return NextResponse.json({
        success: true,
        data: null,
        message: "No feedback data available for this route",
      })
    }

    return NextResponse.json({
      success: true,
      data: JSON.parse(aggregatedData),
    })
  } catch (error) {
    console.error("Get feedback API error:", error)

    return NextResponse.json(
      {
        error: "Failed to retrieve feedback data",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
