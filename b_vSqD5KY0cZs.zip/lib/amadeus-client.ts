import Amadeus from "amadeus"

export interface FlightSearchParams {
  origin: string
  destination: string
  departureDate: string
  returnDate?: string
  adults: number
  children?: number
  infants?: number
  travelClass?: "ECONOMY" | "PREMIUM_ECONOMY" | "BUSINESS" | "FIRST"
  nonStop?: boolean
  maxPrice?: number
  max?: number
}

export interface AmadeusFlightOffer {
  id: string
  source: string
  instantTicketingRequired: boolean
  nonHomogeneous: boolean
  oneWay: boolean
  lastTicketingDate: string
  numberOfBookableSeats: number
  itineraries: Array<{
    duration: string
    segments: Array<{
      departure: {
        iataCode: string
        terminal?: string
        at: string
      }
      arrival: {
        iataCode: string
        terminal?: string
        at: string
      }
      carrierCode: string
      number: string
      aircraft: {
        code: string
      }
      operating?: {
        carrierCode: string
      }
      duration: string
      id: string
      numberOfStops: number
      blacklistedInEU: boolean
    }>
  }>
  price: {
    currency: string
    total: string
    base: string
    fees: Array<{
      amount: string
      type: string
    }>
    grandTotal: string
  }
  pricingOptions: {
    fareType: string[]
    includedCheckedBagsOnly: boolean
  }
  validatingAirlineCodes: string[]
  travelerPricings: Array<{
    travelerId: string
    fareOption: string
    travelerType: string
    price: {
      currency: string
      total: string
      base: string
    }
    fareDetailsBySegment: Array<{
      segmentId: string
      cabin: string
      fareBasis: string
      brandedFare?: string
      class: string
      includedCheckedBags: {
        quantity: number
      }
    }>
  }>
}

class AmadeusClient {
  private client: Amadeus

  constructor() {
    this.client = new Amadeus({
      clientId: process.env.AMADEUS_CLIENT_ID!,
      clientSecret: process.env.AMADEUS_CLIENT_SECRET!,
      hostname: process.env.NODE_ENV === "production" ? "production" : "test",
    })
  }

  async searchFlights(params: FlightSearchParams): Promise<AmadeusFlightOffer[]> {
    try {
      const searchParams: any = {
        originLocationCode: params.origin,
        destinationLocationCode: params.destination,
        departureDate: params.departureDate,
        adults: params.adults,
        max: params.max || 20,
      }

      if (params.returnDate) {
        searchParams.returnDate = params.returnDate
      }

      if (params.children) {
        searchParams.children = params.children
      }

      if (params.infants) {
        searchParams.infants = params.infants
      }

      if (params.travelClass) {
        searchParams.travelClass = params.travelClass
      }

      if (params.nonStop) {
        searchParams.nonStop = params.nonStop
      }

      if (params.maxPrice) {
        searchParams.maxPrice = params.maxPrice
      }

      const response = await this.client.shopping.flightOffersSearch.get(searchParams)
      return response.data
    } catch (error) {
      console.error("Amadeus API Error:", error)
      throw new Error("Failed to fetch flight data from Amadeus")
    }
  }

  async getAirlineInfo(airlineCode: string) {
    try {
      const response = await this.client.referenceData.airlines.get({
        airlineCodes: airlineCode,
      })
      return response.data[0]
    } catch (error) {
      console.error("Failed to get airline info:", error)
      return null
    }
  }

  async getAirportInfo(airportCode: string) {
    try {
      const response = await this.client.referenceData.locations.get({
        keyword: airportCode,
        subType: "AIRPORT",
      })
      return response.data[0]
    } catch (error) {
      console.error("Failed to get airport info:", error)
      return null
    }
  }
}

export const amadeusClient = new AmadeusClient()
