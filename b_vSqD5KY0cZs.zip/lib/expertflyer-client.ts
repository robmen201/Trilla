// ExpertFlyer API integration for real award data
export interface AwardAvailability {
  airline: string
  flightNumber: string
  date: string
  origin: string
  destination: string
  cabin: string
  availability: number
  milesRequired?: number
}

class ExpertFlyerClient {
  private apiKey: string
  private baseUrl: string

  constructor() {
    this.apiKey = process.env.EXPERTFLYER_API_KEY || ""
    this.baseUrl = "https://api.expertflyer.com/v1"
  }

  async getAwardAvailability(
    airline: string,
    origin: string,
    destination: string,
    date: string,
    cabin = "Y",
  ): Promise<AwardAvailability[]> {
    if (!this.apiKey) {
      throw new Error("ExpertFlyer API key not configured")
    }

    try {
      const response = await fetch(`${this.baseUrl}/award-availability`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          airline,
          origin,
          destination,
          date,
          cabin,
        }),
      })

      if (!response.ok) {
        throw new Error(`ExpertFlyer API error: ${response.statusText}`)
      }

      const data = await response.json()
      return data.availability || []
    } catch (error) {
      console.error("ExpertFlyer API Error:", error)
      return []
    }
  }

  async getAwardPricing(
    airline: string,
    origin: string,
    destination: string,
    cabin = "Y",
  ): Promise<{ miles: number; confidence: number } | null> {
    try {
      const response = await fetch(`${this.baseUrl}/award-pricing`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          airline,
          origin,
          destination,
          cabin,
        }),
      })

      if (!response.ok) {
        return null
      }

      const data = await response.json()
      return {
        miles: data.miles,
        confidence: 90, // High confidence for real data
      }
    } catch (error) {
      console.error("ExpertFlyer pricing error:", error)
      return null
    }
  }
}

export const expertFlyerClient = new ExpertFlyerClient()
