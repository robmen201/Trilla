export interface AirlineConfig {
  name: string
  alliance: "Star Alliance" | "Oneworld" | "SkyTeam" | "None"
  baseRates: {
    economy: number
    premium: number
    business: number
    first: number
  }
  seasonalMultipliers: {
    peak: number
    shoulder: number
    low: number
  }
  routeMultipliers: {
    domestic: number
    shortHaul: number
    longHaul: number
    ultraLongHaul: number
  }
}

export const AIRLINE_CONFIGS: Record<string, AirlineConfig> = {
  AA: {
    name: "American Airlines",
    alliance: "Oneworld",
    baseRates: { economy: 1.2, premium: 1.4, business: 2.0, first: 3.0 },
    seasonalMultipliers: { peak: 1.3, shoulder: 1.1, low: 0.9 },
    routeMultipliers: { domestic: 1.0, shortHaul: 1.2, longHaul: 1.5, ultraLongHaul: 1.8 },
  },
  DL: {
    name: "Delta Air Lines",
    alliance: "SkyTeam",
    baseRates: { economy: 1.1, premium: 1.3, business: 1.8, first: 2.8 },
    seasonalMultipliers: { peak: 1.4, shoulder: 1.2, low: 0.8 },
    routeMultipliers: { domestic: 1.0, shortHaul: 1.1, longHaul: 1.4, ultraLongHaul: 1.7 },
  },
  UA: {
    name: "United Airlines",
    alliance: "Star Alliance",
    baseRates: { economy: 1.3, premium: 1.5, business: 2.1, first: 3.2 },
    seasonalMultipliers: { peak: 1.2, shoulder: 1.0, low: 0.9 },
    routeMultipliers: { domestic: 1.0, shortHaul: 1.3, longHaul: 1.6, ultraLongHaul: 1.9 },
  },
  BA: {
    name: "British Airways",
    alliance: "Oneworld",
    baseRates: { economy: 1.4, premium: 1.6, business: 2.3, first: 3.5 },
    seasonalMultipliers: { peak: 1.5, shoulder: 1.2, low: 0.8 },
    routeMultipliers: { domestic: 1.2, shortHaul: 1.4, longHaul: 1.7, ultraLongHaul: 2.0 },
  },
  VS: {
    name: "Virgin Atlantic",
    alliance: "None",
    baseRates: { economy: 1.3, premium: 1.5, business: 2.2, first: 3.3 },
    seasonalMultipliers: { peak: 1.4, shoulder: 1.1, low: 0.9 },
    routeMultipliers: { domestic: 1.0, shortHaul: 1.3, longHaul: 1.6, ultraLongHaul: 1.9 },
  },
  LH: {
    name: "Lufthansa",
    alliance: "Star Alliance",
    baseRates: { economy: 1.2, premium: 1.4, business: 2.0, first: 3.1 },
    seasonalMultipliers: { peak: 1.3, shoulder: 1.1, low: 0.9 },
    routeMultipliers: { domestic: 1.1, shortHaul: 1.3, longHaul: 1.6, ultraLongHaul: 1.9 },
  },
}

export interface RouteInfo {
  distance: number
  type: "domestic" | "shortHaul" | "longHaul" | "ultraLongHaul"
  season: "peak" | "shoulder" | "low"
}

export interface CreditCardConfig {
  name: string
  travelMultiplier: number
  pointValue: number // cents per point
}

export const CREDIT_CARD_CONFIGS: Record<string, CreditCardConfig> = {
  "Chase Sapphire Reserve": { name: "Chase Sapphire Reserve", travelMultiplier: 3, pointValue: 2.0 },
  "Amex Platinum": { name: "Amex Platinum", travelMultiplier: 5, pointValue: 2.0 },
  "Citi Premier": { name: "Citi Premier", travelMultiplier: 3, pointValue: 1.5 },
  "Capital One Venture X": { name: "Capital One Venture X", travelMultiplier: 2, pointValue: 1.5 },
  "Citi AAdvantage": { name: "Citi AAdvantage", travelMultiplier: 2, pointValue: 1.5 },
  "Amex Gold": { name: "Amex Gold", travelMultiplier: 3, pointValue: 2.0 },
}

export class MilesEstimator {
  private getRouteType(distance: number): "domestic" | "shortHaul" | "longHaul" | "ultraLongHaul" {
    if (distance < 500) return "domestic"
    if (distance < 2000) return "shortHaul"
    if (distance < 6000) return "longHaul"
    return "ultraLongHaul"
  }

  private getSeason(date: string): "peak" | "shoulder" | "low" {
    const month = new Date(date).getMonth() + 1

    // Peak: June-August, December
    if ([6, 7, 8, 12].includes(month)) return "peak"

    // Shoulder: March-May, September-November
    if ([3, 4, 5, 9, 10, 11].includes(month)) return "shoulder"

    // Low: January, February
    return "low"
  }

  private calculateDistance(origin: string, destination: string): number {
    // Simplified distance calculation - in production, use a proper geo library
    const distances: Record<string, Record<string, number>> = {
      JFK: { LHR: 3459, CDG: 3625, FRA: 3851, NRT: 6740 },
      LAX: { LHR: 5439, CDG: 5658, FRA: 5782, NRT: 5477 },
      ORD: { LHR: 3958, CDG: 4134, FRA: 4336, NRT: 6299 },
    }

    return distances[origin]?.[destination] || 3500 // Default to medium-haul
  }

  calculateTotalRewardsValue(
    cashPrice: number,
    airlineCode: string,
    cabin: "economy" | "premium" | "business" | "first",
    distance: number,
    creditCard: string,
    statusTier: "none" | "silver" | "gold" | "platinum" = "gold",
  ): {
    airlineMilesEarned: number
    airlineMilesValue: number
    creditCardPointsEarned: number
    creditCardPointsValue: number
    totalRewardsValue: number
  } {
    // Calculate airline miles earned
    const earnedMiles = this.estimateEarnedMiles(cashPrice, airlineCode, cabin, distance, statusTier)
    const airlineMilesValue = Math.round(earnedMiles.totalMiles * 0.01) // 1¢ per mile baseline

    // Calculate credit card points earned
    const cardConfig = CREDIT_CARD_CONFIGS[creditCard]
    const creditCardPointsEarned = cardConfig ? Math.round(cashPrice * cardConfig.travelMultiplier) : 0
    const creditCardPointsValue = cardConfig ? Math.round(creditCardPointsEarned * (cardConfig.pointValue / 100)) : 0

    return {
      airlineMilesEarned: earnedMiles.totalMiles,
      airlineMilesValue,
      creditCardPointsEarned,
      creditCardPointsValue,
      totalRewardsValue: airlineMilesValue + creditCardPointsValue,
    }
  }

  estimateAwardPrice(
    cashPrice: number,
    airlineCode: string,
    cabin: "economy" | "premium" | "business" | "first",
    origin: string,
    destination: string,
    departureDate: string,
    creditCard = "Chase Sapphire Reserve",
  ): {
    estimatedMiles: number
    confidence: number
    naiveMilesValue: number // Old calculation (cash ÷ miles)
    trueMilesValue: number // New calculation (net cash cost ÷ miles)
    recommendation: "cash" | "miles"
    reasoning: string
    rewardsOpportunityCost: number
  } {
    const config = AIRLINE_CONFIGS[airlineCode]

    if (!config) {
      // Fallback for unknown airlines
      const fallbackMiles = Math.round((cashPrice / 1.5) * 100)
      return {
        estimatedMiles: fallbackMiles,
        confidence: 60,
        naiveMilesValue: 1.5,
        trueMilesValue: 1.5,
        recommendation: "cash",
        reasoning: "Unknown airline - estimated based on industry averages",
        rewardsOpportunityCost: 0,
      }
    }

    const distance = this.calculateDistance(origin, destination)
    const routeType = this.getRouteType(distance)
    const season = this.getSeason(departureDate)

    const baseRate = config.baseRates[cabin]
    const seasonalMultiplier = config.seasonalMultipliers[season]
    const routeMultiplier = config.routeMultipliers[routeType]

    // Calculate estimated miles needed
    const estimatedMiles = Math.round((cashPrice / baseRate) * seasonalMultiplier * routeMultiplier)

    // Calculate naive miles value (traditional calculation)
    const naiveMilesValue = Number(((cashPrice / estimatedMiles) * 100).toFixed(2))

    // Calculate rewards opportunity cost
    const rewardsValue = this.calculateTotalRewardsValue(cashPrice, airlineCode, cabin, distance, creditCard)
    const netCashCost = cashPrice - rewardsValue.totalRewardsValue

    // Calculate true miles value (accounting for opportunity cost)
    const trueMilesValue = Number(((netCashCost / estimatedMiles) * 100).toFixed(2))

    // Determine recommendation based on true value
    const recommendation = trueMilesValue >= 1.4 ? "miles" : "cash"

    // Calculate confidence based on various factors
    let confidence = 75 // Base confidence

    // Adjust confidence based on airline data quality
    if (["AA", "DL", "UA"].includes(airlineCode)) confidence += 15
    if (["BA", "LH"].includes(airlineCode)) confidence += 10

    // Adjust confidence based on route popularity
    if (routeType === "longHaul") confidence += 5
    if (routeType === "domestic") confidence -= 5

    // Generate reasoning
    let reasoning = ""
    if (recommendation === "miles") {
      reasoning = `Excellent value at ${trueMilesValue.toFixed(1)}¢ per mile (after accounting for ${rewardsValue.totalRewardsValue} in lost rewards)`
    } else {
      reasoning = `Better to pay cash at ${trueMilesValue.toFixed(1)}¢ per mile - below average value even after rewards opportunity cost`
    }

    if (season === "peak") {
      reasoning += ` Peak season pricing affects availability.`
    }

    return {
      estimatedMiles,
      confidence: Math.min(confidence, 95),
      naiveMilesValue,
      trueMilesValue,
      recommendation,
      reasoning,
      rewardsOpportunityCost: rewardsValue.totalRewardsValue,
    }
  }

  estimateEarnedMiles(
    cashPrice: number,
    airlineCode: string,
    cabin: "economy" | "premium" | "business" | "first",
    distance: number,
    statusTier: "none" | "silver" | "gold" | "platinum" = "none",
  ): {
    baseMiles: number
    bonusMiles: number
    totalMiles: number
    statusMultiplier: number
  } {
    // Base miles calculation (typically distance-based)
    const baseMiles = Math.round(distance)

    // Cabin multipliers
    const cabinMultipliers = {
      economy: 1.0,
      premium: 1.25,
      business: 1.5,
      first: 2.0,
    }

    // Status multipliers
    const statusMultipliers = {
      none: 1.0,
      silver: 1.25,
      gold: 1.5,
      platinum: 1.75,
    }

    const cabinMultiplier = cabinMultipliers[cabin]
    const statusMultiplier = statusMultipliers[statusTier]

    const earnedMiles = Math.round(baseMiles * cabinMultiplier)
    const bonusMiles = Math.round(earnedMiles * (statusMultiplier - 1))
    const totalMiles = earnedMiles + bonusMiles

    return {
      baseMiles: earnedMiles,
      bonusMiles,
      totalMiles,
      statusMultiplier,
    }
  }
}

export const milesEstimator = new MilesEstimator()
