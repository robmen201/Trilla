import { amadeusClient, type AmadeusFlightOffer, type FlightSearchParams } from "./amadeus-client"
import { redisClient } from "./redis-client"
import { milesEstimator, AIRLINE_CONFIGS } from "./miles-estimation"
import { expertFlyerClient } from "./expertflyer-client"

export interface EnhancedFlightOffer {
  id: string
  airline: string
  airlineName: string
  alliance: string
  flightNumber: string
  departTime: string
  arriveTime: string
  duration: string
  stops: number
  origin: string
  destination: string
  date: string
  cabins: {
    economy: CabinInfo
    premium: CabinInfo
    business: CabinInfo
    first?: CabinInfo
  }
  aiRecommendation: {
    isRecommended: boolean
    score: number
    reason: string
    savings: number
    urgency: "low" | "medium" | "high"
    priceChange: number
    preferredMethod: "cash" | "miles"
    cashVsMilesAdvice: string
  }
  bestCreditCard: string
  cardBonus: string
}

export interface CabinInfo {
  name: string
  price: number
  milesPrice: number
  milesValue: number
  potentialMiles: number
  statusMultiplier: number
  benefits: string[]
  baggage: string
  confidence: number
  isEstimated: boolean
}

class FlightDataService {
  private readonly CACHE_TTL = 300 // 5 minutes

  async searchFlights(params: FlightSearchParams): Promise<EnhancedFlightOffer[]> {
    const cacheKey = redisClient.generateCacheKey("flights", params)

    // Try to get from cache first
    const cached = await redisClient.get(cacheKey)
    if (cached) {
      console.log("Returning cached flight data")
      return JSON.parse(cached)
    }

    try {
      // Get real flight data from Amadeus
      const amadeusFlights = await amadeusClient.searchFlights(params)

      // Enhance with miles data and AI recommendations
      const enhancedFlights = await this.enhanceFlightData(amadeusFlights, params)

      // Cache the results
      await redisClient.set(cacheKey, JSON.stringify(enhancedFlights), this.CACHE_TTL)

      return enhancedFlights
    } catch (error) {
      console.error("Flight search error:", error)

      // Return mock data as fallback
      return this.getMockFlightData(params)
    }
  }

  private async enhanceFlightData(
    amadeusFlights: AmadeusFlightOffer[],
    params: FlightSearchParams,
  ): Promise<EnhancedFlightOffer[]> {
    const enhanced: EnhancedFlightOffer[] = []

    for (const flight of amadeusFlights.slice(0, 10)) {
      // Limit to 10 flights
      try {
        const segment = flight.itineraries[0].segments[0]
        const airlineCode = segment.carrierCode
        const airlineConfig = AIRLINE_CONFIGS[airlineCode]

        if (!airlineConfig) continue // Skip unknown airlines

        // Extract basic flight info
        const departTime = new Date(segment.departure.at).toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
          hour12: true,
        })

        const arriveTime = new Date(segment.arrival.at).toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
          hour12: true,
        })

        const duration = flight.itineraries[0].duration.replace("PT", "").toLowerCase()
        const stops = segment.numberOfStops
        const basePrice = Number.parseFloat(flight.price.total)

        // Calculate cabin prices (Amadeus typically returns economy)
        const cabinPrices = this.calculateCabinPrices(basePrice)

        // Get miles estimates for each cabin
        const cabins = await this.getCabinInfo(
          cabinPrices,
          airlineCode,
          params.origin,
          params.destination,
          params.departureDate,
        )

        // Generate AI recommendation
        const aiRecommendation = this.generateAIRecommendation(cabins, airlineConfig)

        enhanced.push({
          id: flight.id,
          airline: airlineConfig.name,
          airlineName: airlineConfig.name,
          alliance: airlineConfig.alliance,
          flightNumber: `${airlineCode}${segment.number}`,
          departTime,
          arriveTime,
          duration,
          stops,
          origin: segment.departure.iataCode,
          destination: segment.arrival.iataCode,
          date: params.departureDate,
          cabins,
          aiRecommendation,
          bestCreditCard: this.getBestCreditCard(airlineCode),
          cardBonus: this.getCreditCardBonus(airlineCode),
        })
      } catch (error) {
        console.error("Error enhancing flight:", error)
        continue
      }
    }

    return enhanced
  }

  private calculateCabinPrices(basePrice: number): Record<string, number> {
    return {
      economy: basePrice,
      premium: Math.round(basePrice * 1.4),
      business: Math.round(basePrice * 3.2),
      first: Math.round(basePrice * 5.5),
    }
  }

  private async getCabinInfo(
    prices: Record<string, number>,
    airlineCode: string,
    origin: string,
    destination: string,
    date: string,
  ): Promise<EnhancedFlightOffer["cabins"]> {
    const cabins: any = {}

    for (const [cabinType, price] of Object.entries(prices)) {
      if (cabinType === "first" && price > 8000) continue // Skip unrealistic first class prices

      // Try to get real award data first
      let milesData
      try {
        milesData = await expertFlyerClient.getAwardPricing(
          airlineCode,
          origin,
          destination,
          cabinType.charAt(0).toUpperCase(),
        )
      } catch (error) {
        console.log("ExpertFlyer unavailable, using estimation")
      }

      // Fallback to estimation
      if (!milesData) {
        const estimation = milesEstimator.estimateAwardPrice(
          price,
          airlineCode,
          cabinType as any,
          origin,
          destination,
          date,
        )
        milesData = {
          miles: estimation.estimatedMiles,
          confidence: estimation.confidence,
        }
      }

      // Calculate earned miles
      const distance = this.calculateDistance(origin, destination)
      const earnedMiles = milesEstimator.estimateEarnedMiles(
        price,
        airlineCode,
        cabinType as any,
        distance,
        "gold", // Assume gold status for demo
      )

      cabins[cabinType] = {
        name: this.getCabinName(cabinType, airlineCode),
        price,
        milesPrice: milesData.miles,
        milesValue: Number(((price / milesData.miles) * 100).toFixed(2)),
        potentialMiles: earnedMiles.totalMiles,
        statusMultiplier: earnedMiles.statusMultiplier,
        benefits: this.getCabinBenefits(cabinType),
        baggage: this.getBaggageInfo(cabinType),
        confidence: milesData.confidence,
        isEstimated: !milesData || milesData.confidence < 90,
      }
    }

    return cabins
  }

  private generateAIRecommendation(
    cabins: EnhancedFlightOffer["cabins"],
    airlineConfig: any,
  ): EnhancedFlightOffer["aiRecommendation"] {
    // Find the best value cabin
    let bestCabin = "economy"
    let bestValue = 0
    let preferredMethod: "cash" | "miles" = "cash"

    for (const [cabinType, cabin] of Object.entries(cabins)) {
      if (cabin.milesValue > bestValue) {
        bestValue = cabin.milesValue
        bestCabin = cabinType
        preferredMethod = cabin.milesValue > 1.4 ? "miles" : "cash"
      }
    }

    const isRecommended = bestValue > 1.3 || airlineConfig.alliance === "Oneworld"
    const score = Math.min(95, Math.round(bestValue * 30 + (isRecommended ? 20 : 0)))

    let reason = ""
    if (bestValue > 2.0) {
      reason = "Exceptional miles value + premium experience"
    } else if (bestValue > 1.4) {
      reason = "Good miles value for this route"
    } else {
      reason = "Better to pay cash and earn miles"
    }

    const savings =
      preferredMethod === "miles"
        ? Math.round(cabins[bestCabin as keyof typeof cabins].price * 0.15)
        : Math.round(cabins[bestCabin as keyof typeof cabins].potentialMiles * 0.015)

    return {
      isRecommended,
      score,
      reason,
      savings,
      urgency: bestValue > 2.0 ? "high" : "medium",
      priceChange: Math.round((Math.random() - 0.5) * 200), // Simulated price change
      preferredMethod,
      cashVsMilesAdvice:
        preferredMethod === "miles"
          ? `Use miles - excellent ${bestValue}¢ value!`
          : `Pay cash - poor miles value at ${bestValue}¢`,
    }
  }

  private calculateDistance(origin: string, destination: string): number {
    // Simplified distance calculation
    const distances: Record<string, Record<string, number>> = {
      JFK: { LHR: 3459, CDG: 3625, FRA: 3851 },
      LAX: { LHR: 5439, CDG: 5658, FRA: 5782 },
      ORD: { LHR: 3958, CDG: 4134, FRA: 4336 },
    }

    return distances[origin]?.[destination] || 3500
  }

  private getCabinName(cabinType: string, airlineCode: string): string {
    const names: Record<string, Record<string, string>> = {
      AA: { economy: "Main Cabin", premium: "Premium Economy", business: "Business", first: "Flagship First" },
      DL: { economy: "Main Cabin", premium: "Comfort+", business: "Delta One", first: "Delta One Suites" },
      UA: { economy: "Economy", premium: "Premium Plus", business: "Polaris", first: "Polaris First" },
      BA: { economy: "Economy", premium: "Premium Economy", business: "Club World", first: "First" },
    }

    return names[airlineCode]?.[cabinType] || `${cabinType.charAt(0).toUpperCase()}${cabinType.slice(1)}`
  }

  private getCabinBenefits(cabinType: string): string[] {
    const benefits: Record<string, string[]> = {
      economy: ["Personal item", "Seat selection for fee", "Standard meal"],
      premium: ["Priority boarding", "Extra legroom", "Premium meal", "Free checked bag"],
      business: ["Lie-flat seat", "Lounge access", "Premium dining", "Priority everything"],
      first: ["Private suite", "Concierge service", "Chef-prepared meals", "Luxury amenities"],
    }

    return benefits[cabinType] || []
  }

  private getBaggageInfo(cabinType: string): string {
    const baggage: Record<string, string> = {
      economy: "Carry-on: Free, Checked: $30",
      premium: "Carry-on: Free, Checked: Free (1 bag)",
      business: "Carry-on: Free, Checked: Free (2 bags)",
      first: "Carry-on: Free, Checked: Free (3 bags)",
    }

    return baggage[cabinType] || ""
  }

  private getBestCreditCard(airlineCode: string): string {
    const cards: Record<string, string> = {
      AA: "Citi AAdvantage Platinum",
      DL: "Amex Platinum",
      UA: "Chase Sapphire Reserve",
      BA: "Chase Sapphire Reserve",
      VS: "Amex Gold",
    }

    return cards[airlineCode] || "Chase Sapphire Reserve"
  }

  private getCreditCardBonus(airlineCode: string): string {
    const bonuses: Record<string, string> = {
      AA: "2x",
      DL: "5x",
      UA: "3x",
      BA: "3x",
      VS: "3x",
    }

    return bonuses[airlineCode] || "3x"
  }

  private getMockFlightData(params: FlightSearchParams): EnhancedFlightOffer[] {
    // Return the existing mock data as fallback
    return [
      {
        id: "1",
        airline: "British Airways",
        airlineName: "British Airways",
        alliance: "Oneworld",
        flightNumber: "BA112",
        departTime: "8:30 AM",
        arriveTime: "10:45 PM",
        duration: "7h 15m",
        stops: 0,
        origin: params.origin,
        destination: params.destination,
        date: params.departureDate,
        cabins: {
          economy: {
            name: "Economy Basic",
            price: 850,
            milesPrice: 60000,
            milesValue: 1.42,
            potentialMiles: 3458,
            statusMultiplier: 1.0,
            benefits: ["Personal item", "Seat selection for fee", "Standard meal"],
            baggage: "Carry-on: $35, Checked: $60",
            confidence: 75,
            isEstimated: true,
          },
          premium: {
            name: "Premium Economy",
            price: 1250,
            milesPrice: 85000,
            milesValue: 1.47,
            potentialMiles: 5187,
            statusMultiplier: 1.25,
            benefits: ["Priority boarding", "Extra legroom", "Premium meal", "Free checked bag"],
            baggage: "Carry-on: Free, Checked: Free (1 bag)",
            confidence: 75,
            isEstimated: true,
          },
          business: {
            name: "Business Class",
            price: 3200,
            milesPrice: 120000,
            milesValue: 2.67,
            potentialMiles: 10374,
            statusMultiplier: 2.0,
            benefits: ["Lie-flat seat", "Lounge access", "Premium dining", "Priority everything"],
            baggage: "Carry-on: Free, Checked: Free (2 bags)",
            confidence: 75,
            isEstimated: true,
          },
        },
        aiRecommendation: {
          isRecommended: true,
          score: 98,
          reason: "Best value redemption + your Gold status benefits",
          savings: 850,
          urgency: "high",
          priceChange: 120,
          preferredMethod: "miles",
          cashVsMilesAdvice: "Use miles - exceptional 2.67¢ value!",
        },
        bestCreditCard: "Chase Sapphire Reserve",
        cardBonus: "3x",
      },
    ]
  }
}

export const flightDataService = new FlightDataService()
