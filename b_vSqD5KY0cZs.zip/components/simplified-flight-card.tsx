"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Sparkles, TrendingUp, Clock } from "lucide-react"

interface SimplifiedFlightCardProps {
  flight: {
    id: string
    airline: string
    departTime: string
    arriveTime: string
    duration: string
    price: number
    recommendation: {
      method: "miles" | "cash"
      savings: number
      card: string
      confidence: number
    }
    urgency?: {
      priceChange: number
      timeLeft: string
    }
  }
}

export function SimplifiedFlightCard({ flight }: SimplifiedFlightCardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        {/* Urgency Alert */}
        {flight.urgency && (
          <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-lg flex items-center gap-2">
            <Clock className="h-4 w-4 text-orange-600" />
            <span className="text-sm text-orange-700">
              Price increased ${flight.urgency.priceChange} since yesterday • Book within {flight.urgency.timeLeft}
            </span>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          {/* Flight Info */}
          <div className="md:col-span-2">
            <div className="flex items-center justify-between mb-2">
              <div className="font-medium">{flight.airline}</div>
              <Badge variant="outline" className="bg-green-50 text-green-700">
                Best Value
              </Badge>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="font-medium">{flight.departTime}</div>
                <div className="text-sm text-muted-foreground">JFK</div>
              </div>
              <div className="flex flex-col items-center">
                <div className="text-xs text-muted-foreground">{flight.duration}</div>
                <ArrowRight className="h-4 w-4 text-muted-foreground" />
                <div className="text-xs text-muted-foreground">Nonstop</div>
              </div>
              <div className="text-center">
                <div className="font-medium">{flight.arriveTime}</div>
                <div className="text-sm text-muted-foreground">LHR</div>
              </div>
            </div>
          </div>

          {/* AI Recommendation */}
          <div className="bg-primary/5 p-4 rounded-lg border border-primary/20">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-primary">AI Recommendation</span>
            </div>
            <div className="text-lg font-bold">${flight.price}</div>
            <div className="text-sm text-muted-foreground">
              {flight.recommendation.method === "miles" ? "Use miles" : "Pay cash"} with {flight.recommendation.card}
            </div>
            <div className="flex items-center gap-1 mt-1">
              <TrendingUp className="h-3 w-3 text-green-600" />
              <span className="text-xs text-green-600 font-medium">Save ${flight.recommendation.savings}</span>
            </div>
            <div className="text-xs text-muted-foreground mt-1">{flight.recommendation.confidence}% confidence</div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-2">
            <Button className="w-full bg-primary hover:bg-primary/90">Book Recommended</Button>
            <Button variant="outline" size="sm" className="w-full">
              See All Options
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
