"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import {
  ArrowRight,
  Heart,
  Plane,
  Sparkles,
  TrendingUp,
  Clock,
  Bell,
  DollarSign,
  Zap,
  AlertCircle,
  Loader2,
  Info,
} from "lucide-react"
import Link from "next/link"
import type { EnhancedFlightOffer } from "@/lib/flight-data-service"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface RealTimeFlightResultsProps {
  searchParams: {
    origin: string
    destination: string
    departureDate: string
    returnDate?: string
    adults: number
    children?: number
    travelClass?: string
  }
}

export function RealTimeFlightResults({ searchParams }: RealTimeFlightResultsProps) {
  const [flights, setFlights] = useState<EnhancedFlightOffer[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedFlightId, setSelectedFlightId] = useState<string | null>(null)
  const [favoriteFlights, setFavoriteFlights] = useState<string[]>([])
  const [selectedCabin, setSelectedCabin] = useState<{ [key: string]: string }>({})
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<{ [key: string]: "cash" | "miles" }>({})

  useEffect(() => {
    searchFlights()
  }, [searchParams])

  const searchFlights = async () => {
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/flights/search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(searchParams),
      })

      const contentType = response.headers.get("content-type") || ""
      let data: any = null

      if (contentType.includes("application/json")) {
        data = await response.json()
      } else {
        const text = await response.text()
        throw new Error(text || response.statusText)
      }

      if (!response.ok) {
        throw new Error(data?.error || data?.message || "Failed to search flights")
      }

      setFlights(data.flights || [])
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "An error occurred"
      setError(errorMessage)
      console.error("Flight search error:", err)
    } finally {
      setLoading(false)
    }
  }

  const toggleFavorite = (id: string) => {
    if (favoriteFlights.includes(id)) {
      setFavoriteFlights(favoriteFlights.filter((flightId) => flightId !== id))
    } else {
      setFavoriteFlights([...favoriteFlights, id])
    }
  }

  const getSelectedCabinData = (flight: EnhancedFlightOffer) => {
    const cabinKey = selectedCabin[flight.id] || "economy"
    return flight.cabins[cabinKey as keyof typeof flight.cabins]
  }

  const selectPaymentMethod = (flightId: string, method: "cash" | "miles") => {
    setSelectedPaymentMethod({ ...selectedPaymentMethod, [flightId]: method })
  }

  // Calculate total rewards value for cash payments
  const calculateTotalRewardsValue = (flight: EnhancedFlightOffer, cabin: any) => {
    // Airline miles value (typically 1.0¢ per mile)
    const airlineMilesValue = cabin.potentialMiles * 0.01

    // Credit card points value (varies by card)
    const cardPointsEarned = Math.round(cabin.price * Number.parseInt(flight.cardBonus))
    let cardPointsValue = 0

    // Different cards have different point values
    if (flight.bestCreditCard.includes("Chase")) {
      cardPointsValue = cardPointsEarned * 0.02 // 2¢ per UR point
    } else if (flight.bestCreditCard.includes("Amex")) {
      cardPointsValue = cardPointsEarned * 0.02 // 2¢ per MR point
    } else if (flight.bestCreditCard.includes("Citi")) {
      cardPointsValue = cardPointsEarned * 0.015 // 1.5¢ per TYP
    } else {
      cardPointsValue = cardPointsEarned * 0.015 // Default 1.5¢
    }

    return {
      airlineMilesValue: Math.round(airlineMilesValue),
      cardPointsValue: Math.round(cardPointsValue),
      totalRewardsValue: Math.round(airlineMilesValue + cardPointsValue),
      cardPointsEarned,
    }
  }

  // Calculate corrected miles value
  const calculateTrueMilesValue = (cabin: any, rewardsValue: any) => {
    const netCashCost = cabin.price - rewardsValue.totalRewardsValue
    return Number(((netCashCost / cabin.milesPrice) * 100).toFixed(2))
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Card className="bg-gradient-to-r from-primary/5 to-blue/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Loader2 className="h-5 w-5 text-primary animate-spin" />
              <span className="font-medium">Searching flights...</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Getting real-time prices and award availability for {searchParams.origin} → {searchParams.destination}
            </p>
          </CardContent>
        </Card>

        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="flex items-center gap-3">
                  <Skeleton className="w-10 h-10 rounded-full" />
                  <div>
                    <Skeleton className="h-4 w-24 mb-2" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <Skeleton className="h-16 w-full" />
                </div>
                <div className="md:col-span-2">
                  <div className="grid grid-cols-2 gap-3">
                    <Skeleton className="h-24 w-full" />
                    <Skeleton className="h-24 w-full" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  if (error) {
    return (
      <Card className="border-red-200 bg-red-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-3">
            <AlertCircle className="h-6 w-6 text-red-600" />
            <div>
              <h3 className="font-medium text-red-800">Search Error</h3>
              <p className="text-sm text-red-700 mt-1">{error}</p>
            </div>
          </div>
          <Button onClick={searchFlights} className="mt-4 bg-transparent" variant="outline">
            Try Again
          </Button>
        </CardContent>
      </Card>
    )
  }

  if (flights.length === 0) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Plane className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="font-medium mb-2">No flights found</h3>
          <p className="text-sm text-muted-foreground">Try adjusting your search criteria or dates.</p>
          <Button onClick={searchFlights} className="mt-4">
            Search Again
          </Button>
        </CardContent>
      </Card>
    )
  }

  const sortedFlights = [...flights].sort((a, b) => {
    if (a.aiRecommendation.isRecommended && !b.aiRecommendation.isRecommended) return -1
    if (!a.aiRecommendation.isRecommended && b.aiRecommendation.isRecommended) return 1
    return b.aiRecommendation.score - a.aiRecommendation.score
  })

  return (
    <TooltipProvider>
      <div className="space-y-4">
        {/* Search Results Header */}
        <Card className="bg-gradient-to-r from-primary/5 to-blue/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  <span className="font-medium">Smart Flight Comparison</span>
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    {flights.length} flights found
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  True cost analysis including rewards opportunity cost for accurate miles valuations
                </p>
              </div>
              <Button onClick={searchFlights} variant="outline" size="sm">
                <ArrowRight className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            </div>
          </CardContent>
        </Card>

        {sortedFlights.map((flight, index) => {
          const currentCabin = getSelectedCabinData(flight)
          const isTopRecommendation = flight.aiRecommendation.isRecommended && index === 0
          const userSelectedMethod = selectedPaymentMethod[flight.id]
          const aiPreferredMethod = flight.aiRecommendation.preferredMethod

          // Calculate total rewards value for this flight
          const rewardsCalculation = calculateTotalRewardsValue(flight, currentCabin)
          const netCashCost = currentCabin.price - rewardsCalculation.totalRewardsValue

          // Calculate both naive and true miles values
          const naiveMilesValue = currentCabin.milesValue // Original calculation
          const trueMilesValue = calculateTrueMilesValue(currentCabin, rewardsCalculation)

          // Check if this is a Lufthansa flight for the bonus badge
          const isLufthansa = flight.airline === "Lufthansa"

          return (
            <Card
              key={flight.id}
              className={`${selectedFlightId === flight.id ? "border-primary" : ""} ${
                flight.aiRecommendation.isRecommended ? "border-l-4 border-l-primary shadow-md" : ""
              }`}
            >
              <CardContent className="p-6">
                {/* AI Recommendation Banner */}
                {flight.aiRecommendation.isRecommended && (
                  <div className="mb-4 p-3 bg-primary/10 border border-primary/20 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Sparkles className="h-4 w-4 text-primary" />
                        <span className="font-medium text-primary">
                          {isTopRecommendation ? "🎯 Best Match" : "⭐ Great Option"}
                        </span>
                        <Badge variant="default" className="bg-primary">
                          {flight.aiRecommendation.score}% Match
                        </Badge>
                        {/* Add 30% bonus badge for Lufthansa */}
                        {isLufthansa && (
                          <Badge className="bg-orange-500 hover:bg-orange-600 text-white animate-pulse">
                            <Zap className="h-3 w-3 mr-1" />
                            30% Bonus
                          </Badge>
                        )}
                      </div>
                      {flight.aiRecommendation.urgency === "high" && (
                        <Badge variant="destructive" className="animate-pulse">
                          <Clock className="h-3 w-3 mr-1" />
                          Book Soon
                        </Badge>
                      )}
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <p className="text-sm text-primary/80">{flight.aiRecommendation.reason}</p>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="h-3 w-3 text-green-600" />
                        <span className="text-sm font-medium text-green-600">
                          Save ${flight.aiRecommendation.savings}
                        </span>
                      </div>
                    </div>
                    {/* Add bonus explanation for Lufthansa */}
                    {isLufthansa && (
                      <div className="mt-2 text-xs text-orange-600 font-medium">
                        🔥 Amex transfer bonus: Only need 42,350 points instead of 55,000!
                      </div>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  {/* Flight Info */}
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                      <Plane className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="font-medium">{flight.airline}</div>
                      <div className="text-sm text-muted-foreground">{flight.alliance}</div>
                      <div className="text-xs text-muted-foreground">{flight.flightNumber}</div>
                    </div>
                  </div>

                  {/* Flight Times */}
                  <div className="flex items-center justify-center">
                    <div className="text-center">
                      <div className="font-medium">{flight.departTime}</div>
                      <div className="text-sm text-muted-foreground">{flight.origin}</div>
                    </div>
                    <div className="mx-2 md:mx-4 flex flex-col items-center">
                      <div className="text-xs text-muted-foreground mb-1">{flight.duration}</div>
                      <div className="relative w-16 md:w-24">
                        <div className="border-t border-dashed border-gray-300 absolute w-full top-1/2"></div>
                        <ArrowRight className="h-3 w-3 absolute right-0 top-1/2 -translate-y-1/2" />
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {flight.stops === 0 ? "Nonstop" : `${flight.stops} stop`}
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="font-medium">{flight.arriveTime}</div>
                      <div className="text-sm text-muted-foreground">{flight.destination}</div>
                    </div>
                  </div>

                  {/* Enhanced Dual-Price Display */}
                  <div className="md:col-span-2">
                    <div className="grid grid-cols-2 gap-3">
                      {/* Cash Option with Total Value Calculation */}
                      <div
                        className={`relative p-4 rounded-lg border-2 cursor-pointer transition-all ${
                          userSelectedMethod === "cash" || (!userSelectedMethod && aiPreferredMethod === "cash")
                            ? "border-green-500 bg-green-50 shadow-md"
                            : "border-gray-200 bg-white hover:border-green-300"
                        }`}
                        onClick={() => selectPaymentMethod(flight.id, "cash")}
                      >
                        {aiPreferredMethod === "cash" && (
                          <div className="absolute -top-2 -right-2">
                            <Badge className="bg-green-600 text-white text-xs animate-pulse">
                              <Zap className="h-3 w-3 mr-1" />
                              AI Pick
                            </Badge>
                          </div>
                        )}

                        <div className="flex items-center gap-2 mb-2">
                          <DollarSign className="h-4 w-4 text-green-600" />
                          <span className="font-medium text-green-800">Pay Cash</span>
                        </div>

                        {/* Ticket Price */}
                        <div className="text-2xl font-bold text-green-700">${currentCabin.price}</div>

                        {/* Simplified Rewards Info */}
                        <div className="text-xs text-green-600 space-y-1 mb-2">
                          <div>✈️ Earn {currentCabin.potentialMiles.toLocaleString()} miles</div>
                          <div>💳 Earn {rewardsCalculation.cardPointsEarned.toLocaleString()} points</div>
                        </div>

                        <div className="text-xs text-green-600 font-medium">
                          💳 {flight.cardBonus} with {flight.bestCreditCard}
                        </div>
                      </div>

                      {/* Miles Option with Corrected Valuation */}
                      <div
                        className={`relative p-4 rounded-lg border-2 cursor-pointer transition-all ${
                          userSelectedMethod === "miles" || (!userSelectedMethod && aiPreferredMethod === "miles")
                            ? "border-blue-500 bg-blue-50 shadow-md"
                            : "border-gray-200 bg-white hover:border-blue-300"
                        }`}
                        onClick={() => selectPaymentMethod(flight.id, "miles")}
                      >
                        {aiPreferredMethod === "miles" && (
                          <div className="absolute -top-2 -right-2">
                            <Badge className="bg-blue-600 text-white text-xs animate-pulse">
                              <Zap className="h-3 w-3 mr-1" />
                              AI Pick
                            </Badge>
                          </div>
                        )}

                        <div className="flex items-center gap-2 mb-2">
                          <Plane className="h-4 w-4 text-blue-600" />
                          <span className="font-medium text-blue-800">Use Miles</span>
                        </div>

                        <div className="text-2xl font-bold text-blue-700">
                          {currentCabin.milesPrice.toLocaleString()}
                        </div>
                        <div className="text-xs text-blue-600 mb-2">
                          miles + ${Math.round(currentCabin.price * 0.1)} taxes
                        </div>

                        {/* Miles Value Comparison */}
                        <div className="space-y-1">
                          <div className="flex items-center gap-1">
                            <span className="text-xs text-blue-600 line-through">
                              💎 Naive: {naiveMilesValue}¢/mile
                            </span>
                            <Tooltip>
                              <TooltipTrigger>
                                <Info className="h-3 w-3 text-blue-400" />
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="text-xs">
                                  Traditional calculation: ${currentCabin.price} ÷{" "}
                                  {currentCabin.milesPrice.toLocaleString()} miles
                                </p>
                              </TooltipContent>
                            </Tooltip>
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="text-xs font-medium text-blue-600">💎 True: {trueMilesValue}¢/mile</span>
                            <Tooltip>
                              <TooltipTrigger>
                                <Info className="h-3 w-3 text-blue-400" />
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="text-xs">
                                  Corrected: ${netCashCost} ÷ {currentCabin.milesPrice.toLocaleString()} miles
                                </p>
                                <p className="text-xs">
                                  Accounts for ${rewardsCalculation.totalRewardsValue} in lost rewards
                                </p>
                              </TooltipContent>
                            </Tooltip>
                          </div>
                        </div>

                        <div className={`text-xs ${trueMilesValue > 1.3 ? "text-blue-600" : "text-orange-600"}`}>
                          {trueMilesValue > 1.3 ? "✨ Great value!" : "⚠️ Below average"}
                        </div>
                      </div>
                    </div>

                    {/* Enhanced AI Advice with True Cost Comparison */}
                    <div className="mt-3 p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-200">
                      <div className="flex items-center gap-2 mb-2">
                        <Sparkles className="h-3 w-3 text-purple-600" />
                        <span className="text-xs font-medium text-purple-800">Smart Comparison:</span>
                      </div>
                      <div className="text-xs text-purple-700 space-y-1">
                        <div>
                          💰 <strong>Net cash cost:</strong> ${netCashCost} (after $
                          {rewardsCalculation.totalRewardsValue} rewards)
                        </div>
                        <div>
                          ✈️ <strong>Miles cost:</strong> {currentCabin.milesPrice.toLocaleString()} miles + $
                          {Math.round(currentCabin.price * 0.1)}
                        </div>
                        <div className="pt-1 border-t border-purple-200">
                          <strong>
                            {trueMilesValue > 1.4
                              ? `Use miles - excellent ${trueMilesValue}¢ value after opportunity cost!`
                              : `Pay cash - poor miles value at ${trueMilesValue}¢ after opportunity cost`}
                          </strong>
                        </div>
                        {/* Add bonus message for Lufthansa */}
                        {isLufthansa && (
                          <div className="pt-1 border-t border-orange-200">
                            <strong className="text-orange-600">
                              🔥 With 30% Amex bonus: Only need 42,350 points to get 55,000 miles!
                            </strong>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>

              <CardFooter className="flex justify-between p-4 pt-0">
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => toggleFavorite(flight.id)}
                    className={favoriteFlights.includes(flight.id) ? "text-red-500" : ""}
                  >
                    <Heart className={`h-4 w-4 mr-2 ${favoriteFlights.includes(flight.id) ? "fill-red-500" : ""}`} />
                    {favoriteFlights.includes(flight.id) ? "Saved" : "Save"}
                  </Button>
                  <Link href="/alerts">
                    <Button variant="outline" size="sm">
                      <Bell className="h-4 w-4 mr-2" />
                      Track Price
                    </Button>
                  </Link>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedFlightId(selectedFlightId === flight.id ? null : flight.id)}
                  >
                    {selectedFlightId === flight.id ? "Hide Details" : "View Details"}
                  </Button>
                  <Link href={`/checkout/${flight.id}`}>
                    <Button size="sm" className={flight.aiRecommendation.isRecommended ? "bg-primary" : ""}>
                      {flight.aiRecommendation.isRecommended ? "Select Best" : "Select"}
                    </Button>
                  </Link>
                </div>
              </CardFooter>
            </Card>
          )
        })}
      </div>
    </TooltipProvider>
  )
}
