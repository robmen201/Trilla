"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { CreditCard, Info } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface PaymentOptionsProps {
  selectedCard?: string
  onCardChange?: (cardId: string) => void
}

export function PaymentOptions({ selectedCard = "chase", onCardChange }: PaymentOptionsProps) {
  const [internalSelectedCard, setInternalSelectedCard] = useState(selectedCard)

  useEffect(() => {
    setInternalSelectedCard(selectedCard)
  }, [selectedCard])

  const handleCardChange = (cardId: string) => {
    setInternalSelectedCard(cardId)
    onCardChange?.(cardId)
  }

  const cards = [
    {
      id: "chase",
      name: "Chase Sapphire Reserve",
      lastFour: "4567",
      points: "3x",
      pointsValue: 2550,
      pointsName: "Ultimate Rewards",
      pointsWorth: 0.02,
      recommendation: true,
      reason: "Highest overall value with 3x points on travel and 50% bonus when redeeming through Chase portal",
    },
    {
      id: "amex",
      name: "American Express Platinum",
      lastFour: "7890",
      points: "5x",
      pointsValue: 4250,
      pointsName: "Membership Rewards",
      pointsWorth: 0.018,
      recommendation: false,
      reason: "Highest points earning but lower redemption value for this specific airline",
    },
    {
      id: "citi",
      name: "Citi Premier",
      lastFour: "2345",
      points: "3x",
      pointsValue: 2550,
      pointsName: "ThankYou Points",
      pointsWorth: 0.016,
      recommendation: false,
      reason: "Good earning rate but fewer transfer partners for this route",
    },
  ]

  const recommendedCard = cards.find((card) => card.recommendation)

  return (
    <div className="space-y-6">
      <div className="bg-primary/10 p-4 rounded-lg border border-primary/20">
        <h3 className="font-medium mb-2 flex items-center">
          <CreditCard className="h-4 w-4 mr-2" />
          Card Recommendation
        </h3>
        <p className="text-sm">
          We recommend using your <strong>{recommendedCard?.name}</strong> for this purchase to maximize your rewards.
          You'll earn{" "}
          <strong>
            {recommendedCard?.pointsValue.toLocaleString()} {recommendedCard?.pointsName} points
          </strong>{" "}
          worth approximately{" "}
          <strong>${Math.round((recommendedCard?.pointsValue || 0) * (recommendedCard?.pointsWorth || 0))}</strong> when
          redeemed for travel.
        </p>
      </div>

      <RadioGroup value={internalSelectedCard} onValueChange={handleCardChange} className="space-y-3">
        {cards.map((card) => (
          <div
            key={card.id}
            className={`border rounded-lg p-4 ${internalSelectedCard === card.id ? "border-primary bg-primary/5" : ""}`}
          >
            <div className="flex items-start">
              <RadioGroupItem value={card.id} id={card.id} className="mt-1" />
              <div className="ml-3 flex-1">
                <div className="flex justify-between">
                  <Label htmlFor={card.id} className="font-medium">
                    {card.name}
                  </Label>
                  {card.recommendation && (
                    <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full">Recommended</span>
                  )}
                </div>
                <div className="text-sm text-muted-foreground mt-1">•••• {card.lastFour}</div>
                <div className="flex justify-between items-center mt-3">
                  <div className="text-sm">
                    <span className="font-medium">{card.points}</span> points on travel
                  </div>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-6 w-6">
                          <Info className="h-4 w-4" />
                          <span className="sr-only">Card info</span>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="max-w-xs text-xs">{card.reason}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <div className="mt-2 text-sm">
                  You'll earn <span className="font-medium">{card.pointsValue.toLocaleString()} points</span> worth
                  approximately <span className="font-medium">${Math.round(card.pointsValue * card.pointsWorth)}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </RadioGroup>

      <div className="pt-4 border-t">
        <Button className="w-full">Continue to Payment</Button>
      </div>
    </div>
  )
}

// Export the cards data for use in other components
export const creditCards = [
  {
    id: "chase",
    name: "Chase Sapphire Reserve",
    lastFour: "4567",
    points: "3x",
    pointsValue: 2550,
    pointsName: "Ultimate Rewards",
    pointsWorth: 0.02,
    recommendation: true,
  },
  {
    id: "amex",
    name: "American Express Platinum",
    lastFour: "7890",
    points: "5x",
    pointsValue: 4250,
    pointsName: "Membership Rewards",
    pointsWorth: 0.018,
    recommendation: false,
  },
  {
    id: "citi",
    name: "Citi Premier",
    lastFour: "2345",
    points: "3x",
    pointsValue: 2550,
    pointsName: "ThankYou Points",
    pointsWorth: 0.016,
    recommendation: false,
  },
]
