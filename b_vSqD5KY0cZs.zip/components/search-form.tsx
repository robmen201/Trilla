"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarIcon, Plane } from "lucide-react"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

export function SearchForm() {
  const router = useRouter()
  const [tripType, setTripType] = useState("round")
  const [departDate, setDepartDate] = useState<Date>()
  const [returnDate, setReturnDate] = useState<Date>()
  const [loyaltyPrograms, setLoyaltyPrograms] = useState<string[]>([])
  const [creditCards, setCreditCards] = useState<string[]>([])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, we would validate and process the form data
    router.push("/search-results")
  }

  return (
    <Card className="p-6">
      <Tabs defaultValue="flight" className="mb-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="flight">Flight</TabsTrigger>
          <TabsTrigger value="hotel">Hotel</TabsTrigger>
          <TabsTrigger value="car">Car Rental</TabsTrigger>
        </TabsList>
      </Tabs>

      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          <RadioGroup
            defaultValue="round"
            className="flex flex-wrap gap-4"
            onValueChange={(value) => setTripType(value)}
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="round" id="round" />
              <Label htmlFor="round">Round Trip</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="one" id="one" />
              <Label htmlFor="one">One Way</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="multi" id="multi" />
              <Label htmlFor="multi">Multi-City</Label>
            </div>
          </RadioGroup>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="from">From</Label>
              <Input id="from" placeholder="City or Airport" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="to">To</Label>
              <Input id="to" placeholder="City or Airport" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Depart</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn("w-full justify-start text-left font-normal", !departDate && "text-muted-foreground")}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {departDate ? format(departDate, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={departDate} onSelect={setDepartDate} initialFocus />
                </PopoverContent>
              </Popover>
            </div>
            {tripType === "round" && (
              <div className="space-y-2">
                <Label>Return</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !returnDate && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {returnDate ? format(returnDate, "PPP") : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={returnDate} onSelect={setReturnDate} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="passengers">Passengers</Label>
              <Select defaultValue="1">
                <SelectTrigger id="passengers">
                  <SelectValue placeholder="Passengers" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Passenger</SelectItem>
                  <SelectItem value="2">2 Passengers</SelectItem>
                  <SelectItem value="3">3 Passengers</SelectItem>
                  <SelectItem value="4">4 Passengers</SelectItem>
                  <SelectItem value="5">5+ Passengers</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="class">Class</Label>
              <Select defaultValue="economy">
                <SelectTrigger id="class">
                  <SelectValue placeholder="Class" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="economy">Economy</SelectItem>
                  <SelectItem value="premium">Premium Economy</SelectItem>
                  <SelectItem value="business">Business</SelectItem>
                  <SelectItem value="first">First</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="alliance">Airline Alliance</Label>
              <Select defaultValue="any">
                <SelectTrigger id="alliance">
                  <SelectValue placeholder="Alliance" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any">Any Alliance</SelectItem>
                  <SelectItem value="star">Star Alliance</SelectItem>
                  <SelectItem value="oneworld">Oneworld</SelectItem>
                  <SelectItem value="skyteam">SkyTeam</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Your Loyalty Programs</Label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {["American AAdvantage", "Delta SkyMiles", "United MileagePlus", "Southwest Rapid Rewards"].map(
                (program) => (
                  <Button
                    key={program}
                    type="button"
                    variant="outline"
                    className={cn("justify-start", loyaltyPrograms.includes(program) && "border-primary bg-primary/10")}
                    onClick={() => {
                      if (loyaltyPrograms.includes(program)) {
                        setLoyaltyPrograms(loyaltyPrograms.filter((p) => p !== program))
                      } else {
                        setLoyaltyPrograms([...loyaltyPrograms, program])
                      }
                    }}
                  >
                    {program}
                  </Button>
                ),
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Your Credit Cards</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {["Chase Sapphire", "Amex Platinum", "Capital One Venture", "Citi Premier", "Discover it Miles"].map(
                (card) => (
                  <Button
                    key={card}
                    type="button"
                    variant="outline"
                    className={cn("justify-start", creditCards.includes(card) && "border-primary bg-primary/10")}
                    onClick={() => {
                      if (creditCards.includes(card)) {
                        setCreditCards(creditCards.filter((c) => c !== card))
                      } else {
                        setCreditCards([...creditCards, card])
                      }
                    }}
                  >
                    {card}
                  </Button>
                ),
              )}
            </div>
          </div>

          <Button type="submit" className="w-full" size="lg">
            <Plane className="mr-2 h-4 w-4" />
            Search Flights
          </Button>
        </div>
      </form>
    </Card>
  )
}
