"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, CreditCard, Plane, Sparkles } from "lucide-react"

export function AutoBookingFlow({ flightId }: { flightId: string }) {
  const [bookingStep, setBookingStep] = useState(1)
  const [isProcessing, setIsProcessing] = useState(false)

  const steps = [
    { id: 1, name: "Confirming Best Option", icon: Sparkles },
    { id: 2, name: "Processing Payment", icon: CreditCard },
    { id: 3, name: "Booking Flight", icon: Plane },
    { id: 4, name: "Confirmation", icon: CheckCircle },
  ]

  const handleAutoBook = async () => {
    setIsProcessing(true)

    for (let i = 1; i <= 4; i++) {
      await new Promise((resolve) => setTimeout(resolve, 1500))
      setBookingStep(i)
    }

    setIsProcessing(false)
  }

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          Auto-Booking in Progress
        </CardTitle>
        <Progress value={(bookingStep / 4) * 100} className="mt-2" />
      </CardHeader>
      <CardContent className="space-y-4">
        {steps.map((step) => {
          const Icon = step.icon
          const isActive = bookingStep >= step.id
          const isCurrent = bookingStep === step.id

          return (
            <div
              key={step.id}
              className={`flex items-center gap-3 p-3 rounded-lg transition-all ${
                isActive ? "bg-primary/10 border border-primary/20" : "bg-muted/50"
              }`}
            >
              <div className={`p-2 rounded-full ${isActive ? "bg-primary text-white" : "bg-muted"}`}>
                <Icon className="h-4 w-4" />
              </div>
              <div className="flex-1">
                <div className={`font-medium ${isActive ? "text-primary" : "text-muted-foreground"}`}>{step.name}</div>
                {isCurrent && isProcessing && (
                  <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-primary"></div>
                    Processing...
                  </div>
                )}
              </div>
              {isActive && bookingStep > step.id && <CheckCircle className="h-5 w-5 text-green-600" />}
            </div>
          )
        })}

        {bookingStep === 4 ? (
          <div className="text-center space-y-4 pt-4">
            <CheckCircle className="h-12 w-12 text-green-600 mx-auto" />
            <div>
              <h3 className="font-bold text-lg">Booking Confirmed!</h3>
              <p className="text-sm text-muted-foreground">
                Your flight has been booked successfully. Confirmation details sent to your email.
              </p>
            </div>
            <Button className="w-full">View Booking Details</Button>
          </div>
        ) : (
          <Button className="w-full mt-4" onClick={handleAutoBook} disabled={isProcessing}>
            {isProcessing ? "Processing..." : "Start Auto-Booking"}
          </Button>
        )}
      </CardContent>
    </Card>
  )
}
