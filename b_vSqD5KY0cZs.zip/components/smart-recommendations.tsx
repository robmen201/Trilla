"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Sparkles, CreditCard, Plane, TrendingUp } from "lucide-react"

export function SmartRecommendations() {
  return (
    <div className="space-y-6">
      {/* Main Recommendation */}
      <Card className="border-primary bg-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            Perfect Match for Your Trip
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Plane className="h-4 w-4 text-blue-600" />
                <span className="font-medium">Flight</span>
              </div>
              <div className="text-sm text-muted-foreground">British Airways Business</div>
              <div className="font-bold">8:30 AM → 10:45 PM</div>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <CreditCard className="h-4 w-4 text-green-600" />
                <span className="font-medium">Payment</span>
              </div>
              <div className="text-sm text-muted-foreground">Use 120K Chase points</div>
              <div className="font-bold">Worth $3,200</div>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-4 w-4 text-purple-600" />
                <span className="font-medium">Savings</span>
              </div>
              <div className="text-sm text-muted-foreground">vs paying cash</div>
              <div className="font-bold text-green-600">Save $850</div>
            </div>
          </div>
          <Button className="w-full" size="lg">
            Book This Perfect Match
          </Button>
        </CardContent>
      </Card>

      {/* Quick Insights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <Badge variant="outline" className="mb-2">
              Loyalty Tip
            </Badge>
            <p className="text-sm">Your Gold status gets you free seat selection worth $45</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <Badge variant="outline" className="mb-2">
              Credit Card
            </Badge>
            <p className="text-sm">Chase Sapphire Reserve earns 3x points = 2,550 extra points</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <Badge variant="outline" className="mb-2">
              Price Alert
            </Badge>
            <p className="text-sm">Prices for this route typically increase 20% closer to departure</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
