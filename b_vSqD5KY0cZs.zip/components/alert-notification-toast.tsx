"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { X, TrendingDown, Plane, Bell } from "lucide-react"

interface NotificationToast {
  id: string
  title: string
  message: string
  savings: number
  type: "price_drop" | "award_availability" | "urgent"
  duration?: number
}

export function AlertNotificationToast() {
  const [notifications, setNotifications] = useState<NotificationToast[]>([])

  // Simulate incoming notifications
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.98) {
        // 2% chance every 5 seconds
        const newNotification: NotificationToast = {
          id: Date.now().toString(),
          title: "Price Drop Alert!",
          message: "British Airways Business Class dropped $180",
          savings: 180,
          type: "price_drop",
          duration: 8000,
        }

        setNotifications((prev) => [...prev, newNotification])

        // Auto-remove after duration
        setTimeout(() => {
          setNotifications((prev) => prev.filter((n) => n.id !== newNotification.id))
        }, newNotification.duration || 5000)
      }
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const removeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id))
  }

  const getIcon = (type: NotificationToast["type"]) => {
    switch (type) {
      case "price_drop":
        return <TrendingDown className="h-4 w-4 text-green-600" />
      case "award_availability":
        return <Plane className="h-4 w-4 text-blue-600" />
      case "urgent":
        return <Bell className="h-4 w-4 text-red-600" />
      default:
        return <Bell className="h-4 w-4" />
    }
  }

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2 max-w-sm">
      {notifications.map((notification) => (
        <Card
          key={notification.id}
          className="p-4 shadow-lg border-l-4 border-l-primary bg-white animate-in slide-in-from-right duration-300"
        >
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3 flex-1">
              {getIcon(notification.type)}
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h4 className="font-medium text-sm">{notification.title}</h4>
                  <Badge variant="default" className="bg-primary text-xs">
                    New
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground mb-2">{notification.message}</p>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-green-600 border-green-200 bg-green-50 text-xs">
                    Save ${notification.savings}
                  </Badge>
                  <Button size="sm" className="h-6 text-xs px-2">
                    View Deal
                  </Button>
                </div>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
              onClick={() => removeNotification(notification.id)}
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
        </Card>
      ))}
    </div>
  )
}
