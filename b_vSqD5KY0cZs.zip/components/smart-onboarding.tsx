"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, CreditCard, Plane, User, Sparkles } from "lucide-react"

export function SmartOnboarding() {
  const [step, setStep] = useState(1)
  const [preferences, setPreferences] = useState({
    loyaltyPrograms: [] as string[],
    creditCards: [] as string[],
    travelStyle: "",
    budget: "",
  })

  const totalSteps = 4
  const progress = (step / totalSteps) * 100

  return (
    <div className="max-w-2xl mx-auto">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              Quick Setup for Better Recommendations
            </CardTitle>
            <Badge variant="outline">
              {step} of {totalSteps}
            </Badge>
          </div>
          <Progress value={progress} className="mt-2" />
        </CardHeader>
        <CardContent className="space-y-6">
          {step === 1 && (
            <div>
              <h3 className="font-medium mb-4 flex items-center gap-2">
                <Plane className="h-4 w-4" />
                Which loyalty programs do you have?
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {["American AAdvantage", "Delta SkyMiles", "United MileagePlus", "British Airways Avios"].map(
                  (program) => (
                    <Button
                      key={program}
                      variant={preferences.loyaltyPrograms.includes(program) ? "default" : "outline"}
                      className="justify-start h-auto p-3"
                      onClick={() => {
                        const updated = preferences.loyaltyPrograms.includes(program)
                          ? preferences.loyaltyPrograms.filter((p) => p !== program)
                          : [...preferences.loyaltyPrograms, program]
                        setPreferences({ ...preferences, loyaltyPrograms: updated })
                      }}
                    >
                      <div className="text-left">
                        <div className="font-medium">{program}</div>
                        <div className="text-xs opacity-70">Auto-detect status & miles</div>
                      </div>
                    </Button>
                  ),
                )}
              </div>
            </div>
          )}

          {step === 2 && (
            <div>
              <h3 className="font-medium mb-4 flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                Which credit cards do you use for travel?
              </h3>
              <div className="grid grid-cols-1 gap-3">
                {[
                  { name: "Chase Sapphire Reserve", bonus: "3x on travel", color: "blue" },
                  { name: "Amex Platinum", bonus: "5x on flights", color: "green" },
                  { name: "Capital One Venture X", bonus: "2x on everything", color: "red" },
                  { name: "Citi Premier", bonus: "3x on air travel", color: "purple" },
                ].map((card) => (
                  <Button
                    key={card.name}
                    variant={preferences.creditCards.includes(card.name) ? "default" : "outline"}
                    className="justify-start h-auto p-4"
                    onClick={() => {
                      const updated = preferences.creditCards.includes(card.name)
                        ? preferences.creditCards.filter((c) => c !== card.name)
                        : [...preferences.creditCards, card.name]
                      setPreferences({ ...preferences, creditCards: updated })
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full bg-${card.color}-500`}></div>
                      <div className="text-left">
                        <div className="font-medium">{card.name}</div>
                        <div className="text-xs opacity-70">{card.bonus}</div>
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          )}

          {step === 3 && (
            <div>
              <h3 className="font-medium mb-4 flex items-center gap-2">
                <User className="h-4 w-4" />
                What's your travel style?
              </h3>
              <div className="grid grid-cols-1 gap-3">
                {[
                  { style: "Budget Conscious", desc: "Always looking for the best deals" },
                  { style: "Comfort Focused", desc: "Prefer premium economy or business" },
                  { style: "Miles Maximizer", desc: "Optimize for earning and burning miles" },
                  { style: "Time Saver", desc: "Convenience over cost savings" },
                ].map((option) => (
                  <Button
                    key={option.style}
                    variant={preferences.travelStyle === option.style ? "default" : "outline"}
                    className="justify-start h-auto p-4"
                    onClick={() => setPreferences({ ...preferences, travelStyle: option.style })}
                  >
                    <div className="text-left">
                      <div className="font-medium">{option.style}</div>
                      <div className="text-xs opacity-70">{option.desc}</div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="text-center space-y-4">
              <CheckCircle className="h-16 w-16 text-green-600 mx-auto" />
              <h3 className="font-bold text-xl">All Set!</h3>
              <p className="text-muted-foreground">
                We'll now provide personalized recommendations based on your preferences. You can always adjust these
                settings later.
              </p>
              <div className="bg-primary/10 p-4 rounded-lg">
                <h4 className="font-medium mb-2">Your Profile:</h4>
                <div className="text-sm space-y-1">
                  <div>Loyalty Programs: {preferences.loyaltyPrograms.length} connected</div>
                  <div>Credit Cards: {preferences.creditCards.length} added</div>
                  <div>Travel Style: {preferences.travelStyle}</div>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-between pt-4">
            {step > 1 && (
              <Button variant="outline" onClick={() => setStep(step - 1)}>
                Previous
              </Button>
            )}
            <div className="flex-1"></div>
            {step < totalSteps ? (
              <Button onClick={() => setStep(step + 1)}>Next</Button>
            ) : (
              <Button className="bg-primary">Start Finding Flights</Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
