"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import {
  Bell,
  TrendingDown,
  TrendingUp,
  Plane,
  CreditCard,
  Calendar,
  DollarSign,
  Sparkles,
  X,
  Settings,
} from "lucide-react"

interface PriceAlert {
  id: string
  type: "price_drop" | "award_availability" | "upgrade_deal" | "credit_card_bonus" | "status_benefit"
  title: string
  message: string
  savings: number
  urgency: "low" | "medium" | "high"
  timestamp: Date
  flightId?: string
  actionable: boolean
  read: boolean
}

// Mock alerts data
const mockAlerts: PriceAlert[] = [
  {
    id: "1",
    type: "price_drop",
    title: "Price Drop Alert: JFK → LHR",
    message: "British Airways Business Class dropped $320 since you searched. Now $2,880 (was $3,200)",
    savings: 320,
    urgency: "high",
    timestamp: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
    flightId: "1",
    actionable: true,
    read: false,
  },
  {
    id: "2",
    type: "award_availability",
    title: "Award Space Opened: Virgin Atlantic",
    message: "Upper Class award seats now available for 110K points (previously unavailable)",
    savings: 1200,
    urgency: "high",
    timestamp: new Date(Date.now() - 1000 * 60 * 45), // 45 minutes ago
    flightId: "4",
    actionable: true,
    read: false,
  },
  {
    id: "3",
    type: "credit_card_bonus",
    title: "Limited Time: Chase Sapphire Bonus",
    message: "5x points on travel (normally 3x) through this weekend. Book now to maximize rewards!",
    savings: 850,
    urgency: "medium",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
    actionable: true,
    read: false,
  },
  {
    id: "4",
    type: "upgrade_deal",
    title: "Upgrade Opportunity: American Airlines",
    message: "Premium Economy upgrade available for $180 (normally $400). Your Gold status qualifies.",
    savings: 220,
    urgency: "medium",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 4), // 4 hours ago
    flightId: "2",
    actionable: true,
    read: true,
  },
  {
    id: "5",
    type: "status_benefit",
    title: "Status Benefit Reminder",
    message: "Your Oneworld Gold status includes free seat selection on this route (saves $45)",
    savings: 45,
    urgency: "low",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 6), // 6 hours ago
    actionable: false,
    read: true,
  },
]

export function PriceAlerts() {
  const [alerts, setAlerts] = useState<PriceAlert[]>(mockAlerts)
  const [showSettings, setShowSettings] = useState(false)
  const [alertSettings, setAlertSettings] = useState({
    priceDrops: true,
    awardAvailability: true,
    upgrades: true,
    creditCardDeals: true,
    statusBenefits: false,
    priceThreshold: 50,
    emailNotifications: true,
    pushNotifications: true,
  })

  const unreadCount = alerts.filter((alert) => !alert.read).length

  const markAsRead = (alertId: string) => {
    setAlerts(alerts.map((alert) => (alert.id === alertId ? { ...alert, read: true } : alert)))
  }

  const dismissAlert = (alertId: string) => {
    setAlerts(alerts.filter((alert) => alert.id !== alertId))
  }

  const getAlertIcon = (type: PriceAlert["type"]) => {
    switch (type) {
      case "price_drop":
        return <TrendingDown className="h-4 w-4 text-green-600" />
      case "award_availability":
        return <Plane className="h-4 w-4 text-blue-600" />
      case "upgrade_deal":
        return <TrendingUp className="h-4 w-4 text-purple-600" />
      case "credit_card_bonus":
        return <CreditCard className="h-4 w-4 text-orange-600" />
      case "status_benefit":
        return <Sparkles className="h-4 w-4 text-yellow-600" />
      default:
        return <Bell className="h-4 w-4" />
    }
  }

  const getUrgencyColor = (urgency: PriceAlert["urgency"]) => {
    switch (urgency) {
      case "high":
        return "border-red-200 bg-red-50"
      case "medium":
        return "border-orange-200 bg-orange-50"
      case "low":
        return "border-blue-200 bg-blue-50"
      default:
        return "border-gray-200 bg-gray-50"
    }
  }

  const formatTimeAgo = (timestamp: Date) => {
    const now = new Date()
    const diffInMinutes = Math.floor((now.getTime() - timestamp.getTime()) / (1000 * 60))

    if (diffInMinutes < 60) {
      return `${diffInMinutes}m ago`
    } else if (diffInMinutes < 1440) {
      return `${Math.floor(diffInMinutes / 60)}h ago`
    } else {
      return `${Math.floor(diffInMinutes / 1440)}d ago`
    }
  }

  // Simulate new alerts coming in
  useEffect(() => {
    const interval = setInterval(() => {
      // Randomly add new alerts (for demo purposes)
      if (Math.random() > 0.95) {
        const newAlert: PriceAlert = {
          id: Date.now().toString(),
          type: "price_drop",
          title: "New Price Drop Alert",
          message: "Delta Air Lines Economy dropped $45 since your last search",
          savings: 45,
          urgency: "medium",
          timestamp: new Date(),
          actionable: true,
          read: false,
        }
        setAlerts((prev) => [newAlert, ...prev])
      }
    }, 30000) // Check every 30 seconds

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-y-4">
      {/* Alert Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Smart Alerts
              {unreadCount > 0 && (
                <Badge variant="destructive" className="animate-pulse">
                  {unreadCount} new
                </Badge>
              )}
            </CardTitle>
            <Button variant="outline" size="sm" onClick={() => setShowSettings(!showSettings)}>
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
          </div>
        </CardHeader>
        {showSettings && (
          <CardContent className="border-t">
            <div className="space-y-4">
              <h3 className="font-medium">Alert Preferences</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="price-drops">Price Drops</Label>
                    <Switch
                      id="price-drops"
                      checked={alertSettings.priceDrops}
                      onCheckedChange={(checked) => setAlertSettings({ ...alertSettings, priceDrops: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="award-availability">Award Availability</Label>
                    <Switch
                      id="award-availability"
                      checked={alertSettings.awardAvailability}
                      onCheckedChange={(checked) => setAlertSettings({ ...alertSettings, awardAvailability: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="upgrades">Upgrade Deals</Label>
                    <Switch
                      id="upgrades"
                      checked={alertSettings.upgrades}
                      onCheckedChange={(checked) => setAlertSettings({ ...alertSettings, upgrades: checked })}
                    />
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="credit-deals">Credit Card Deals</Label>
                    <Switch
                      id="credit-deals"
                      checked={alertSettings.creditCardDeals}
                      onCheckedChange={(checked) => setAlertSettings({ ...alertSettings, creditCardDeals: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="status-benefits">Status Benefits</Label>
                    <Switch
                      id="status-benefits"
                      checked={alertSettings.statusBenefits}
                      onCheckedChange={(checked) => setAlertSettings({ ...alertSettings, statusBenefits: checked })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="price-threshold">Min. Savings Threshold</Label>
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4" />
                      <Input
                        id="price-threshold"
                        type="number"
                        value={alertSettings.priceThreshold}
                        onChange={(e) => setAlertSettings({ ...alertSettings, priceThreshold: Number(e.target.value) })}
                        className="w-20"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Active Alerts */}
      <div className="space-y-3">
        {alerts.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center">
              <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-medium mb-2">No alerts yet</h3>
              <p className="text-sm text-muted-foreground">
                We'll notify you when better deals become available for your searches.
              </p>
            </CardContent>
          </Card>
        ) : (
          alerts.map((alert) => (
            <Card
              key={alert.id}
              className={`${getUrgencyColor(alert.urgency)} ${!alert.read ? "border-l-4 border-l-primary" : ""}`}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    <div className="mt-1">{getAlertIcon(alert.type)}</div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className={`font-medium ${!alert.read ? "text-primary" : ""}`}>{alert.title}</h3>
                        {!alert.read && (
                          <Badge variant="default" className="bg-primary text-xs">
                            New
                          </Badge>
                        )}
                        {alert.urgency === "high" && (
                          <Badge variant="destructive" className="text-xs animate-pulse">
                            Urgent
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{alert.message}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {formatTimeAgo(alert.timestamp)}
                        </div>
                        {alert.savings > 0 && (
                          <div className="flex items-center gap-1 text-green-600 font-medium">
                            <TrendingDown className="h-3 w-3" />
                            Save ${alert.savings}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 ml-4">
                    {alert.actionable && (
                      <Button size="sm" onClick={() => markAsRead(alert.id)} className="bg-primary hover:bg-primary/90">
                        {alert.flightId ? "View Flight" : "Take Action"}
                      </Button>
                    )}
                    <Button variant="ghost" size="sm" onClick={() => dismissAlert(alert.id)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Alert Summary */}
      {alerts.length > 0 && (
        <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-green-800">Total Potential Savings</h3>
                <p className="text-2xl font-bold text-green-600">
                  ${alerts.reduce((sum, alert) => sum + alert.savings, 0)}
                </p>
                <p className="text-sm text-green-700">
                  From {alerts.filter((a) => a.actionable).length} actionable alerts
                </p>
              </div>
              <div className="text-right">
                <Button className="bg-green-600 hover:bg-green-700">Review All Deals</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
