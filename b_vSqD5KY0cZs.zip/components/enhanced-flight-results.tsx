"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  ArrowRight,
  CreditCard,
  Heart,
  Plane,
  Sparkles,
  TrendingUp,
  Clock,
  Bell,
  Check,
  DollarSign,
  Zap,
} from "lucide-react"
import Link from "next/link"
import { AlertNotificationToast } from "./alert-notification-toast"

// Enhanced flight data with AI recommendations
const flights = [
  {
    id: "1",
    airline: "British Airways",
    alliance: "Oneworld",
    departTime: "8:30 AM",
    arriveTime: "10:45 PM",
    duration: "7h 15m",
    stops: 0,
    aiRecommendation: {
      isRecommended: true,
      score: 98,
      reason: "Best value redemption + your Gold status benefits",
      savings: 850,
      urgency: "high",
      priceChange: 120,
      preferredMethod: "miles" as "cash" | "miles",
      cashVsMilesAdvice: "Use miles - exceptional 2.67¢ value!",
    },
    cabins: {
      economy: {
        name: "Economy Basic",
        price: 850,
        milesPrice: 60000,
        milesValue: 1.42,
        potentialMiles: 3458,
        statusMultiplier: 1.0,
        benefits: ["Personal item", "Seat selection for fee", "Standard meal"],
        baggage: "Carry-on: $35, Checked: $60",
      },
      premium: {
        name: "Premium Economy",
        price: 1250,
        milesPrice: 85000,
        milesValue: 1.47,
        potentialMiles: 5187,
        statusMultiplier: 1.25,
        benefits: ["Priority boarding", "Extra legroom", "Premium meal", "Free checked bag"],
        baggage: "Carry-on: Free, Checked: Free (1 bag)",
      },
      business: {
        name: "Business Class",
        price: 3200,
        milesPrice: 120000,
        milesValue: 2.67,
        potentialMiles: 10374,
        statusMultiplier: 2.0,
        benefits: ["Lie-flat seat", "Lounge access", "Premium dining", "Priority everything"],
        baggage: "Carry-on: Free, Checked: Free (2 bags)",
      },
    },
    bestCreditCard: "Chase Sapphire Reserve",
    cardBonus: "3x",
  },
  {
    id: "2",
    airline: "American Airlines",
    alliance: "Oneworld",
    departTime: "10:15 AM",
    arriveTime: "11:30 PM",
    duration: "7h 15m",
    stops: 0,
    aiRecommendation: {
      isRecommended: false,
      score: 75,
      reason: "Good option but lower value than top choice",
      savings: 320,
      urgency: "medium",
      priceChange: -25,
      preferredMethod: "cash" as "cash" | "miles",
      cashVsMilesAdvice: "Pay cash - poor miles value at 1.2¢",
    },
    cabins: {
      economy: {
        name: "Main Cabin",
        price: 780,
        milesPrice: 65000,
        milesValue: 1.2,
        potentialMiles: 3458,
        statusMultiplier: 1.0,
        benefits: ["Personal item", "Seat selection for fee", "Complimentary snacks"],
        baggage: "Carry-on: Free, Checked: $30",
      },
      premium: {
        name: "Premium Economy",
        price: 1180,
        milesPrice: 90000,
        milesValue: 1.31,
        potentialMiles: 5187,
        statusMultiplier: 1.5,
        benefits: ["Priority boarding", "Extra legroom", "Free drinks", "Free checked bag"],
        baggage: "Carry-on: Free, Checked: Free (1 bag)",
      },
      business: {
        name: "Business Class",
        price: 2950,
        milesPrice: 115000,
        milesValue: 2.57,
        potentialMiles: 10374,
        statusMultiplier: 2.0,
        benefits: ["Lie-flat seat", "Flagship Lounge", "Premium dining", "Priority check-in"],
        baggage: "Carry-on: Free, Checked: Free (2 bags)",
      },
    },
    bestCreditCard: "Citi AAdvantage",
    cardBonus: "2x",
  },
  {
    id: "3",
    airline: "Delta Air Lines",
    alliance: "SkyTeam",
    departTime: "1:45 PM",
    arriveTime: "3:20 AM",
    duration: "7h 35m",
    stops: 0,
    aiRecommendation: {
      isRecommended: false,
      score: 68,
      reason: "Decent option but not optimal for your profile",
      savings: 180,
      urgency: "low",
      priceChange: 45,
      preferredMethod: "cash" as "cash" | "miles",
      cashVsMilesAdvice: "Pay cash - below average miles value",
    },
    cabins: {
      economy: {
        name: "Main Cabin",
        price: 795,
        milesPrice: 70000,
        milesValue: 1.14,
        potentialMiles: 3458,
        statusMultiplier: 1.0,
        benefits: ["Personal item", "Seat selection for fee", "Complimentary snacks"],
        baggage: "Carry-on: Free, Checked: $30",
      },
      premium: {
        name: "Comfort+",
        price: 1195,
        milesPrice: 95000,
        milesValue: 1.26,
        potentialMiles: 5187,
        statusMultiplier: 1.5,
        benefits: ["Priority boarding", "Extra legroom", "Free drinks", "Sky Priority"],
        baggage: "Carry-on: Free, Checked: Free (1 bag)",
      },
      business: {
        name: "Delta One",
        price: 3100,
        milesPrice: 125000,
        milesValue: 2.48,
        potentialMiles: 10374,
        statusMultiplier: 2.0,
        benefits: ["Lie-flat suite", "Sky Club access", "Chef-curated meals", "Premium amenities"],
        baggage: "Carry-on: Free, Checked: Free (2 bags)",
      },
    },
    bestCreditCard: "Amex Platinum",
    cardBonus: "5x",
  },
  {
    id: "4",
    airline: "Virgin Atlantic",
    alliance: "None",
    departTime: "7:30 PM",
    arriveTime: "9:45 AM",
    duration: "8h 15m",
    stops: 0,
    aiRecommendation: {
      isRecommended: true,
      score: 92,
      reason: "Excellent premium value with your Amex points",
      savings: 1200,
      urgency: "high",
      priceChange: 200,
      preferredMethod: "miles" as "cash" | "miles",
      cashVsMilesAdvice: "Transfer Amex points - fantastic 2.59¢ value!",
    },
    cabins: {
      economy: {
        name: "Economy",
        price: 760,
        milesPrice: 55000,
        milesValue: 1.38,
        potentialMiles: 3458,
        statusMultiplier: 1.0,
        benefits: ["Personal item", "Seat selection for fee", "Complimentary meal"],
        baggage: "Carry-on: Free, Checked: $25",
      },
      premium: {
        name: "Premium",
        price: 1150,
        milesPrice: 80000,
        milesValue: 1.44,
        potentialMiles: 5187,
        statusMultiplier: 1.5,
        benefits: ["Priority check-in", "Extra legroom", "Premium meal", "Free bar"],
        baggage: "Carry-on: Free, Checked: Free (1 bag)",
      },
      business: {
        name: "Upper Class",
        price: 2850,
        milesPrice: 110000,
        milesValue: 2.59,
        potentialMiles: 10374,
        statusMultiplier: 2.0,
        benefits: ["Lie-flat seat", "Clubhouse access", "Premium dining", "Onboard bar"],
        baggage: "Carry-on: Free, Checked: Free (2 bags)",
      },
    },
    bestCreditCard: "Amex Gold",
    cardBonus: "3x",
  },
]

export function EnhancedFlightResults() {
  const [selectedFlightId, setSelectedFlightId] = useState<string | null>(null)
  const [favoriteFlights, setFavoriteFlights] = useState<string[]>([])
  const [selectedCabin, setSelectedCabin] = useState<{ [key: string]: string }>({})
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<{ [key: string]: "cash" | "miles" }>({})

  const toggleFavorite = (id: string) => {
    if (favoriteFlights.includes(id)) {
      setFavoriteFlights(favoriteFlights.filter((flightId) => flightId !== id))
    } else {
      setFavoriteFlights([...favoriteFlights, id])
    }
  }

  const getSelectedCabinData = (flight: (typeof flights)[0]) => {
    const cabinKey = selectedCabin[flight.id] || "economy"
    return flight.cabins[cabinKey as keyof typeof flight.cabins]
  }

  const selectPaymentMethod = (flightId: string, method: "cash" | "miles") => {
    setSelectedPaymentMethod({ ...selectedPaymentMethod, [flightId]: method })
  }

  // Sort flights to show recommended ones first
  const sortedFlights = [...flights].sort((a, b) => {
    if (a.aiRecommendation.isRecommended && !b.aiRecommendation.isRecommended) return -1
    if (!a.aiRecommendation.isRecommended && b.aiRecommendation.isRecommended) return 1
    return b.aiRecommendation.score - a.aiRecommendation.score
  })

  return (
    <div className="space-y-4">
      <AlertNotificationToast />

      {/* AI Insights Header */}
      <Card className="bg-gradient-to-r from-primary/5 to-blue/5 border-primary/20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="h-5 w-5 text-primary" />
                <span className="font-medium">AI Travel Assistant</span>
              </div>
              <p className="text-sm text-muted-foreground">
                See both cash and miles prices for every flight, with personalized recommendations based on your
                profile.
              </p>
            </div>
            <Link href="/alerts">
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                Set Up Alerts
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      {sortedFlights.map((flight, index) => {
        const currentCabin = getSelectedCabinData(flight)
        const isTopRecommendation = flight.aiRecommendation.isRecommended && index === 0
        const userSelectedMethod = selectedPaymentMethod[flight.id]
        const aiPreferredMethod = flight.aiRecommendation.preferredMethod

        return (
          <Card
            key={flight.id}
            className={`${selectedFlightId === flight.id ? "border-primary" : ""} ${
              flight.aiRecommendation.isRecommended ? "border-l-4 border-l-primary shadow-md" : ""
            }`}
          >
            <CardContent className="p-6">
              {/* AI Recommendation Banner */}
              {flight.aiRecommendation.isRecommended && (
                <div className="mb-4 p-3 bg-primary/10 border border-primary/20 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-primary" />
                      <span className="font-medium text-primary">
                        {isTopRecommendation ? "🎯 Best Match" : "⭐ Great Option"}
                      </span>
                      <Badge variant="default" className="bg-primary">
                        {flight.aiRecommendation.score}% Match
                      </Badge>
                    </div>
                    {flight.aiRecommendation.urgency === "high" && (
                      <Badge variant="destructive" className="animate-pulse">
                        <Clock className="h-3 w-3 mr-1" />
                        Book Soon
                      </Badge>
                    )}
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <p className="text-sm text-primary/80">{flight.aiRecommendation.reason}</p>
                    <div className="flex items-center gap-1">
                      <TrendingUp className="h-3 w-3 text-green-600" />
                      <span className="text-sm font-medium text-green-600">
                        Save ${flight.aiRecommendation.savings}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Price Change Alert */}
              {flight.aiRecommendation.priceChange > 0 && (
                <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-lg flex items-center gap-2">
                  <Clock className="h-4 w-4 text-orange-600" />
                  <span className="text-sm text-orange-700">
                    Price increased ${flight.aiRecommendation.priceChange} since yesterday
                  </span>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {/* Flight Info */}
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                    <Plane className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="font-medium">{flight.airline}</div>
                    <div className="text-sm text-muted-foreground">{flight.alliance}</div>
                  </div>
                </div>

                {/* Flight Times */}
                <div className="flex items-center justify-center">
                  <div className="text-center">
                    <div className="font-medium">{flight.departTime}</div>
                    <div className="text-sm text-muted-foreground">JFK</div>
                  </div>
                  <div className="mx-2 md:mx-4 flex flex-col items-center">
                    <div className="text-xs text-muted-foreground mb-1">{flight.duration}</div>
                    <div className="relative w-16 md:w-24">
                      <div className="border-t border-dashed border-gray-300 absolute w-full top-1/2"></div>
                      <ArrowRight className="h-3 w-3 absolute right-0 top-1/2 -translate-y-1/2" />
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {flight.stops === 0 ? "Nonstop" : `${flight.stops} stop`}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="font-medium">{flight.arriveTime}</div>
                    <div className="text-sm text-muted-foreground">LHR</div>
                  </div>
                </div>

                {/* Revolutionary Dual-Price Display */}
                <div className="md:col-span-2">
                  <div className="grid grid-cols-2 gap-3">
                    {/* Cash Option */}
                    <div
                      className={`relative p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        userSelectedMethod === "cash" || (!userSelectedMethod && aiPreferredMethod === "cash")
                          ? "border-green-500 bg-green-50 shadow-md"
                          : "border-gray-200 bg-white hover:border-green-300"
                      }`}
                      onClick={() => selectPaymentMethod(flight.id, "cash")}
                    >
                      {/* AI Recommendation Badge */}
                      {aiPreferredMethod === "cash" && (
                        <div className="absolute -top-2 -right-2">
                          <Badge className="bg-green-600 text-white text-xs animate-pulse">
                            <Zap className="h-3 w-3 mr-1" />
                            AI Pick
                          </Badge>
                        </div>
                      )}

                      <div className="flex items-center gap-2 mb-2">
                        <DollarSign className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-green-800">Pay Cash</span>
                      </div>

                      <div className="text-2xl font-bold text-green-700">${currentCabin.price}</div>
                      <div className="text-xs text-green-600 mb-2">
                        + Earn {currentCabin.potentialMiles.toLocaleString()} miles
                      </div>

                      <div className="text-xs text-green-600 font-medium">💳 Best with {flight.bestCreditCard}</div>
                      <div className="text-xs text-green-600">
                        +{Math.round(currentCabin.price * Number.parseInt(flight.cardBonus)).toLocaleString()} points
                      </div>
                    </div>

                    {/* Miles Option */}
                    <div
                      className={`relative p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        userSelectedMethod === "miles" || (!userSelectedMethod && aiPreferredMethod === "miles")
                          ? "border-blue-500 bg-blue-50 shadow-md"
                          : "border-gray-200 bg-white hover:border-blue-300"
                      }`}
                      onClick={() => selectPaymentMethod(flight.id, "miles")}
                    >
                      {/* AI Recommendation Badge */}
                      {aiPreferredMethod === "miles" && (
                        <div className="absolute -top-2 -right-2">
                          <Badge className="bg-blue-600 text-white text-xs animate-pulse">
                            <Zap className="h-3 w-3 mr-1" />
                            AI Pick
                          </Badge>
                        </div>
                      )}

                      <div className="flex items-center gap-2 mb-2">
                        <Plane className="h-4 w-4 text-blue-600" />
                        <span className="font-medium text-blue-800">Use Miles</span>
                      </div>

                      <div className="text-2xl font-bold text-blue-700">{currentCabin.milesPrice.toLocaleString()}</div>
                      <div className="text-xs text-blue-600 mb-2">
                        miles + ${Math.round(currentCabin.price * 0.1)} taxes
                      </div>

                      <div className="text-xs text-blue-600 font-medium">
                        💎 Value: {currentCabin.milesValue}¢ per mile
                      </div>
                      <div className={`text-xs ${currentCabin.milesValue > 1.3 ? "text-blue-600" : "text-orange-600"}`}>
                        {currentCabin.milesValue > 1.3 ? "✨ Great value!" : "⚠️ Below average"}
                      </div>
                    </div>
                  </div>

                  {/* AI Advice */}
                  <div className="mt-3 p-2 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-200">
                    <div className="flex items-center gap-2">
                      <Sparkles className="h-3 w-3 text-purple-600" />
                      <span className="text-xs font-medium text-purple-800">AI Advice:</span>
                    </div>
                    <p className="text-xs text-purple-700 mt-1">{flight.aiRecommendation.cashVsMilesAdvice}</p>
                  </div>
                </div>
              </div>

              {/* Additional Info Badges */}
              <div className="mt-4 flex flex-wrap gap-2">
                <Badge variant="outline" className="text-xs">
                  {currentCabin.name}
                </Badge>
                {flight.aiRecommendation.isRecommended && (
                  <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 text-xs">
                    <Sparkles className="h-3 w-3 mr-1" />
                    Top Choice
                  </Badge>
                )}
                {currentCabin.milesValue > 1.5 && (
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 text-xs">
                    🏆 Excellent Miles Value
                  </Badge>
                )}
              </div>

              {selectedFlightId === flight.id && (
                <div className="mt-6 pt-6 border-t">
                  <Tabs defaultValue="cabins">
                    <TabsList className="mb-4">
                      <TabsTrigger value="cabins">Cabin Options</TabsTrigger>
                      <TabsTrigger value="card">Best Card</TabsTrigger>
                    </TabsList>

                    <TabsContent value="cabins" className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.entries(flight.cabins).map(([cabinKey, cabin]) => (
                          <Card
                            key={cabinKey}
                            className={`cursor-pointer transition-all ${
                              (selectedCabin[flight.id] || "economy") === cabinKey
                                ? "border-primary bg-primary/5"
                                : "hover:border-gray-300"
                            }`}
                            onClick={() => setSelectedCabin({ ...selectedCabin, [flight.id]: cabinKey })}
                          >
                            <CardContent className="p-4">
                              <div className="flex justify-between items-start mb-3">
                                <div>
                                  <h3 className="font-medium">{cabin.name}</h3>
                                  <div className="text-sm text-muted-foreground capitalize">{cabinKey} Class</div>
                                </div>
                                {(selectedCabin[flight.id] || "economy") === cabinKey && (
                                  <Badge variant="default" className="bg-primary">
                                    Selected
                                  </Badge>
                                )}
                              </div>

                              <div className="grid grid-cols-2 gap-4 mb-4">
                                <div>
                                  <div className="text-lg font-bold">${cabin.price}</div>
                                  <div className="text-xs text-muted-foreground">Cash price</div>
                                </div>
                                <div>
                                  <div className="text-lg font-bold">{cabin.milesPrice.toLocaleString()}</div>
                                  <div className="text-xs text-muted-foreground">Miles needed</div>
                                </div>
                              </div>

                              <div className="space-y-1">
                                {cabin.benefits.slice(0, 2).map((benefit, index) => (
                                  <div key={index} className="flex items-center gap-2 text-xs">
                                    <Check className="h-3 w-3 text-green-600" />
                                    <span>{benefit}</span>
                                  </div>
                                ))}
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </TabsContent>

                    <TabsContent value="card" className="space-y-4">
                      <div className="bg-muted/50 p-4 rounded-lg">
                        <h3 className="font-medium mb-2 flex items-center">
                          <CreditCard className="h-4 w-4 mr-1" />
                          Best Card for This Purchase
                        </h3>
                        <div className="flex items-center gap-3 mt-3">
                          <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                          <div>
                            <div className="font-medium">{flight.bestCreditCard}</div>
                            <div className="text-sm text-muted-foreground">{flight.cardBonus} points on travel</div>
                            <div className="text-sm font-medium">
                              Earn {Math.round(currentCabin.price * Number.parseInt(flight.cardBonus)).toLocaleString()}{" "}
                              points
                            </div>
                          </div>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between p-4 pt-0">
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => toggleFavorite(flight.id)}
                  className={favoriteFlights.includes(flight.id) ? "text-red-500" : ""}
                >
                  <Heart className={`h-4 w-4 mr-2 ${favoriteFlights.includes(flight.id) ? "fill-red-500" : ""}`} />
                  {favoriteFlights.includes(flight.id) ? "Saved" : "Save"}
                </Button>
                <Link href="/alerts">
                  <Button variant="outline" size="sm">
                    <Bell className="h-4 w-4 mr-2" />
                    Track Price
                  </Button>
                </Link>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedFlightId(selectedFlightId === flight.id ? null : flight.id)}
                >
                  {selectedFlightId === flight.id ? "Hide Details" : "View Details"}
                </Button>
                <Link
                  href={`/checkout/${flight.id}?method=${userSelectedMethod || aiPreferredMethod}&cabin=${selectedCabin[flight.id] || "economy"}`}
                >
                  <Button size="sm" className={flight.aiRecommendation.isRecommended ? "bg-primary" : ""}>
                    {flight.aiRecommendation.isRecommended ? "Select Best" : "Select"}
                  </Button>
                </Link>
              </div>
            </CardFooter>
          </Card>
        )
      })}
    </div>
  )
}
