import { Button } from "@/components/ui/button"
import Image from "next/image"

export function HeroSection() {
  return (
    <div className="relative">
      <div className="absolute inset-0 z-0">
        <Image
          src="/placeholder.svg?height=600&width=1600"
          alt="Travel background"
          fill
          className="object-cover brightness-50"
          priority
        />
      </div>
      <div className="relative z-10 container mx-auto px-4 py-24 md:py-32">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4">Travel Smart, Save More</h1>
          <p className="text-xl text-white/90 mb-8">
            Optimize your travel with our intelligent flight comparison tool. Compare cash prices with miles value,
            calculate potential rewards, and get personalized recommendations.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button size="lg" className="bg-primary text-white hover:bg-primary/90">
              Search Flights
            </Button>
            <Button size="lg" variant="outline" className="bg-transparent text-white border-white hover:bg-white/10">
              Learn More
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
