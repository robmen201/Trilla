"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarIcon, Plane, Loader2, MapPin, Users } from "lucide-react"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

// City options for From and To
const fromCities = [
  { code: "JFK", name: "New York", airport: "John F. Kennedy Intl" },
  { code: "LAX", name: "Los Angeles", airport: "Los Angeles Intl" },
  { code: "MIA", name: "Miami", airport: "Miami Intl" },
  { code: "ORD", name: "Chicago", airport: "O'Hare Intl" },
]

const toCities = [
  { code: "LHR", name: "London", airport: "Heathrow" },
  { code: "CDG", name: "Paris", airport: "Charles de Gaulle" },
  { code: "NRT", name: "Tokyo", airport: "Narita Intl" },
  { code: "SYD", name: "Sydney", airport: "Kingsford Smith" },
]

export function SearchFormEnhanced() {
  const router = useRouter()
  const [isSearching, setIsSearching] = useState(false)
  const [tripType, setTripType] = useState("round")

  // Start with empty values
  const [fromCity, setFromCity] = useState("")
  const [toCity, setToCity] = useState("")
  const [departDate, setDepartDate] = useState<Date>()
  const [returnDate, setReturnDate] = useState<Date>()
  const [passengers, setPassengers] = useState("1")
  const [travelClass, setTravelClass] = useState("ECONOMY")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!fromCity || !toCity || !departDate) {
      alert("Please fill in all required fields")
      return
    }

    setIsSearching(true)

    try {
      // Prepare search parameters
      const searchParams = new URLSearchParams({
        origin: fromCity,
        destination: toCity,
        departureDate: format(departDate, "yyyy-MM-dd"),
        adults: passengers,
        travelClass,
      })

      if (tripType === "round" && returnDate) {
        searchParams.append("returnDate", format(returnDate, "yyyy-MM-dd"))
      }

      // Navigate to results page with search parameters
      router.push(`/search-results?${searchParams.toString()}`)
    } catch (error) {
      console.error("Search error:", error)
      alert("Search failed. Please try again.")
    } finally {
      setIsSearching(false)
    }
  }

  const getFromCityDisplay = () => {
    const city = fromCities.find((c) => c.code === fromCity)
    return city ? `${city.name} (${city.code})` : "From"
  }

  const getToCityDisplay = () => {
    const city = toCities.find((c) => c.code === toCity)
    return city ? `${city.name} (${city.code})` : "To"
  }

  return (
    <Card className="p-6 bg-white/95 backdrop-blur-sm border-2 border-teal-200">
      <Tabs defaultValue="flight" className="mb-6">
        <TabsList className="grid w-full grid-cols-4 bg-teal-50">
          <TabsTrigger value="flight" className="data-[state=active]:bg-teal-500 data-[state=active]:text-white">
            ✈️ Flight
          </TabsTrigger>
          <TabsTrigger value="hotel" disabled className="opacity-50">
            🏨 Hotel
          </TabsTrigger>
          <TabsTrigger value="car" disabled className="opacity-50">
            🚗 Car Rental
          </TabsTrigger>
          <TabsTrigger value="rewards" className="data-[state=active]:bg-teal-500 data-[state=active]:text-white">
            🎁 Rewards
          </TabsTrigger>
        </TabsList>
      </Tabs>

      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          {/* Trip Type Selection */}
          <div className="flex gap-4 text-sm">
            <button
              type="button"
              className={`px-4 py-2 rounded-full border-2 transition-all ${
                tripType === "round"
                  ? "border-teal-500 bg-teal-50 text-teal-700 font-medium"
                  : "border-gray-200 text-gray-600 hover:border-gray-300"
              }`}
              onClick={() => setTripType("round")}
            >
              Round Trip
            </button>
            <button
              type="button"
              className={`px-4 py-2 rounded-full border-2 transition-all ${
                tripType === "one"
                  ? "border-teal-500 bg-teal-50 text-teal-700 font-medium"
                  : "border-gray-200 text-gray-600 hover:border-gray-300"
              }`}
              onClick={() => setTripType("one")}
            >
              One Way
            </button>
            <button
              type="button"
              className="px-4 py-2 rounded-full border-2 border-gray-200 text-gray-400 cursor-not-allowed"
              disabled
            >
              Multi-City
            </button>
          </div>

          {/* Main Search Form */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 p-4 bg-gradient-to-r from-teal-50 to-blue-50 rounded-xl border-2 border-teal-200">
            {/* From City */}
            <div className="lg:col-span-3">
              <label className="block text-sm font-medium text-gray-700 mb-2">From</label>
              <Select value={fromCity} onValueChange={setFromCity}>
                <SelectTrigger className="h-12 text-left">
                  <div className="flex items-center gap-3">
                    <MapPin className="h-4 w-4 text-teal-500" />
                    <div>
                      <div className="font-medium text-gray-900">{getFromCityDisplay()}</div>
                      {fromCity && (
                        <div className="text-xs text-gray-500">
                          {fromCities.find((c) => c.code === fromCity)?.airport}
                        </div>
                      )}
                    </div>
                  </div>
                </SelectTrigger>
                <SelectContent>
                  {fromCities.map((city) => (
                    <SelectItem key={city.code} value={city.code}>
                      <div className="flex items-center gap-3 py-2">
                        <div className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center">
                          <span className="text-xs font-bold text-teal-700">{city.code}</span>
                        </div>
                        <div>
                          <div className="font-medium">{city.name}</div>
                          <div className="text-xs text-gray-500">{city.airport}</div>
                        </div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* To City */}
            <div className="lg:col-span-3">
              <label className="block text-sm font-medium text-gray-700 mb-2">To</label>
              <Select value={toCity} onValueChange={setToCity}>
                <SelectTrigger className="h-12 text-left">
                  <div className="flex items-center gap-3">
                    <MapPin className="h-4 w-4 text-blue-500" />
                    <div>
                      <div className="font-medium text-gray-900">{getToCityDisplay()}</div>
                      {toCity && (
                        <div className="text-xs text-gray-500">{toCities.find((c) => c.code === toCity)?.airport}</div>
                      )}
                    </div>
                  </div>
                </SelectTrigger>
                <SelectContent>
                  {toCities.map((city) => (
                    <SelectItem key={city.code} value={city.code}>
                      <div className="flex items-center gap-3 py-2">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                          <span className="text-xs font-bold text-blue-700">{city.code}</span>
                        </div>
                        <div>
                          <div className="font-medium">{city.name}</div>
                          <div className="text-xs text-gray-500">{city.airport}</div>
                        </div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Departure Date */}
            <div className="lg:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Departure</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "h-12 w-full justify-start text-left font-normal",
                      !departDate && "text-muted-foreground",
                    )}
                  >
                    <CalendarIcon className="mr-3 h-4 w-4 text-teal-500" />
                    <div>
                      <div className="font-medium">
                        {departDate ? format(departDate, "MMM dd, yyyy") : "Select date"}
                      </div>
                      {departDate && <div className="text-xs text-gray-500">{format(departDate, "EEEE")}</div>}
                    </div>
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={departDate}
                    onSelect={setDepartDate}
                    initialFocus
                    disabled={(date) => date < new Date()}
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Return Date */}
            {tripType === "round" && (
              <div className="lg:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Return</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "h-12 w-full justify-start text-left font-normal",
                        !returnDate && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-3 h-4 w-4 text-blue-500" />
                      <div>
                        <div className="font-medium">
                          {returnDate ? format(returnDate, "MMM dd, yyyy") : "Select date"}
                        </div>
                        {returnDate && <div className="text-xs text-gray-500">{format(returnDate, "EEEE")}</div>}
                      </div>
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={returnDate}
                      onSelect={setReturnDate}
                      initialFocus
                      disabled={(date) => date < (departDate || new Date())}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            )}

            {/* Passengers & Class */}
            <div className="lg:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Travelers & Class</label>
              <div className="grid grid-cols-2 gap-2">
                <Select value={passengers} onValueChange={setPassengers}>
                  <SelectTrigger className="h-12">
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-gray-500" />
                      <span className="font-medium">{passengers}</span>
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 Traveler</SelectItem>
                    <SelectItem value="2">2 Travelers</SelectItem>
                    <SelectItem value="3">3 Travelers</SelectItem>
                    <SelectItem value="4">4 Travelers</SelectItem>
                    <SelectItem value="5">5+ Travelers</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={travelClass} onValueChange={setTravelClass}>
                  <SelectTrigger className="h-12">
                    <div className="font-medium text-sm">
                      {travelClass === "ECONOMY"
                        ? "Economy"
                        : travelClass === "PREMIUM_ECONOMY"
                          ? "Premium"
                          : travelClass === "BUSINESS"
                            ? "Business"
                            : "First"}
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ECONOMY">Economy</SelectItem>
                    <SelectItem value="PREMIUM_ECONOMY">Premium Economy</SelectItem>
                    <SelectItem value="BUSINESS">Business</SelectItem>
                    <SelectItem value="FIRST">First</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Search Button */}
          <Button
            type="submit"
            className="w-full h-14 text-lg font-semibold bg-gradient-to-r from-teal-500 to-blue-500 hover:from-teal-600 hover:to-blue-600 text-white shadow-lg hover:shadow-xl transition-all duration-200"
            size="lg"
            disabled={isSearching || !fromCity || !toCity || !departDate}
          >
            {isSearching ? (
              <>
                <Loader2 className="mr-3 h-5 w-5 animate-spin" />
                Searching Best Flights...
              </>
            ) : (
              <>
                <Plane className="mr-3 h-5 w-5" />
                Search Smart Flights
              </>
            )}
          </Button>

          {/* Helper Text */}
          <div className="text-center text-sm text-gray-600">
            <p>✨ Real-time prices • 🎯 Miles optimization • 💳 Credit card rewards</p>
          </div>
        </div>
      </form>
    </Card>
  )
}
