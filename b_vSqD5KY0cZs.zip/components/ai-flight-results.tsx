"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  ArrowRight,
  Sparkles,
  TrendingUp,
  Clock,
  CreditCard,
  Plane,
  AlertTriangle,
  CheckCircle,
  Zap,
} from "lucide-react"

// AI-powered flight recommendations
const aiRecommendations = [
  {
    id: "1",
    airline: "British Airways",
    departTime: "8:30 AM",
    arriveTime: "10:45 PM",
    duration: "7h 15m",
    cabin: "Business Class",
    aiScore: 98,
    recommendation: {
      method: "miles",
      price: 3200,
      milesNeeded: 120000,
      savings: 850,
      card: "Chase Sapphire Reserve",
      reason: "Amazing value redemption + your Gold status gets free upgrades",
      confidence: 98,
      milesEarned: 10374,
      valueLabel: "Amazing value", // Add this new field
      centsPerMile: 2.67, // Add this new field
    },
    urgency: {
      priceChange: 120,
      timeLeft: "6 hours",
      bookingPressure: "high",
    },
    insights: [
      "Your Oneworld Gold status includes free seat selection ($45 value)",
      "Business class miles redemption at 2.67¢/mile (excellent value)",
      "Chase points transfer 1:1 to British Airways",
    ],
    autoBookable: true,
  },
  {
    id: "2",
    airline: "American Airlines",
    departTime: "10:15 AM",
    arriveTime: "11:30 PM",
    duration: "7h 15m",
    cabin: "Premium Economy",
    aiScore: 85,
    recommendation: {
      method: "cash",
      price: 1180,
      milesNeeded: 90000,
      savings: 320,
      card: "Citi AAdvantage Platinum",
      reason: "Pay cash & earn miles - poor redemption value but great earning opportunity",
      confidence: 85,
      milesEarned: 5187,
    },
    urgency: {
      priceChange: -45,
      timeLeft: "2 days",
      bookingPressure: "medium",
    },
    insights: [
      "Miles redemption only 1.31¢/mile (below average)",
      "Paying cash earns 5,187 AAdvantage miles",
      "Citi card earns 2x miles on American flights",
    ],
    autoBookable: true,
  },
  {
    id: "3",
    airline: "Lufthansa",
    departTime: "2:15 PM",
    arriveTime: "5:30 AM+1",
    duration: "8h 15m",
    cabin: "Business Class",
    aiScore: 96,
    recommendation: {
      method: "miles",
      price: 4200,
      milesNeeded: 85000,
      savings: 1950,
      card: "Chase Sapphire Reserve",
      reason: "Transfer Chase points to United for Lufthansa - incredible value",
      confidence: 96,
      milesEarned: 12600,
      valueLabel: "Amazing value",
      centsPerMile: 4.94,
    },
    urgency: {
      priceChange: 150,
      timeLeft: "10 hours",
      bookingPressure: "high",
    },
    insights: [
      "Lufthansa Business at 4.94¢/mile - exceptional Star Alliance value",
      "Chase points transfer 1:1 to United for Lufthansa awards",
      "Limited award availability - book now",
    ],
    autoBookable: true,
  },
  {
    id: "4",
    airline: "Virgin Atlantic",
    departTime: "7:30 PM",
    arriveTime: "9:45 AM",
    duration: "8h 15m",
    cabin: "Upper Class",
    aiScore: 92,
    recommendation: {
      method: "miles",
      price: 4900,
      milesNeeded: 160000,
      savings: 1200,
      card: "Amex Platinum",
      reason: "Transfer Amex points to Virgin - exceptional value for First Class experience",
      confidence: 92,
      milesEarned: 17290,
    },
    urgency: {
      priceChange: 200,
      timeLeft: "12 hours",
      bookingPressure: "high",
    },
    insights: [
      "Virgin Upper Class = First Class experience at Business price",
      "Amex transfers 1:1 to Virgin Flying Club",
      "3.06¢/mile value - exceptional for premium cabin",
    ],
    autoBookable: true,
  },
  {
    id: "5",
    airline: "Lufthansa",
    departTime: "2:15 PM",
    arriveTime: "5:30 AM+1",
    duration: "8h 15m",
    cabin: "Business Class",
    aiScore: 94,
    recommendation: {
      method: "miles",
      price: 4200,
      milesNeeded: 88000,
      savings: 1850,
      card: "Chase Sapphire Reserve",
      reason: "Amazing value redemption - transfer Chase points to United for Lufthansa",
      confidence: 96,
      milesEarned: 12600,
      valueLabel: "Amazing value",
      centsPerMile: 4.77,
    },
    urgency: {
      priceChange: 180,
      timeLeft: "8 hours",
      bookingPressure: "high",
    },
    insights: [
      "Lufthansa Business at 4.77¢/mile - exceptional Star Alliance value",
      "Chase points transfer 1:1 to United for Lufthansa awards",
      "Miles & More program offers great availability on this route",
    ],
    autoBookable: true,
  },
]

export function AIFlightResults() {
  const [selectedFlight, setSelectedFlight] = useState<string | null>(null)
  const [bookingInProgress, setBookingInProgress] = useState<string | null>(null)
  const [showAlternatives, setShowAlternatives] = useState(false)

  const topRecommendation = aiRecommendations[0]
  const alternatives = aiRecommendations.slice(1)

  const handleAutoBook = async (flightId: string) => {
    setBookingInProgress(flightId)
    // Simulate booking process
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setBookingInProgress(null)
    // In real app, this would redirect to confirmation
  }

  return (
    <div className="space-y-6">
      {/* AI Perfect Match */}
      <Card className="border-2 border-primary bg-gradient-to-r from-primary/5 to-blue/5 shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-primary" />
              Perfect Match for You
              <Badge variant="default" className="bg-primary">
                {topRecommendation.aiScore}% Match
              </Badge>
            </CardTitle>
            {topRecommendation.urgency.bookingPressure === "high" && (
              <Badge variant="destructive" className="animate-pulse">
                <Clock className="h-3 w-3 mr-1" />
                Book Soon
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Urgency Alert */}
          {topRecommendation.urgency.priceChange > 0 && (
            <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg flex items-center gap-3">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              <div>
                <div className="font-medium text-orange-800">Price Alert</div>
                <div className="text-sm text-orange-700">
                  Prices increased ${topRecommendation.urgency.priceChange} since yesterday. Book within{" "}
                  {topRecommendation.urgency.timeLeft} to secure this rate.
                </div>
              </div>
            </div>
          )}

          {/* Flight Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="font-bold text-lg">{topRecommendation.airline}</div>
                  <div className="text-sm text-muted-foreground">{topRecommendation.cabin}</div>
                </div>
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  AI Verified
                </Badge>
              </div>

              <div className="flex items-center gap-6">
                <div className="text-center">
                  <div className="font-bold">{topRecommendation.departTime}</div>
                  <div className="text-sm text-muted-foreground">JFK</div>
                </div>
                <div className="flex flex-col items-center flex-1">
                  <div className="text-xs text-muted-foreground mb-1">{topRecommendation.duration}</div>
                  <div className="relative w-full">
                    <div className="border-t-2 border-dashed border-primary absolute w-full top-1/2"></div>
                    <ArrowRight className="h-4 w-4 absolute right-0 top-1/2 -translate-y-1/2 text-primary" />
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">Nonstop</div>
                </div>
                <div className="text-center">
                  <div className="font-bold">{topRecommendation.arriveTime}</div>
                  <div className="text-sm text-muted-foreground">LHR</div>
                </div>
              </div>
            </div>

            {/* AI Recommendation */}
            <div className="bg-white p-4 rounded-lg border-2 border-primary/20">
              <div className="flex items-center gap-2 mb-3">
                <Zap className="h-4 w-4 text-primary" />
                <span className="font-medium text-primary">AI Recommendation</span>
              </div>

              {topRecommendation.recommendation.method === "miles" ? (
                <div>
                  <div className="text-2xl font-bold text-primary">
                    {topRecommendation.recommendation.milesNeeded.toLocaleString()} miles
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Transfer from {topRecommendation.recommendation.card}
                  </div>
                  {topRecommendation.recommendation.valueLabel && (
                    <div className="text-xs font-bold text-green-600 bg-green-50 px-2 py-1 rounded-full mt-1 inline-block">
                      🌟 {topRecommendation.recommendation.valueLabel} - {topRecommendation.recommendation.centsPerMile}
                      ¢/mile
                    </div>
                  )}
                </div>
              ) : (
                <div>
                  <div className="text-2xl font-bold text-primary">${topRecommendation.recommendation.price}</div>
                  <div className="text-sm text-muted-foreground">Pay with {topRecommendation.recommendation.card}</div>
                </div>
              )}

              <div className="flex items-center gap-1 mt-2">
                <TrendingUp className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium text-green-600">
                  Save ${topRecommendation.recommendation.savings}
                </span>
              </div>

              <div className="mt-2">
                <div className="flex justify-between text-xs mb-1">
                  <span>Confidence</span>
                  <span>{topRecommendation.recommendation.confidence}%</span>
                </div>
                <Progress value={topRecommendation.recommendation.confidence} className="h-2" />
              </div>
            </div>

            {/* Auto-Book Button */}
            <div className="flex flex-col gap-3">
              <Button
                className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-3"
                size="lg"
                onClick={() => handleAutoBook(topRecommendation.id)}
                disabled={bookingInProgress === topRecommendation.id}
              >
                {bookingInProgress === topRecommendation.id ? (
                  <div className="flex items-center gap-2">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    Booking...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4" />
                    Auto-Book This
                  </div>
                )}
              </Button>

              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => setShowAlternatives(!showAlternatives)}
              >
                {showAlternatives ? "Hide" : "See"} Other Options
              </Button>
            </div>
          </div>

          {/* AI Insights */}
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <h3 className="font-medium mb-3 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-blue-600" />
              Why This is Perfect for You
            </h3>
            <div className="space-y-2">
              {topRecommendation.insights.map((insight, index) => (
                <div key={index} className="flex items-start gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>{insight}</span>
                </div>
              ))}
            </div>
            <div className="mt-3 text-xs text-blue-600 font-medium">{topRecommendation.recommendation.reason}</div>
          </div>
        </CardContent>
      </Card>

      {/* Alternative Options */}
      {showAlternatives && (
        <div className="space-y-4">
          <h2 className="text-xl font-bold">Alternative Options</h2>
          {alternatives.map((flight) => (
            <Card key={flight.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
                  {/* Flight Info */}
                  <div className="md:col-span-2">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="font-medium">{flight.airline}</div>
                      <Badge variant="outline">{flight.aiScore}% Match</Badge>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <div className="font-medium">{flight.departTime}</div>
                        <div className="text-xs text-muted-foreground">JFK</div>
                      </div>
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                      <div className="text-center">
                        <div className="font-medium">{flight.arriveTime}</div>
                        <div className="text-xs text-muted-foreground">LHR</div>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">{flight.cabin}</div>
                  </div>

                  {/* Recommendation */}
                  <div className="bg-muted/50 p-3 rounded-lg">
                    <div className="font-medium">
                      {flight.recommendation.method === "miles"
                        ? `${flight.recommendation.milesNeeded.toLocaleString()} miles`
                        : `$${flight.recommendation.price}`}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {flight.recommendation.method === "miles" ? "Use miles" : "Pay cash"}
                    </div>
                    <div className="text-xs text-green-600 font-medium">Save ${flight.recommendation.savings}</div>
                  </div>

                  {/* Why Different */}
                  <div className="text-sm">
                    <div className="font-medium mb-1">Why this option:</div>
                    <div className="text-muted-foreground text-xs">{flight.recommendation.reason}</div>
                  </div>

                  {/* Action */}
                  <div className="flex flex-col gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleAutoBook(flight.id)}
                      disabled={bookingInProgress === flight.id}
                    >
                      {bookingInProgress === flight.id ? "Booking..." : "Select This"}
                    </Button>
                    <div className="text-xs text-center text-muted-foreground">
                      {flight.recommendation.confidence}% confidence
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Smart Insights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <CreditCard className="h-4 w-4 text-green-600" />
              <Badge variant="outline" className="text-green-700 border-green-300">
                Credit Card Tip
              </Badge>
            </div>
            <p className="text-sm text-green-800">
              Your Chase Sapphire Reserve will earn 9,600 extra points on this booking
            </p>
          </CardContent>
        </Card>

        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Plane className="h-4 w-4 text-blue-600" />
              <Badge variant="outline" className="text-blue-700 border-blue-300">
                Status Benefit
              </Badge>
            </div>
            <p className="text-sm text-blue-800">
              Your Oneworld Gold status includes priority boarding and lounge access
            </p>
          </CardContent>
        </Card>

        <Card className="bg-purple-50 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-4 w-4 text-purple-600" />
              <Badge variant="outline" className="text-purple-700 border-purple-300">
                Market Insight
              </Badge>
            </div>
            <p className="text-sm text-purple-800">
              Business class prices on this route typically increase 25% in the next week
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
