"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import {
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts"
import {
  Shield,
  Users,
  Plane,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Search,
  Download,
  Settings,
  Bell,
  Eye,
  Plus,
  Activity,
  Globe,
  CreditCard,
  Star,
  MessageSquare,
  BarChart3,
  Edit,
  Ban,
  Mail,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  Save,
  X,
  Check,
  Clock,
  Crown,
  Zap,
  Building,
  Gift,
  Hotel,
  Minus,
} from "lucide-react"

// Mock data for different sections
const platformMetrics = [
  { month: "Jan", users: 2400, bookings: 1200, revenue: 450000, alerts: 89 },
  { month: "Feb", users: 2800, bookings: 1400, revenue: 520000, alerts: 76 },
  { month: "Mar", users: 3200, bookings: 1800, revenue: 680000, alerts: 92 },
  { month: "Apr", users: 3600, bookings: 2100, revenue: 780000, alerts: 68 },
  { month: "May", users: 4100, bookings: 2400, revenue: 890000, alerts: 84 },
  { month: "Jun", users: 4500, bookings: 2800, revenue: 1020000, alerts: 71 },
]

const usersList = [
  {
    id: 1,
    name: "John Doe",
    email: "john.doe@email.com",
    status: "active",
    plan: "Premium",
    joined: "2024-01-15",
    bookings: 12,
    spent: 4250,
    lastLogin: "2 hours ago",
  },
  {
    id: 2,
    name: "Sarah Smith",
    email: "sarah.smith@email.com",
    status: "active",
    plan: "Business",
    joined: "2024-02-20",
    bookings: 28,
    spent: 8900,
    lastLogin: "1 day ago",
  },
  {
    id: 3,
    name: "Mike Wilson",
    email: "mike.wilson@email.com",
    status: "suspended",
    plan: "Free",
    joined: "2024-03-10",
    bookings: 3,
    spent: 450,
    lastLogin: "1 week ago",
  },
  {
    id: 4,
    name: "Emma Brown",
    email: "emma.brown@email.com",
    status: "active",
    plan: "Enterprise",
    joined: "2024-01-05",
    bookings: 45,
    spent: 15600,
    lastLogin: "30 min ago",
  },
]

const flightOperations = [
  {
    route: "JFK → LAX",
    airline: "American Airlines",
    bookings: 342,
    revenue: 128400,
    avgPrice: 375,
    commission: 3200,
    status: "active",
  },
  {
    route: "MIA → LHR",
    airline: "British Airways",
    bookings: 298,
    revenue: 156780,
    avgPrice: 526,
    commission: 4200,
    status: "active",
  },
  {
    route: "LAX → NRT",
    airline: "Japan Airlines",
    bookings: 267,
    revenue: 198450,
    avgPrice: 743,
    commission: 5100,
    status: "maintenance",
  },
  {
    route: "DFW → FRA",
    airline: "Lufthansa",
    bookings: 198,
    revenue: 134560,
    avgPrice: 679,
    commission: 3800,
    status: "active",
  },
]

const financialData = [
  { month: "Jan", revenue: 450000, costs: 320000, profit: 130000, margin: 28.9 },
  { month: "Feb", revenue: 520000, costs: 365000, profit: 155000, margin: 29.8 },
  { month: "Mar", revenue: 680000, costs: 476000, profit: 204000, margin: 30.0 },
  { month: "Apr", revenue: 780000, costs: 546000, profit: 234000, margin: 30.0 },
  { month: "May", revenue: 890000, costs: 623000, profit: 267000, margin: 30.0 },
  { month: "Jun", revenue: 1020000, costs: 714000, profit: 306000, margin: 30.0 },
]

const supportTickets = [
  {
    id: "SUP-001",
    user: "alex.johnson@email.com",
    subject: "Booking confirmation issue",
    priority: "high",
    status: "open",
    assignee: "Sarah Admin",
    created: "2024-06-24 14:30",
    updated: "1 hour ago",
  },
  {
    id: "SUP-002",
    user: "lisa.davis@email.com",
    subject: "Miles not credited",
    priority: "medium",
    status: "in-progress",
    assignee: "Mike Support",
    created: "2024-06-24 11:15",
    updated: "3 hours ago",
  },
  {
    id: "SUP-003",
    user: "tom.garcia@email.com",
    subject: "Refund request",
    priority: "high",
    status: "open",
    assignee: "Emma Admin",
    created: "2024-06-24 09:45",
    updated: "5 hours ago",
  },
]

const systemHealth = [
  { service: "Web Server", status: "healthy", uptime: "99.9%", response: "45ms", load: "23%" },
  { service: "Database", status: "healthy", uptime: "99.8%", response: "12ms", load: "67%" },
  { service: "Redis Cache", status: "healthy", uptime: "100%", response: "3ms", load: "34%" },
  { service: "Payment Gateway", status: "warning", uptime: "98.5%", response: "890ms", load: "89%" },
  { service: "Email Service", status: "healthy", uptime: "99.7%", response: "156ms", load: "12%" },
  { service: "File Storage", status: "healthy", uptime: "99.9%", response: "78ms", load: "45%" },
]

const systemAlerts = [
  {
    id: 1,
    type: "critical",
    message: "Payment gateway experiencing delays",
    time: "5 min ago",
    status: "active",
    affected: "Payment processing",
  },
  {
    id: 2,
    type: "warning",
    message: "Amadeus API rate limit at 85%",
    time: "12 min ago",
    status: "monitoring",
    affected: "Flight search",
  },
  {
    id: 3,
    type: "info",
    message: "Scheduled maintenance completed",
    time: "1 hour ago",
    status: "resolved",
    affected: "Database",
  },
  {
    id: 4,
    type: "warning",
    message: "High traffic detected on search endpoints",
    time: "2 hours ago",
    status: "monitoring",
    affected: "Search API",
  },
]

const apiEndpoints = [
  {
    name: "Flight Search",
    endpoint: "/api/flights/search",
    requests: 45000,
    avgResponse: 245,
    errorRate: 0.2,
    uptime: 99.8,
    rateLimit: "1000/min",
  },
  {
    name: "Booking Create",
    endpoint: "/api/bookings/create",
    requests: 12000,
    avgResponse: 890,
    errorRate: 1.2,
    uptime: 98.5,
    rateLimit: "100/min",
  },
  {
    name: "User Auth",
    endpoint: "/api/auth/login",
    requests: 23000,
    avgResponse: 156,
    errorRate: 0.1,
    uptime: 99.9,
    rateLimit: "50/min",
  },
  {
    name: "Price Alerts",
    endpoint: "/api/alerts/create",
    requests: 8900,
    avgResponse: 78,
    errorRate: 0.3,
    uptime: 99.7,
    rateLimit: "200/min",
  },
]

// Updated loyalty programs with status multipliers
const initialLoyaltyPrograms = [
  {
    id: 1,
    name: "United MileagePlus",
    partner: "United Airlines",
    type: "airline",
    commission: 2.8,
    pointValue: 0.012,
    bookings: 456,
    revenue: 124000,
    status: "active",
    contract: "2025-12-31",
    perks: ["Priority boarding", "Free checked bags", "Lounge access", "Upgrade priority"],
    statusMultipliers: [
      { status: "General Member", multiplier: 5 },
      { status: "Premier Silver", multiplier: 7 },
      { status: "Premier Gold", multiplier: 8 },
      { status: "Premier Platinum", multiplier: 9 },
      { status: "Premier 1K", multiplier: 11 },
    ],
    redemptionChart: [
      { tarifa: "Ejecutiva Full", clase: "J", calificacion: 300, premio: 300 },
      { tarifa: "Ejecutiva Promo", clase: "P", calificacion: 175, premio: 175 },
      { tarifa: "Economica Full", clase: "M", calificacion: 175, premio: 175 },
      { tarifa: "Economica Classic", clase: "O, T", calificacion: 100, premio: 100 },
      { tarifa: "Economica Basic", clase: "O, T, A", calificacion: 50, premio: 50 },
    ],
  },
  {
    id: 2,
    name: "Delta SkyMiles",
    partner: "Delta Airlines",
    type: "airline",
    commission: 2.6,
    pointValue: 0.011,
    bookings: 398,
    revenue: 112000,
    status: "active",
    contract: "2025-08-15",
    perks: ["Sky Priority", "Free seat selection", "Complimentary drinks", "Miles bonus"],
    statusMultipliers: [
      { status: "Basic SkyMiles", multiplier: 5 },
      { status: "Silver Medallion", multiplier: 7 },
      { status: "Gold Medallion", multiplier: 8 },
      { status: "Platinum Medallion", multiplier: 9 },
      { status: "Diamond Medallion", multiplier: 11 },
    ],
    redemptionChart: [
      { tarifa: "Ejecutiva Full", clase: "J", calificacion: 300, premio: 300 },
      { tarifa: "Ejecutiva Promo", clase: "P", calificacion: 175, premio: 175 },
      { tarifa: "Economica Full", clase: "M", calificacion: 175, premio: 175 },
      { tarifa: "Economica Classic", clase: "O, T", calificacion: 100, premio: 100 },
      { tarifa: "Economica Basic", clase: "O, T, A", calificacion: 50, premio: 50 },
    ],
  },
  {
    id: 3,
    name: "American AAdvantage",
    partner: "American Airlines",
    type: "airline",
    commission: 2.9,
    pointValue: 0.013,
    bookings: 367,
    revenue: 108900,
    status: "negotiating",
    contract: "2024-12-31",
    perks: ["Priority check-in", "Free bags", "Admirals Club access", "Upgrade certificates"],
    statusMultipliers: [
      { status: "AAdvantage Member", multiplier: 5 },
      { status: "Gold", multiplier: 7 },
      { status: "Platinum", multiplier: 8 },
      { status: "Platinum Pro", multiplier: 9 },
      { status: "Executive Platinum", multiplier: 11 },
    ],
    redemptionChart: [
      { tarifa: "Ejecutiva Full", clase: "J", calificacion: 300, premio: 300 },
      { tarifa: "Ejecutiva Promo", clase: "P", calificacion: 175, premio: 175 },
      { tarifa: "Economica Full", clase: "M", calificacion: 175, premio: 175 },
      { tarifa: "Economica Classic", clase: "O, T", calificacion: 100, premio: 100 },
      { tarifa: "Economica Basic", clase: "O, T, A", calificacion: 50, premio: 50 },
    ],
  },
  {
    id: 4,
    name: "Marriott Bonvoy",
    partner: "Marriott International",
    type: "hotel",
    commission: 3.2,
    pointValue: 0.008,
    bookings: 234,
    revenue: 89000,
    status: "active",
    contract: "2025-06-30",
    perks: ["Late checkout", "Room upgrades", "Free WiFi", "Elite night credits"],
    statusMultipliers: [
      { status: "Member", multiplier: 10 },
      { status: "Silver Elite", multiplier: 12 },
      { status: "Gold Elite", multiplier: 15 },
      { status: "Platinum Elite", multiplier: 17 },
      { status: "Titanium Elite", multiplier: 20 },
      { status: "Ambassador Elite", multiplier: 25 },
    ],
    redemptionChart: [
      { tarifa: "Suite Presidential", clase: "PS", calificacion: 500, premio: 500 },
      { tarifa: "Suite Ejecutiva", clase: "ES", calificacion: 300, premio: 300 },
      { tarifa: "Habitacion Premium", clase: "PR", calificacion: 200, premio: 200 },
      { tarifa: "Habitacion Standard", clase: "ST", calificacion: 100, premio: 100 },
    ],
  },
  {
    id: 5,
    name: "Chase Sapphire Reserve",
    partner: "Chase Bank",
    type: "credit_card",
    commission: 4.5,
    pointValue: 0.02,
    bookings: 189,
    revenue: 67000,
    status: "active",
    contract: "2025-12-31",
    perks: ["3x points on travel", "Travel insurance", "Airport lounge access", "No foreign fees"],
    statusMultipliers: [], // Credit cards don't have status tiers
  },
]

const subscriptionPlans = [
  {
    id: 1,
    name: "Freemium",
    price: 0,
    period: "Forever",
    description: "Perfect for occasional travelers who want basic flight search and comparison",
    features: [
      "5 flight searches per month",
      "Basic price comparison",
      "Email price alerts (1 active)",
      "Standard customer support",
      "Mobile app access",
    ],
    users: 8945,
    revenue: 0,
    conversionRate: "12.3%",
    churnRate: "8.5%",
    status: "active",
    color: "bg-gray-500",
    icon: Gift,
  },
  {
    id: 2,
    name: "Basic",
    price: 9,
    period: "month",
    description: "Ideal for regular travelers who need unlimited searches and smart alerts",
    features: [
      "Unlimited flight searches",
      "Advanced price comparison",
      "Email & SMS price alerts (5 active)",
      "Basic loyalty program integration",
      "Priority email support",
      "Mobile app with offline access",
      "Price history charts",
    ],
    users: 3456,
    revenue: 31104,
    conversionRate: "28.7%",
    churnRate: "5.2%",
    status: "active",
    color: "bg-blue-500",
    icon: Zap,
  },
  {
    id: 3,
    name: "Pro",
    price: 20,
    period: "month",
    description: "Advanced features for frequent travelers and travel enthusiasts",
    features: [
      "Everything in Basic",
      "AI-powered flight recommendations",
      "Real-time price tracking",
      "Unlimited price alerts",
      "Credit card points optimization",
      "Calendar integration",
      "Seat map & amenity details",
      "24/7 priority support",
      "Advanced booking analytics",
    ],
    users: 1102,
    revenue: 22040,
    conversionRate: "45.6%",
    churnRate: "3.1%",
    status: "active",
    color: "bg-purple-500",
    icon: Crown,
  },
  {
    id: 4,
    name: "Business",
    price: 60,
    period: "month",
    description: "Enterprise-grade solution for businesses and travel managers",
    features: [
      "Everything in Pro",
      "Team management dashboard",
      "Corporate booking tools",
      "Expense reporting & analytics",
      "API access for integrations",
      "Dedicated account manager",
      "Custom approval workflows",
      "Bulk booking discounts",
      "Advanced reporting & insights",
      "White-label options",
    ],
    users: 276,
    revenue: 16560,
    conversionRate: "67.8%",
    churnRate: "1.8%",
    status: "active",
    color: "bg-emerald-500",
    icon: Building,
  },
]

export function AdminDashboard() {
  const [activeSection, setActiveSection] = useState("analytics")
  const [selectedTimeframe, setSelectedTimeframe] = useState("30d")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedUser, setSelectedUser] = useState(null)
  const [selectedTicket, setSelectedTicket] = useState(null)
  const [editingProgram, setEditingProgram] = useState(null)
  const [addingProgram, setAddingProgram] = useState(false)
  const [loyaltyPrograms, setLoyaltyPrograms] = useState(initialLoyaltyPrograms)
  const [editFormData, setEditFormData] = useState({
    name: "",
    partner: "",
    type: "airline",
    commission: 0,
    pointValue: 0,
    status: "active",
    contract: "",
    perks: [],
    statusMultipliers: [],
    redemptionChart: [],
  })
  const [newPerk, setNewPerk] = useState("")

  // New state for redemption chart modal
  const [showRedemptionChart, setShowRedemptionChart] = useState(false)
  const [selectedProgramForChart, setSelectedProgramForChart] = useState(null)
  const [chartData, setChartData] = useState([])

  const [showRedemptionModal, setShowRedemptionModal] = useState(false)
  const [selectedProgramForRedemption, setSelectedProgramForRedemption] = useState(null)
  const [redemptionData, setRedemptionData] = useState([])

  const handleEditProgram = (program) => {
    setEditingProgram(program)
    setEditFormData({
      name: program.name,
      partner: program.partner,
      type: program.type,
      commission: program.commission,
      pointValue: program.pointValue,
      status: program.status,
      contract: program.contract,
      perks: [...program.perks],
      statusMultipliers: [...(program.statusMultipliers || [])],
      redemptionChart: [...(program.redemptionChart || [])],
    })
  }

  const handleAddProgram = () => {
    setAddingProgram(true)
    setEditFormData({
      name: "",
      partner: "",
      type: "airline",
      commission: 0,
      pointValue: 0,
      status: "active",
      contract: "",
      perks: [],
      statusMultipliers: [],
      redemptionChart: [],
    })
  }

  const handleSaveProgram = () => {
    if (addingProgram) {
      // Add new program
      const newProgram = {
        id: Math.max(...loyaltyPrograms.map((p) => p.id)) + 1,
        ...editFormData,
        bookings: 0,
        revenue: 0,
      }
      setLoyaltyPrograms([...loyaltyPrograms, newProgram])
      setAddingProgram(false)
    } else {
      // Update existing program
      const updatedPrograms = loyaltyPrograms.map((program) =>
        program.id === editingProgram.id ? { ...program, ...editFormData } : program,
      )
      setLoyaltyPrograms(updatedPrograms)
      setEditingProgram(null)
    }

    // Reset form
    setEditFormData({
      name: "",
      partner: "",
      type: "airline",
      commission: 0,
      pointValue: 0,
      status: "active",
      contract: "",
      perks: [],
      statusMultipliers: [],
      redemptionChart: [],
    })

    alert(addingProgram ? "Program added successfully!" : "Program updated successfully!")
  }

  const handleCancelEdit = () => {
    setEditingProgram(null)
    setAddingProgram(false)
    setEditFormData({
      name: "",
      partner: "",
      type: "airline",
      commission: 0,
      pointValue: 0,
      status: "active",
      contract: "",
      perks: [],
      statusMultipliers: [],
      redemptionChart: [],
    })
  }

  const handleAddPerk = () => {
    if (newPerk.trim()) {
      setEditFormData({
        ...editFormData,
        perks: [...editFormData.perks, newPerk.trim()],
      })
      setNewPerk("")
    }
  }

  const handleRemovePerk = (index) => {
    setEditFormData({
      ...editFormData,
      perks: editFormData.perks.filter((_, i) => i !== index),
    })
  }

  // New functions for redemption chart
  const handleOpenRedemptionChart = (program) => {
    setSelectedProgramForChart(program)
    setChartData([...(program.statusMultipliers || [])])
    setShowRedemptionChart(true)
  }

  const handleAddStatus = () => {
    setChartData([...chartData, { status: "", multiplier: 5 }])
  }

  const handleRemoveStatus = (index) => {
    setChartData(chartData.filter((_, i) => i !== index))
  }

  const handleStatusChange = (index, field, value) => {
    const updatedData = chartData.map((item, i) =>
      i === index ? { ...item, [field]: field === "multiplier" ? Number(value) : value } : item,
    )
    setChartData(updatedData)
  }

  const handleSaveRedemptionChart = () => {
    const updatedPrograms = loyaltyPrograms.map((program) =>
      program.id === selectedProgramForChart.id ? { ...program, statusMultipliers: [...chartData] } : program,
    )
    setLoyaltyPrograms(updatedPrograms)
    setShowRedemptionChart(false)
    setSelectedProgramForChart(null)
    setChartData([])
    alert("Redemption chart updated successfully!")
  }

  const handleCancelRedemptionChart = () => {
    setShowRedemptionChart(false)
    setSelectedProgramForChart(null)
    setChartData([])
  }

  const handleOpenRedemptionModal = (program) => {
    setSelectedProgramForRedemption(program)
    setRedemptionData([...(program.redemptionChart || [])])
    setShowRedemptionModal(true)
  }

  const handleAddRedemptionRow = () => {
    setRedemptionData([...redemptionData, { tarifa: "", clase: "", calificacion: 0, premio: 0 }])
  }

  const handleRemoveRedemptionRow = (index) => {
    setRedemptionData(redemptionData.filter((_, i) => i !== index))
  }

  const handleRedemptionChange = (index, field, value) => {
    const updatedData = redemptionData.map((item, i) =>
      i === index ? { ...item, [field]: field === "calificacion" || field === "premio" ? Number(value) : value } : item,
    )
    setRedemptionData(updatedData)
  }

  const handleSaveRedemptionModal = () => {
    const updatedPrograms = loyaltyPrograms.map((program) =>
      program.id === selectedProgramForRedemption.id ? { ...program, redemptionChart: [...redemptionData] } : program,
    )
    setLoyaltyPrograms(updatedPrograms)
    setShowRedemptionModal(false)
    setSelectedProgramForRedemption(null)
    setRedemptionData([])
    alert("Redemption chart updated successfully!")
  }

  const handleCancelRedemptionModal = () => {
    setShowRedemptionModal(false)
    setSelectedProgramForRedemption(null)
    setRedemptionData([])
  }

  const getTypeIcon = (type) => {
    switch (type) {
      case "airline":
        return <Plane className="h-5 w-5" />
      case "hotel":
        return <Hotel className="h-5 w-5" />
      case "credit_card":
        return <CreditCard className="h-5 w-5" />
      default:
        return <Star className="h-5 w-5" />
    }
  }

  const getTypeColor = (type) => {
    switch (type) {
      case "airline":
        return "bg-blue-500"
      case "hotel":
        return "bg-green-500"
      case "credit_card":
        return "bg-purple-500"
      default:
        return "bg-yellow-500"
    }
  }

  const renderContent = () => {
    switch (activeSection) {
      case "analytics":
        return renderAnalyticsDashboard()
      case "users":
        return renderUserManagement()
      case "flights":
        return renderFlightOperations()
      case "financial":
        return renderFinancialReports()
      case "support":
        return renderSupportCenter()
      case "health":
        return renderSystemHealth()
      case "alerts":
        return renderAlertManagement()
      case "api":
        return renderAPIManagement()
      case "payments":
        return renderPaymentSystems()
      case "loyalty":
        return renderLoyaltyPrograms()
      case "subscriptions":
        return renderSubscriptionPlans()
      case "settings":
        return renderSystemSettings()
      default:
        return renderAnalyticsDashboard()
    }
  }

  const renderAnalyticsDashboard = () => (
    <>
      {/* Critical Alerts Banner */}
      <div className="mb-6">
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                <div>
                  <h3 className="font-medium text-red-800">System Alert</h3>
                  <p className="text-sm text-red-600">
                    Payment gateway experiencing delays - affecting 12% of transactions
                  </p>
                </div>
              </div>
              <Button size="sm" variant="outline" className="border-red-300 text-red-700 bg-transparent">
                View Details
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Key Performance Indicators */}
      <div className="grid grid-cols-4 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Active Users</p>
                <p className="text-2xl font-bold text-teal-600">13,779</p>
                <p className="text-xs text-green-600">+8.2% vs last month</p>
              </div>
              <Users className="h-8 w-8 text-teal-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Platform Revenue</p>
                <p className="text-2xl font-bold text-teal-600">$1.02M</p>
                <p className="text-xs text-green-600">+12.5% vs last month</p>
              </div>
              <DollarSign className="h-8 w-8 text-teal-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">System Uptime</p>
                <p className="text-2xl font-bold text-green-600">99.2%</p>
                <p className="text-xs text-gray-500">Last 30 days</p>
              </div>
              <Activity className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Open Tickets</p>
                <p className="text-2xl font-bold text-orange-600">47</p>
                <p className="text-xs text-red-600">+5 since yesterday</p>
              </div>
              <MessageSquare className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-12 gap-6">
        {/* Platform Growth Chart */}
        <div className="col-span-8">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Platform Performance</CardTitle>
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={platformMetrics}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="users" stroke="#14B8A6" strokeWidth={2} name="Users" />
                  <Line type="monotone" dataKey="bookings" stroke="#3B82F6" strokeWidth={2} name="Bookings" />
                  <Line type="monotone" dataKey="revenue" stroke="#8B5CF6" strokeWidth={2} name="Revenue" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* User Segments */}
        <div className="col-span-4">
          <Card>
            <CardHeader>
              <CardTitle>User Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={[
                      { name: "Free Users", value: 65, count: 8945, color: "#94A3B8" },
                      { name: "Premium", value: 25, count: 3456, color: "#10B981" },
                      { name: "Business", value: 8, count: 1102, color: "#3B82F6" },
                      { name: "Enterprise", value: 2, count: 276, color: "#8B5CF6" },
                    ]}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    dataKey="value"
                  >
                    {[
                      { name: "Free Users", value: 65, count: 8945, color: "#94A3B8" },
                      { name: "Premium", value: 25, count: 3456, color: "#10B981" },
                      { name: "Business", value: 8, count: 1102, color: "#3B82F6" },
                      { name: "Enterprise", value: 2, count: 276, color: "#8B5CF6" },
                    ].map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  )

  const renderUserManagement = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">User Management</h2>
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input placeholder="Search users..." className="pl-10 w-80" />
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add User
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Users</p>
                <p className="text-2xl font-bold text-teal-600">13,779</p>
              </div>
              <Users className="h-8 w-8 text-teal-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Active Today</p>
                <p className="text-2xl font-bold text-green-600">2,847</p>
              </div>
              <Activity className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Premium Users</p>
                <p className="text-2xl font-bold text-blue-600">3,456</p>
              </div>
              <Star className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Suspended</p>
                <p className="text-2xl font-bold text-red-600">23</p>
              </div>
              <Ban className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>User List</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {usersList.map((user) => (
              <div key={user.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-teal-500 rounded-full flex items-center justify-center text-white font-medium">
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-medium">{user.name}</div>
                    <div className="text-sm text-gray-500">{user.email}</div>
                    <div className="text-xs text-gray-400">Joined: {user.joined}</div>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <div className="text-sm font-medium">{user.bookings}</div>
                    <div className="text-xs text-gray-500">Bookings</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">${user.spent}</div>
                    <div className="text-xs text-gray-500">Spent</div>
                  </div>
                  <Badge
                    className={
                      user.status === "active"
                        ? "bg-green-100 text-green-800"
                        : user.status === "suspended"
                          ? "bg-red-100 text-red-800"
                          : "bg-gray-100 text-gray-800"
                    }
                  >
                    {user.status}
                  </Badge>
                  <Badge className="bg-blue-100 text-blue-800">{user.plan}</Badge>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Mail className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" className="text-red-600 bg-transparent">
                      <Ban className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderFlightOperations = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Flight Operations</h2>
        <div className="flex items-center gap-4">
          <Button variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Sync Data
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Route
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Active Routes</p>
                <p className="text-2xl font-bold text-teal-600">247</p>
              </div>
              <Plane className="h-8 w-8 text-teal-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Partner Airlines</p>
                <p className="text-2xl font-bold text-blue-600">34</p>
              </div>
              <Globe className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Bookings</p>
                <p className="text-2xl font-bold text-green-600">8,947</p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Commission Earned</p>
                <p className="text-2xl font-bold text-purple-600">$45.2K</p>
              </div>
              <DollarSign className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Route Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {flightOperations.map((route, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white">
                    <Plane className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="font-medium">{route.route}</div>
                    <div className="text-sm text-gray-500">{route.airline}</div>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <div className="text-sm font-medium">{route.bookings}</div>
                    <div className="text-xs text-gray-500">Bookings</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">${route.revenue.toLocaleString()}</div>
                    <div className="text-xs text-gray-500">Revenue</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">${route.commission}</div>
                    <div className="text-xs text-gray-500">Commission</div>
                  </div>
                  <Badge
                    className={
                      route.status === "active"
                        ? "bg-green-100 text-green-800"
                        : route.status === "maintenance"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-gray-100 text-gray-800"
                    }
                  >
                    {route.status}
                  </Badge>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderFinancialReports = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Financial Reports</h2>
        <div className="flex items-center gap-4">
          <Select defaultValue="monthly">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="yearly">Yearly</SelectItem>
            </SelectContent>
          </Select>
          <Button>
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Revenue</p>
                <p className="text-2xl font-bold text-teal-600">$1.02M</p>
                <p className="text-xs text-green-600">+12.5% vs last month</p>
              </div>
              <DollarSign className="h-8 w-8 text-teal-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Net Profit</p>
                <p className="text-2xl font-bold text-green-600">$306K</p>
                <p className="text-xs text-green-600">30.0% margin</p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Operating Costs</p>
                <p className="text-2xl font-bold text-orange-600">$714K</p>
                <p className="text-xs text-red-600">+8.3% vs last month</p>
              </div>
              <TrendingDown className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Commission Earned</p>
                <p className="text-2xl font-bold text-purple-600">$89.2K</p>
                <p className="text-xs text-green-600">+15.7% vs last month</p>
              </div>
              <Star className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-8">
          <Card>
            <CardHeader>
              <CardTitle>Revenue & Profit Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={financialData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="revenue" fill="#14B8A6" name="Revenue" />
                  <Bar dataKey="profit" fill="#10B981" name="Profit" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
        <div className="col-span-4">
          <Card>
            <CardHeader>
              <CardTitle>Profit Margin</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={financialData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="margin" stroke="#8B5CF6" strokeWidth={3} />
                </LineChart>
              </ResponsiveContainer>
              <div className="mt-4 text-center">
                <div className="text-2xl font-bold text-purple-600">30.0%</div>
                <div className="text-sm text-gray-500">Average Margin</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )

  const renderSupportCenter = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Support Center</h2>
        <div className="flex items-center gap-4">
          <Select defaultValue="all">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Tickets</SelectItem>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
            </SelectContent>
          </Select>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            New Ticket
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Open Tickets</p>
                <p className="text-2xl font-bold text-red-600">47</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">In Progress</p>
                <p className="text-2xl font-bold text-yellow-600">23</p>
              </div>
              <Activity className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Resolved Today</p>
                <p className="text-2xl font-bold text-green-600">89</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Avg Response</p>
                <p className="text-2xl font-bold text-blue-600">2.4h</p>
              </div>
              <Clock className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Support Tickets</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {supportTickets.map((ticket) => (
              <div key={ticket.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center text-white">
                    <MessageSquare className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="font-medium">{ticket.id}</div>
                    <div className="text-sm text-gray-600">{ticket.subject}</div>
                    <div className="text-sm text-gray-500">{ticket.user}</div>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <div className="text-sm font-medium">{ticket.assignee}</div>
                    <div className="text-xs text-gray-500">Assignee</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">{ticket.updated}</div>
                    <div className="text-xs text-gray-500">Last Update</div>
                  </div>
                  <Badge
                    className={
                      ticket.priority === "high"
                        ? "bg-red-100 text-red-800"
                        : ticket.priority === "medium"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-green-100 text-green-800"
                    }
                  >
                    {ticket.priority}
                  </Badge>
                  <Badge
                    className={
                      ticket.status === "open"
                        ? "bg-red-100 text-red-800"
                        : ticket.status === "in-progress"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-green-100 text-green-800"
                    }
                  >
                    {ticket.status}
                  </Badge>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderSystemHealth = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">System Health</h2>
        <div className="flex items-center gap-4">
          <Button variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button>
            <Settings className="h-4 w-4 mr-2" />
            Configure
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Overall Health</p>
                <p className="text-2xl font-bold text-green-600">Healthy</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Active Alerts</p>
                <p className="text-2xl font-bold text-yellow-600">2</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Avg Response</p>
                <p className="text-2xl font-bold text-blue-600">156ms</p>
              </div>
              <Activity className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Service Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {systemHealth.map((service, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-4">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-white ${
                      service.status === "healthy"
                        ? "bg-green-500"
                        : service.status === "warning"
                          ? "bg-yellow-500"
                          : "bg-red-500"
                    }`}
                  >
                    {service.status === "healthy" ? (
                      <CheckCircle className="h-5 w-5" />
                    ) : (
                      <AlertTriangle className="h-5 w-5" />
                    )}
                  </div>
                  <div>
                    <div className="font-medium">{service.service}</div>
                    <div className="text-sm text-gray-500">Uptime: {service.uptime}</div>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <div className="text-sm font-medium">{service.response}</div>
                    <div className="text-xs text-gray-500">Response</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">{service.load}</div>
                    <div className="text-xs text-gray-500">Load</div>
                  </div>
                  <Badge
                    className={
                      service.status === "healthy"
                        ? "bg-green-100 text-green-800"
                        : service.status === "warning"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-red-100 text-red-800"
                    }
                  >
                    {service.status}
                  </Badge>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Settings className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderAlertManagement = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Alert Management</h2>
        <div className="flex items-center gap-4">
          <Select defaultValue="all">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Alerts</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="warning">Warning</SelectItem>
              <SelectItem value="info">Info</SelectItem>
            </SelectContent>
          </Select>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Create Alert
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Active Alerts</p>
                <p className="text-2xl font-bold text-red-600">4</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Critical</p>
                <p className="text-2xl font-bold text-red-600">1</p>
              </div>
              <X className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Warnings</p>
                <p className="text-2xl font-bold text-yellow-600">2</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Resolved Today</p>
                <p className="text-2xl font-bold text-green-600">12</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>System Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {systemAlerts.map((alert) => (
              <div key={alert.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-4">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-white ${
                      alert.type === "critical"
                        ? "bg-red-500"
                        : alert.type === "warning"
                          ? "bg-yellow-500"
                          : "bg-blue-500"
                    }`}
                  >
                    {alert.type === "critical" ? (
                      <X className="h-5 w-5" />
                    ) : alert.type === "warning" ? (
                      <AlertTriangle className="h-5 w-5" />
                    ) : (
                      <Bell className="h-5 w-5" />
                    )}
                  </div>
                  <div>
                    <div className="font-medium">{alert.message}</div>
                    <div className="text-sm text-gray-500">Affected: {alert.affected}</div>
                    <div className="text-sm text-gray-400">{alert.time}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <Badge
                    className={
                      alert.type === "critical"
                        ? "bg-red-100 text-red-800"
                        : alert.type === "warning"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-blue-100 text-blue-800"
                    }
                  >
                    {alert.type}
                  </Badge>
                  <Badge
                    className={
                      alert.status === "active"
                        ? "bg-red-100 text-red-800"
                        : alert.status === "monitoring"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-green-100 text-green-800"
                    }
                  >
                    {alert.status}
                  </Badge>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Check className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderAPIManagement = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">API Management</h2>
        <div className="flex items-center gap-4">
          <Button variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh Stats
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Endpoint
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Requests</p>
                <p className="text-2xl font-bold text-teal-600">89.9K</p>
                <p className="text-xs text-green-600">+12% vs yesterday</p>
              </div>
              <Activity className="h-8 w-8 text-teal-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Avg Response</p>
                <p className="text-2xl font-bold text-blue-600">245ms</p>
                <p className="text-xs text-green-600">-15ms vs yesterday</p>
              </div>
              <TrendingUp className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Error Rate</p>
                <p className="text-2xl font-bold text-green-600">0.4%</p>
                <p className="text-xs text-green-600">-0.2% vs yesterday</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Rate Limit Usage</p>
                <p className="text-2xl font-bold text-yellow-600">67%</p>
                <p className="text-xs text-yellow-600">Peak usage</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>API Endpoints</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {apiEndpoints.map((endpoint, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center text-white">
                    <Globe className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="font-medium">{endpoint.name}</div>
                    <div className="text-sm text-gray-500 font-mono">{endpoint.endpoint}</div>
                    <div className="text-sm text-gray-400">Rate Limit: {endpoint.rateLimit}</div>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <div className="text-sm font-medium">{endpoint.requests.toLocaleString()}</div>
                    <div className="text-xs text-gray-500">Requests</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">{endpoint.avgResponse}ms</div>
                    <div className="text-xs text-gray-500">Avg Response</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">{endpoint.errorRate}%</div>
                    <div className="text-xs text-gray-500">Error Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">{endpoint.uptime}%</div>
                    <div className="text-xs text-gray-500">Uptime</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Settings className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderPaymentSystems = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Payment Systems</h2>
        <div className="flex items-center gap-4">
          <Button variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Sync Payments
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Gateway
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Processed</p>
                <p className="text-2xl font-bold text-teal-600">$1.02M</p>
                <p className="text-xs text-green-600">+12.5% vs last month</p>
              </div>
              <CreditCard className="h-8 w-8 text-teal-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Success Rate</p>
                <p className="text-2xl font-bold text-green-600">98.7%</p>
                <p className="text-xs text-green-600">+0.3% vs last month</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Failed Payments</p>
                <p className="text-2xl font-bold text-red-600">1.3%</p>
                <p className="text-xs text-red-600">-0.3% vs last month</p>
              </div>
              <X className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Avg Processing</p>
                <p className="text-2xl font-bold text-blue-600">2.3s</p>
                <p className="text-xs text-green-600">-0.5s vs last month</p>
              </div>
              <Activity className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Payment Methods</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={[
                    { name: "Credit Cards", value: 65, color: "#10B981" },
                    { name: "PayPal", value: 20, color: "#3B82F6" },
                    { name: "Bank Transfer", value: 10, color: "#8B5CF6" },
                    { name: "Other", value: 5, color: "#F59E0B" },
                  ]}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  dataKey="value"
                >
                  {[
                    { name: "Credit Cards", value: 65, color: "#10B981" },
                    { name: "PayPal", value: 20, color: "#3B82F6" },
                    { name: "Bank Transfer", value: 10, color: "#8B5CF6" },
                    { name: "Other", value: 5, color: "#F59E0B" },
                  ].map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Gateway Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: "Stripe", status: "healthy", uptime: "99.9%", volume: "$456K" },
                { name: "PayPal", status: "healthy", uptime: "99.7%", volume: "$234K" },
                { name: "Square", status: "warning", uptime: "98.5%", volume: "$123K" },
                { name: "Braintree", status: "healthy", uptime: "99.8%", volume: "$89K" },
              ].map((gateway, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-white ${
                        gateway.status === "healthy" ? "bg-green-500" : "bg-yellow-500"
                      }`}
                    >
                      <CreditCard className="h-4 w-4" />
                    </div>
                    <div>
                      <div className="font-medium">{gateway.name}</div>
                      <div className="text-sm text-gray-500">Uptime: {gateway.uptime}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">{gateway.volume}</div>
                    <Badge
                      className={
                        gateway.status === "healthy" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                      }
                    >
                      {gateway.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  const renderLoyaltyPrograms = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Loyalty Programs</h2>
        <div className="flex items-center gap-4">
          <Button variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Sync Programs
          </Button>
          <Button onClick={handleAddProgram}>
            <Plus className="h-4 w-4 mr-2" />
            Add Program
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Active Programs</p>
                <p className="text-2xl font-bold text-teal-600">{loyaltyPrograms.length}</p>
              </div>
              <Star className="h-8 w-8 text-teal-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Commission</p>
                <p className="text-2xl font-bold text-green-600">$89.2K</p>
                <p className="text-xs text-green-600">+15.7% vs last month</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Partner Airlines</p>
                <p className="text-2xl font-bold text-blue-600">
                  {loyaltyPrograms.filter((p) => p.type === "airline").length}
                </p>
              </div>
              <Plane className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Avg Point Value</p>
                <p className="text-2xl font-bold text-purple-600">1.2¢</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Program Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {loyaltyPrograms.map((program) => (
              <div key={program.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-4">
                  <div
                    className={`w-10 h-10 ${getTypeColor(program.type)} rounded-full flex items-center justify-center text-white`}
                  >
                    {getTypeIcon(program.type)}
                  </div>
                  <div>
                    <div className="font-medium">{program.name}</div>
                    <div className="text-sm text-gray-500">{program.partner}</div>
                    <div className="text-sm text-gray-400">Contract expires: {program.contract}</div>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <div className="text-sm font-medium">{program.bookings}</div>
                    <div className="text-xs text-gray-500">Bookings</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">${program.revenue.toLocaleString()}</div>
                    <div className="text-xs text-gray-500">Revenue</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">{program.commission}%</div>
                    <div className="text-xs text-gray-500">Commission</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">{program.pointValue}¢</div>
                    <div className="text-xs text-gray-500">Point Value</div>
                  </div>
                  <Badge
                    className={
                      program.type === "airline"
                        ? "bg-blue-100 text-blue-800"
                        : program.type === "hotel"
                          ? "bg-green-100 text-green-800"
                          : "bg-purple-100 text-purple-800"
                    }
                  >
                    {program.type.replace("_", " ")}
                  </Badge>
                  <Badge
                    className={
                      program.status === "active"
                        ? "bg-green-100 text-green-800"
                        : program.status === "negotiating"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-gray-100 text-gray-800"
                    }
                  >
                    {program.status}
                  </Badge>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleEditProgram(program)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    {(program.type === "airline" || program.type === "hotel") && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleOpenRedemptionChart(program)}
                          className="text-purple-600 border-purple-200 hover:bg-purple-50"
                        >
                          📊
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleOpenRedemptionModal(program)}
                          className="text-green-600 border-green-200 hover:bg-green-50"
                        >
                          ✈️
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Program Modal */}
      {(editingProgram || addingProgram) && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-[600px] max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">
                {addingProgram ? "Add New Loyalty Program" : "Edit Loyalty Program"}
              </h3>
              <Button variant="ghost" size="sm" onClick={handleCancelEdit}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Program Name</label>
                  <Input
                    value={editFormData.name}
                    onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                    placeholder="e.g., United MileagePlus"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Partner</label>
                  <Input
                    value={editFormData.partner}
                    onChange={(e) => setEditFormData({ ...editFormData, partner: e.target.value })}
                    placeholder="e.g., United Airlines"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Program Type</label>
                <Select
                  value={editFormData.type}
                  onValueChange={(value) => setEditFormData({ ...editFormData, type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="airline">Airline Program</SelectItem>
                    <SelectItem value="hotel">Hotel Program</SelectItem>
                    <SelectItem value="credit_card">Credit Card Program</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Commission (%)</label>
                  <Input
                    type="number"
                    step="0.1"
                    value={editFormData.commission}
                    onChange={(e) =>
                      setEditFormData({ ...editFormData, commission: Number.parseFloat(e.target.value) })
                    }
                    placeholder="2.8"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Point Value (¢)</label>
                  <Input
                    type="number"
                    step="0.001"
                    value={editFormData.pointValue}
                    onChange={(e) =>
                      setEditFormData({ ...editFormData, pointValue: Number.parseFloat(e.target.value) })
                    }
                    placeholder="0.012"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <Select
                    value={editFormData.status}
                    onValueChange={(value) => setEditFormData({ ...editFormData, status: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="negotiating">Negotiating</SelectItem>
                      <SelectItem value="suspended">Suspended</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Contract Expiry</label>
                  <Input
                    type="date"
                    value={editFormData.contract}
                    onChange={(e) => setEditFormData({ ...editFormData, contract: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Program Perks</label>
                <div className="space-y-2">
                  {editFormData.perks.map((perk, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div className="flex-1 p-2 bg-gray-50 rounded text-sm">{perk}</div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleRemovePerk(index)}
                        className="text-red-600"
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                  <div className="flex items-center gap-2">
                    <Input
                      value={newPerk}
                      onChange={(e) => setNewPerk(e.target.value)}
                      placeholder="Add a new perk..."
                      onKeyPress={(e) => e.key === "Enter" && handleAddPerk()}
                    />
                    <Button size="sm" onClick={handleAddPerk} disabled={!newPerk.trim()}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 mt-6">
              <Button onClick={handleSaveProgram} className="flex-1">
                <Save className="h-4 w-4 mr-2" />
                {addingProgram ? "Add Program" : "Save Changes"}
              </Button>
              <Button variant="outline" onClick={handleCancelEdit} className="flex-1 bg-transparent">
                Cancel
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* NEW REDEMPTION CHART MODAL */}
      {showRedemptionChart && selectedProgramForChart && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-[700px] max-w-3xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold">📊 Redemption Chart</h3>
                <p className="text-sm text-gray-600">{selectedProgramForChart.name} - Status Multipliers</p>
              </div>
              <Button variant="ghost" size="sm" onClick={handleCancelRedemptionChart}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="border rounded-lg p-4 bg-gray-50">
              <div className="grid grid-cols-12 gap-4 mb-3 text-sm font-medium text-gray-700">
                <div className="col-span-6">Status</div>
                <div className="col-span-4">Multiplier</div>
                <div className="col-span-2">Actions</div>
              </div>

              <div className="space-y-2">
                {chartData.map((item, index) => (
                  <div key={index} className="grid grid-cols-12 gap-4 items-center">
                    <div className="col-span-6">
                      <Input
                        value={item.status}
                        onChange={(e) => handleStatusChange(index, "status", e.target.value)}
                        placeholder="e.g., Premier Silver"
                        className="bg-white"
                      />
                    </div>
                    <div className="col-span-4">
                      <Input
                        type="number"
                        value={item.multiplier}
                        onChange={(e) => handleStatusChange(index, "multiplier", e.target.value)}
                        placeholder="5"
                        className="bg-white"
                      />
                    </div>
                    <div className="col-span-2 flex items-center gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleRemoveStatus(index)}
                        className="text-red-600 border-red-200 hover:bg-red-50"
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 pt-3 border-t">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleAddStatus}
                  className="text-green-600 border-green-200 hover:bg-green-50 bg-transparent"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Status Tier
                </Button>
              </div>
            </div>

            <div className="flex items-center gap-3 mt-6">
              <Button onClick={handleSaveRedemptionChart} className="flex-1">
                <Save className="h-4 w-4 mr-2" />
                Save Redemption Chart
              </Button>
              <Button variant="outline" onClick={handleCancelRedemptionChart} className="flex-1 bg-transparent">
                Cancel
              </Button>
            </div>
          </div>
        </div>
      )}

      {showRedemptionModal && selectedProgramForRedemption && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-[900px] max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold">✈️ Redemption Chart</h3>
                <p className="text-sm text-gray-600">{selectedProgramForRedemption.name} - Fare Classes & Miles</p>
              </div>
              <Button variant="ghost" size="sm" onClick={handleCancelRedemptionModal}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="border rounded-lg p-4 bg-gray-50">
              <div className="grid grid-cols-12 gap-4 mb-3 text-sm font-medium text-gray-700 bg-white p-3 rounded border">
                <div className="col-span-1"></div>
                <div className="col-span-3">Tarifa</div>
                <div className="col-span-2">Clase</div>
                <div className="col-span-3">M. Calificación</div>
                <div className="col-span-3">M. Premio</div>
              </div>

              <div className="space-y-2">
                {redemptionData.map((item, index) => (
                  <div key={index} className="grid grid-cols-12 gap-4 items-center bg-white p-3 rounded border">
                    <div className="col-span-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleRemoveRedemptionRow(index)}
                        className="text-red-600 border-red-200 hover:bg-red-50 w-8 h-8 p-0"
                      >
                        🗑️
                      </Button>
                    </div>
                    <div className="col-span-3">
                      <Input
                        value={item.tarifa}
                        onChange={(e) => {
                          const value = e.target.value.replace(/[^a-zA-Z\s]/g, "")
                          handleRedemptionChange(index, "tarifa", value)
                        }}
                        placeholder="e.g., Ejecutiva Full"
                        className="bg-white"
                      />
                    </div>
                    <div className="col-span-2">
                      <Input
                        value={item.clase}
                        onChange={(e) => {
                          const value = e.target.value.replace(/[^a-zA-Z,\s]/g, "")
                          handleRedemptionChange(index, "clase", value)
                        }}
                        placeholder="e.g., J"
                        className="bg-white"
                      />
                    </div>
                    <div className="col-span-3">
                      <Input
                        type="number"
                        value={item.calificacion}
                        onChange={(e) => handleRedemptionChange(index, "calificacion", e.target.value)}
                        placeholder="300"
                        className="bg-white"
                      />
                    </div>
                    <div className="col-span-3">
                      <Input
                        type="number"
                        value={item.premio}
                        onChange={(e) => handleRedemptionChange(index, "premio", e.target.value)}
                        placeholder="300"
                        className="bg-white"
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 pt-3">
                <Button onClick={handleAddRedemptionRow} className="bg-green-500 hover:bg-green-600 text-white">
                  Agregar +
                </Button>
              </div>
            </div>

            <div className="flex items-center gap-3 mt-6">
              <Button onClick={handleSaveRedemptionModal} className="flex-1">
                <Save className="h-4 w-4 mr-2" />
                Save Redemption Chart
              </Button>
              <Button variant="outline" onClick={handleCancelRedemptionModal} className="flex-1 bg-transparent">
                Cancel
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )

  const renderSubscriptionPlans = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Subscription Plans</h2>
        <div className="flex items-center gap-4">
          <Select defaultValue="all">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Plans</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
            </SelectContent>
          </Select>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Create Plan
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Subscribers</p>
                <p className="text-2xl font-bold text-teal-600">13,779</p>
                <p className="text-xs text-green-600">+8.2% vs last month</p>
              </div>
              <Users className="h-8 w-8 text-teal-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Monthly Revenue</p>
                <p className="text-2xl font-bold text-green-600">$69.7K</p>
                <p className="text-xs text-green-600">+15.3% vs last month</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Avg Conversion</p>
                <p className="text-2xl font-bold text-blue-600">23.4%</p>
                <p className="text-xs text-green-600">+2.1% vs last month</p>
              </div>
              <TrendingUp className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Avg Churn Rate</p>
                <p className="text-2xl font-bold text-orange-600">4.2%</p>
                <p className="text-xs text-green-600">-1.3% vs last month</p>
              </div>
              <TrendingDown className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {subscriptionPlans.map((plan) => {
          const IconComponent = plan.icon
          return (
            <Card key={plan.id} className="relative overflow-hidden">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 ${plan.color} rounded-lg flex items-center justify-center text-white`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{plan.name}</CardTitle>
                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl font-bold">{plan.price === 0 ? "Free" : `$${plan.price}`}</span>
                        {plan.price > 0 && <span className="text-gray-500">/{plan.period}</span>}
                      </div>
                    </div>
                  </div>
                  <Badge
                    className={plan.status === "active" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}
                  >
                    {plan.status}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 mt-2">{plan.description}</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-lg font-bold text-teal-600">{plan.users.toLocaleString()}</div>
                    <div className="text-xs text-gray-500">Active Users</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-lg font-bold text-green-600">
                      {plan.revenue === 0 ? "Free" : `$${plan.revenue.toLocaleString()}`}
                    </div>
                    <div className="text-xs text-gray-500">Monthly Revenue</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <div className="text-lg font-bold text-blue-600">{plan.conversionRate}</div>
                    <div className="text-xs text-gray-500">Conversion Rate</div>
                  </div>
                  <div className="text-center p-3 bg-orange-50 rounded-lg">
                    <div className="text-lg font-bold text-orange-600">{plan.churnRate}</div>
                    <div className="text-xs text-gray-500">Churn Rate</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Plan Features:</h4>
                  <div className="space-y-1">
                    {plan.features.slice(0, 4).map((feature, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                        <CheckCircle className="h-3 w-3 text-green-500 flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                    {plan.features.length > 4 && (
                      <div className="text-xs text-gray-500">+{plan.features.length - 4} more features</div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                    <Eye className="h-4 w-4 mr-2" />
                    View Details
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Plan
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Plan Performance Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={subscriptionPlans}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="users" fill="#14B8A6" name="Users" />
              <Bar dataKey="revenue" fill="#10B981" name="Revenue" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )

  const renderSystemSettings = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">System Settings</h2>
        <div className="flex items-center gap-4">
          <Button variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Reset to Defaults
          </Button>
          <Button>
            <Save className="h-4 w-4 mr-2" />
            Save Changes
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Platform Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Maintenance Mode</div>
                <div className="text-sm text-gray-500">Enable maintenance mode for updates</div>
              </div>
              <Switch />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">User Registration</div>
                <div className="text-sm text-gray-500">Allow new user registrations</div>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Email Notifications</div>
                <div className="text-sm text-gray-500">Send system notifications via email</div>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Debug Mode</div>
                <div className="text-sm text-gray-500">Enable detailed error logging</div>
              </div>
              <Switch />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>API Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium">Rate Limit (requests/minute)</label>
              <Input defaultValue="1000" className="mt-1" />
            </div>
            <div>
              <label className="text-sm font-medium">API Timeout (seconds)</label>
              <Input defaultValue="30" className="mt-1" />
            </div>
            <div>
              <label className="text-sm font-medium">Cache TTL (minutes)</label>
              <Input defaultValue="60" className="mt-1" />
            </div>
            <div>
              <label className="text-sm font-medium">Max Concurrent Requests</label>
              <Input defaultValue="100" className="mt-1" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Security Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Two-Factor Authentication</div>
                <div className="text-sm text-gray-500">Require 2FA for admin accounts</div>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">IP Whitelist</div>
                <div className="text-sm text-gray-500">Restrict admin access by IP</div>
              </div>
              <Switch />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Session Timeout</div>
                <div className="text-sm text-gray-500">Auto-logout after inactivity</div>
              </div>
              <Switch defaultChecked />
            </div>
            <div>
              <label className="text-sm font-medium">Session Duration (hours)</label>
              <Input defaultValue="8" className="mt-1" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Notification Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium">Admin Email</label>
              <Input defaultValue="admin@trilla.com" className="mt-1" />
            </div>
            <div>
              <label className="text-sm font-medium">Alert Webhook URL</label>
              <Input placeholder="https://hooks.slack.com/..." className="mt-1" />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Critical Alert SMS</div>
                <div className="text-sm text-gray-500">Send SMS for critical alerts</div>
              </div>
              <Switch defaultChecked />
            </div>
            <div>
              <label className="text-sm font-medium">SMS Phone Number</label>
              <Input placeholder="+1 (555) 123-4567" className="mt-1" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>System Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-6">
            <div>
              <div className="text-sm text-gray-500">Platform Version</div>
              <div className="font-medium">v2.4.1</div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Database Version</div>
              <div className="font-medium">PostgreSQL 14.2</div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Last Backup</div>
              <div className="font-medium">2 hours ago</div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Server Uptime</div>
              <div className="font-medium">15 days, 4 hours</div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Disk Usage</div>
              <div className="font-medium">67% (340GB / 500GB)</div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Memory Usage</div>
              <div className="font-medium">45% (7.2GB / 16GB)</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="text-2xl font-bold">
              <span className="text-teal-500">TRILL</span>
              <span className="text-gray-800">A</span>
            </div>
            <Badge className="bg-red-100 text-red-800 flex items-center gap-1">
              <Shield className="h-3 w-3" />
              Admin Control Panel
            </Badge>
          </div>

          <div className="flex items-center gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search users, bookings, tickets..."
                className="pl-10 w-80"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Notifications */}
            <Button variant="outline" size="sm" className="relative bg-transparent">
              <Bell className="h-4 w-4" />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                3
              </span>
            </Button>

            {/* Time Filter */}
            <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 90 days</SelectItem>
                <SelectItem value="1y">Last year</SelectItem>
              </SelectContent>
            </Select>

            {/* Admin Profile */}
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                A
              </div>
              <span className="text-sm font-medium">Super Admin</span>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Admin Sidebar */}
        <aside className="w-64 bg-white border-r border-gray-200 min-h-screen">
          <div className="p-4">
            <div className="space-y-2">
              <Button
                className={`w-full justify-start ${
                  activeSection === "analytics" ? "bg-teal-500 text-white hover:bg-teal-600" : "text-gray-600"
                }`}
                variant={activeSection === "analytics" ? "default" : "ghost"}
                onClick={() => setActiveSection("analytics")}
              >
                <BarChart3 className="mr-3 h-4 w-4" />
                Analytics Dashboard
              </Button>

              <Button
                className={`w-full justify-start ${
                  activeSection === "users" ? "bg-teal-500 text-white hover:bg-teal-600" : "text-gray-600"
                }`}
                variant={activeSection === "users" ? "default" : "ghost"}
                onClick={() => setActiveSection("users")}
              >
                <Users className="mr-3 h-4 w-4" />
                User Management
              </Button>

              <Button
                className={`w-full justify-start ${
                  activeSection === "flights" ? "bg-teal-500 text-white hover:bg-teal-600" : "text-gray-600"
                }`}
                variant={activeSection === "flights" ? "default" : "ghost"}
                onClick={() => setActiveSection("flights")}
              >
                <Plane className="mr-3 h-4 w-4" />
                Flight Operations
              </Button>

              <Button
                className={`w-full justify-start ${
                  activeSection === "financial" ? "bg-teal-500 text-white hover:bg-teal-600" : "text-gray-600"
                }`}
                variant={activeSection === "financial" ? "default" : "ghost"}
                onClick={() => setActiveSection("financial")}
              >
                <DollarSign className="mr-3 h-4 w-4" />
                Financial Reports
              </Button>

              <Button
                className={`w-full justify-start ${
                  activeSection === "support" ? "bg-teal-500 text-white hover:bg-teal-600" : "text-gray-600"
                }`}
                variant={activeSection === "support" ? "default" : "ghost"}
                onClick={() => setActiveSection("support")}
              >
                <MessageSquare className="mr-3 h-4 w-4" />
                Support Center
              </Button>

              <Button
                className={`w-full justify-start ${
                  activeSection === "health" ? "bg-teal-500 text-white hover:bg-teal-600" : "text-gray-600"
                }`}
                variant={activeSection === "health" ? "default" : "ghost"}
                onClick={() => setActiveSection("health")}
              >
                <Activity className="mr-3 h-4 w-4" />
                System Health
              </Button>

              <Button
                className={`w-full justify-start ${
                  activeSection === "alerts" ? "bg-teal-500 text-white hover:bg-teal-600" : "text-gray-600"
                }`}
                variant={activeSection === "alerts" ? "default" : "ghost"}
                onClick={() => setActiveSection("alerts")}
              >
                <AlertTriangle className="mr-3 h-4 w-4" />
                Alert Management
              </Button>

              <Button
                className={`w-full justify-start ${
                  activeSection === "api" ? "bg-teal-500 text-white hover:bg-teal-600" : "text-gray-600"
                }`}
                variant={activeSection === "api" ? "default" : "ghost"}
                onClick={() => setActiveSection("api")}
              >
                <Globe className="mr-3 h-4 w-4" />
                API Management
              </Button>

              <Button
                className={`w-full justify-start ${
                  activeSection === "payments" ? "bg-teal-500 text-white hover:bg-teal-600" : "text-gray-600"
                }`}
                variant={activeSection === "payments" ? "default" : "ghost"}
                onClick={() => setActiveSection("payments")}
              >
                <CreditCard className="mr-3 h-4 w-4" />
                Payment Systems
              </Button>

              <Button
                className={`w-full justify-start ${
                  activeSection === "loyalty" ? "bg-teal-500 text-white hover:bg-teal-600" : "text-gray-600"
                }`}
                variant={activeSection === "loyalty" ? "default" : "ghost"}
                onClick={() => setActiveSection("loyalty")}
              >
                <Star className="mr-3 h-4 w-4" />
                Loyalty Programs
              </Button>

              <Button
                className={`w-full justify-start ${
                  activeSection === "subscriptions" ? "bg-teal-500 text-white hover:bg-teal-600" : "text-gray-600"
                }`}
                variant={activeSection === "subscriptions" ? "default" : "ghost"}
                onClick={() => setActiveSection("subscriptions")}
              >
                <Crown className="mr-3 h-4 w-4" />
                Subscription Plans
              </Button>

              <Button
                className={`w-full justify-start ${
                  activeSection === "settings" ? "bg-teal-500 text-white hover:bg-teal-600" : "text-gray-600"
                }`}
                variant={activeSection === "settings" ? "default" : "ghost"}
                onClick={() => setActiveSection("settings")}
              >
                <Settings className="mr-3 h-4 w-4" />
                System Settings
              </Button>
            </div>
          </div>
        </aside>

        {/* Main Admin Content */}
        <main className="flex-1 p-6">{renderContent()}</main>
      </div>
    </div>
  )
}
