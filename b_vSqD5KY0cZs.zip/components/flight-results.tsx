"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, CreditCard, DollarSign, Heart, Plane, Check } from "lucide-react"
import Link from "next/link"

// Mock flight data with cabin classes
const flights = [
  {
    id: "1",
    airline: "British Airways",
    alliance: "Oneworld",
    departTime: "8:30 AM",
    arriveTime: "10:45 PM",
    duration: "7h 15m",
    stops: 0,
    cabins: {
      economy: {
        name: "Economy Basic",
        price: 850,
        milesPrice: 60000,
        milesValue: 1.42,
        potentialMiles: 3458,
        statusMultiplier: 1.0,
        benefits: ["Personal item", "Seat selection for fee", "Standard meal"],
        baggage: "Carry-on: $35, Checked: $60",
      },
      premium: {
        name: "Premium Economy",
        price: 1250,
        milesPrice: 85000,
        milesValue: 1.47,
        potentialMiles: 5187,
        statusMultiplier: 1.25,
        benefits: ["Priority boarding", "Extra legroom", "Premium meal", "Free checked bag"],
        baggage: "Carry-on: Free, Checked: Free (1 bag)",
      },
      business: {
        name: "Business Class",
        price: 3200,
        milesPrice: 120000,
        milesValue: 2.67,
        potentialMiles: 10374,
        statusMultiplier: 2.0,
        benefits: ["Lie-flat seat", "Lounge access", "Premium dining", "Priority everything"],
        baggage: "Carry-on: Free, Checked: Free (2 bags)",
      },
      first: {
        name: "First Class",
        price: 5800,
        milesPrice: 180000,
        milesValue: 3.22,
        potentialMiles: 17290,
        statusMultiplier: 3.0,
        benefits: ["Private suite", "Concierge service", "Chef-prepared meals", "Chauffeur service"],
        baggage: "Carry-on: Free, Checked: Free (3 bags)",
      },
    },
    bestCreditCard: "Chase Sapphire Reserve",
    cardBonus: "3x",
  },
  {
    id: "2",
    airline: "American Airlines",
    alliance: "Oneworld",
    departTime: "10:15 AM",
    arriveTime: "11:30 PM",
    duration: "7h 15m",
    stops: 0,
    cabins: {
      economy: {
        name: "Main Cabin",
        price: 780,
        milesPrice: 65000,
        milesValue: 1.2,
        potentialMiles: 3458,
        statusMultiplier: 1.0,
        benefits: ["Personal item", "Seat selection for fee", "Complimentary snacks"],
        baggage: "Carry-on: Free, Checked: $30",
      },
      premium: {
        name: "Premium Economy",
        price: 1180,
        milesPrice: 90000,
        milesValue: 1.31,
        potentialMiles: 5187,
        statusMultiplier: 1.5,
        benefits: ["Priority boarding", "Extra legroom", "Free drinks", "Free checked bag"],
        baggage: "Carry-on: Free, Checked: Free (1 bag)",
      },
      business: {
        name: "Business Class",
        price: 2950,
        milesPrice: 115000,
        milesValue: 2.57,
        potentialMiles: 10374,
        statusMultiplier: 2.0,
        benefits: ["Lie-flat seat", "Flagship Lounge", "Premium dining", "Priority check-in"],
        baggage: "Carry-on: Free, Checked: Free (2 bags)",
      },
      first: {
        name: "Flagship First",
        price: 5200,
        milesPrice: 170000,
        milesValue: 3.06,
        potentialMiles: 17290,
        statusMultiplier: 3.0,
        benefits: ["Private suite", "Flagship First Dining", "Premium amenities", "Concierge service"],
        baggage: "Carry-on: Free, Checked: Free (3 bags)",
      },
    },
    bestCreditCard: "Citi AAdvantage",
    cardBonus: "2x",
  },
  {
    id: "3",
    airline: "Delta Air Lines",
    alliance: "SkyTeam",
    departTime: "1:45 PM",
    arriveTime: "3:20 AM",
    duration: "7h 35m",
    stops: 0,
    cabins: {
      economy: {
        name: "Main Cabin",
        price: 795,
        milesPrice: 70000,
        milesValue: 1.14,
        potentialMiles: 3458,
        statusMultiplier: 1.0,
        benefits: ["Personal item", "Seat selection for fee", "Complimentary snacks"],
        baggage: "Carry-on: Free, Checked: $30",
      },
      premium: {
        name: "Comfort+",
        price: 1195,
        milesPrice: 95000,
        milesValue: 1.26,
        potentialMiles: 5187,
        statusMultiplier: 1.5,
        benefits: ["Priority boarding", "Extra legroom", "Free drinks", "Sky Priority"],
        baggage: "Carry-on: Free, Checked: Free (1 bag)",
      },
      business: {
        name: "Delta One",
        price: 3100,
        milesPrice: 125000,
        milesValue: 2.48,
        potentialMiles: 10374,
        statusMultiplier: 2.0,
        benefits: ["Lie-flat suite", "Sky Club access", "Chef-curated meals", "Premium amenities"],
        baggage: "Carry-on: Free, Checked: Free (2 bags)",
      },
      first: {
        name: "Delta One Suites",
        price: 5500,
        milesPrice: 175000,
        milesValue: 3.14,
        potentialMiles: 17290,
        statusMultiplier: 3.0,
        benefits: ["Private suite with door", "Premium dining", "Luxury amenities", "Dedicated service"],
        baggage: "Carry-on: Free, Checked: Free (3 bags)",
      },
    },
    bestCreditCard: "Amex Platinum",
    cardBonus: "5x",
  },
  {
    id: "4",
    airline: "Virgin Atlantic",
    alliance: "None",
    departTime: "7:30 PM",
    arriveTime: "9:45 AM",
    duration: "8h 15m",
    stops: 0,
    cabins: {
      economy: {
        name: "Economy",
        price: 760,
        milesPrice: 55000,
        milesValue: 1.38,
        potentialMiles: 3458,
        statusMultiplier: 1.0,
        benefits: ["Personal item", "Seat selection for fee", "Complimentary meal"],
        baggage: "Carry-on: Free, Checked: $25",
      },
      premium: {
        name: "Premium",
        price: 1150,
        milesPrice: 80000,
        milesValue: 1.44,
        potentialMiles: 5187,
        statusMultiplier: 1.5,
        benefits: ["Priority check-in", "Extra legroom", "Premium meal", "Free bar"],
        baggage: "Carry-on: Free, Checked: Free (1 bag)",
      },
      business: {
        name: "Upper Class",
        price: 2850,
        milesPrice: 110000,
        milesValue: 2.59,
        potentialMiles: 10374,
        statusMultiplier: 2.0,
        benefits: ["Lie-flat seat", "Clubhouse access", "Premium dining", "Onboard bar"],
        baggage: "Carry-on: Free, Checked: Free (2 bags)",
      },
      first: {
        name: "Upper Class Suite",
        price: 4900,
        milesPrice: 160000,
        milesValue: 3.06,
        potentialMiles: 17290,
        statusMultiplier: 3.0,
        benefits: ["Private suite", "Premium service", "Fine dining", "Luxury amenities"],
        baggage: "Carry-on: Free, Checked: Free (3 bags)",
      },
    },
    bestCreditCard: "Amex Gold",
    cardBonus: "3x",
  },
]

export function FlightResults() {
  const [selectedFlightId, setSelectedFlightId] = useState<string | null>(null)
  const [favoriteFlights, setFavoriteFlights] = useState<string[]>([])
  const [selectedCabin, setSelectedCabin] = useState<{ [key: string]: string }>({})

  const toggleFavorite = (id: string) => {
    if (favoriteFlights.includes(id)) {
      setFavoriteFlights(favoriteFlights.filter((flightId) => flightId !== id))
    } else {
      setFavoriteFlights([...favoriteFlights, id])
    }
  }

  const getSelectedCabinData = (flight: (typeof flights)[0]) => {
    const cabinKey = selectedCabin[flight.id] || "economy"
    return flight.cabins[cabinKey as keyof typeof flight.cabins]
  }

  return (
    <div className="space-y-4">
      {flights.map((flight) => {
        const currentCabin = getSelectedCabinData(flight)

        return (
          <Card key={flight.id} className={selectedFlightId === flight.id ? "border-primary" : ""}>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                    <Plane className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="font-medium">{flight.airline}</div>
                    <div className="text-sm text-muted-foreground">{flight.alliance}</div>
                  </div>
                </div>

                <div className="flex items-center justify-center">
                  <div className="text-center">
                    <div className="font-medium">{flight.departTime}</div>
                    <div className="text-sm text-muted-foreground">JFK</div>
                  </div>
                  <div className="mx-2 md:mx-4 flex flex-col items-center">
                    <div className="text-xs text-muted-foreground mb-1">{flight.duration}</div>
                    <div className="relative w-16 md:w-24">
                      <div className="border-t border-dashed border-gray-300 absolute w-full top-1/2"></div>
                      <ArrowRight className="h-3 w-3 absolute right-0 top-1/2 -translate-y-1/2" />
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {flight.stops === 0 ? "Nonstop" : `${flight.stops} stop`}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="font-medium">{flight.arriveTime}</div>
                    <div className="text-sm text-muted-foreground">LHR</div>
                  </div>
                </div>

                <div className="flex flex-col items-end justify-center">
                  <div className="text-2xl font-bold">${currentCabin.price}</div>
                  <div className="text-sm text-muted-foreground">
                    or {currentCabin.milesPrice.toLocaleString()} miles
                  </div>
                  <Badge variant="outline" className="mt-1">
                    {currentCabin.milesValue}¢ per mile
                  </Badge>
                  <div className="text-xs text-muted-foreground mt-1">{currentCabin.name}</div>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-3">
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  Earn {currentCabin.potentialMiles.toLocaleString()} miles
                </Badge>
                {currentCabin.milesValue > 1.3 ? (
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                    Recommended: Use Miles (Good value!)
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                    Recommended: Pay Cash & Earn Miles
                  </Badge>
                )}
              </div>

              {selectedFlightId === flight.id && (
                <div className="mt-6 pt-6 border-t">
                  <Tabs defaultValue="cabins">
                    <TabsList className="mb-4">
                      <TabsTrigger value="cabins">Cabin Options</TabsTrigger>
                      <TabsTrigger value="compare">Cash vs Miles</TabsTrigger>
                      <TabsTrigger value="earn">Miles Earned</TabsTrigger>
                      <TabsTrigger value="card">Best Card</TabsTrigger>
                      <TabsTrigger value="redeem">Redemption Guide</TabsTrigger>
                    </TabsList>

                    <TabsContent value="cabins" className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.entries(flight.cabins).map(([cabinKey, cabin]) => (
                          <Card
                            key={cabinKey}
                            className={`cursor-pointer transition-all ${
                              (selectedCabin[flight.id] || "economy") === cabinKey
                                ? "border-primary bg-primary/5"
                                : "hover:border-gray-300"
                            }`}
                            onClick={() => setSelectedCabin({ ...selectedCabin, [flight.id]: cabinKey })}
                          >
                            <CardContent className="p-4">
                              <div className="flex justify-between items-start mb-3">
                                <div>
                                  <h3 className="font-medium">{cabin.name}</h3>
                                  <div className="text-sm text-muted-foreground capitalize">{cabinKey} Class</div>
                                </div>
                                {(selectedCabin[flight.id] || "economy") === cabinKey && (
                                  <Badge variant="default" className="bg-primary">
                                    Selected
                                  </Badge>
                                )}
                              </div>

                              <div className="grid grid-cols-2 gap-4 mb-4">
                                <div>
                                  <div className="text-lg font-bold">${cabin.price}</div>
                                  <div className="text-xs text-muted-foreground">Cash price</div>
                                </div>
                                <div>
                                  <div className="text-lg font-bold">{cabin.milesPrice.toLocaleString()}</div>
                                  <div className="text-xs text-muted-foreground">Miles needed</div>
                                </div>
                              </div>

                              <div className="mb-4">
                                <div className="flex items-center gap-2 mb-2">
                                  <Plane className="h-4 w-4 text-green-600" />
                                  <span className="text-sm font-medium">
                                    Earn {cabin.potentialMiles.toLocaleString()} miles
                                  </span>
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  {cabin.statusMultiplier}x status multiplier
                                </div>
                              </div>

                              <div className="space-y-2">
                                <h4 className="text-sm font-medium">Key Benefits:</h4>
                                <div className="space-y-1">
                                  {cabin.benefits.slice(0, 3).map((benefit, index) => (
                                    <div key={index} className="flex items-center gap-2 text-xs">
                                      <Check className="h-3 w-3 text-green-600" />
                                      <span>{benefit}</span>
                                    </div>
                                  ))}
                                </div>
                                <div className="text-xs text-muted-foreground mt-2">{cabin.baggage}</div>
                              </div>

                              {cabinKey !== "economy" && (
                                <div className="mt-3 pt-3 border-t">
                                  <div className="text-xs text-muted-foreground">
                                    Upgrade from Economy: +${cabin.price - flight.cabins.economy.price}
                                  </div>
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        ))}
                      </div>

                      <div className="bg-muted/50 p-4 rounded-lg">
                        <h3 className="font-medium mb-2">Cabin Comparison</h3>
                        <div className="grid grid-cols-4 gap-4 text-sm">
                          <div className="font-medium">Feature</div>
                          <div className="font-medium">Economy</div>
                          <div className="font-medium">Premium</div>
                          <div className="font-medium">Business+</div>

                          <div className="text-muted-foreground">Miles Earning</div>
                          <div>1x base</div>
                          <div>1.5x base</div>
                          <div>2-3x base</div>

                          <div className="text-muted-foreground">Seat</div>
                          <div>Standard</div>
                          <div>Extra legroom</div>
                          <div>Lie-flat</div>

                          <div className="text-muted-foreground">Baggage</div>
                          <div>Fee applies</div>
                          <div>1 free</div>
                          <div>2-3 free</div>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="compare" className="space-y-4">
                      <div className="grid grid-cols-2 gap-6">
                        <div className="bg-muted/50 p-4 rounded-lg">
                          <h3 className="font-medium mb-2 flex items-center">
                            <DollarSign className="h-4 w-4 mr-1" />
                            Cash Price ({currentCabin.name})
                          </h3>
                          <div className="text-2xl font-bold">${currentCabin.price}</div>
                          <p className="text-sm text-muted-foreground mt-2">
                            Paying with cash gives you flexibility and allows you to earn{" "}
                            {currentCabin.potentialMiles.toLocaleString()} miles on this flight.
                          </p>
                        </div>
                        <div className="bg-muted/50 p-4 rounded-lg">
                          <h3 className="font-medium mb-2">Miles Price ({currentCabin.name})</h3>
                          <div className="text-2xl font-bold">{currentCabin.milesPrice.toLocaleString()} miles</div>
                          <p className="text-sm text-muted-foreground mt-2">
                            Value: {currentCabin.milesValue}¢ per mile
                            {currentCabin.milesValue > 1.3 ? " (Good value!)" : ""}
                          </p>
                        </div>
                      </div>
                      <div className="bg-primary/10 p-4 rounded-lg border border-primary/20">
                        <h3 className="font-medium mb-2">Our Recommendation</h3>
                        {currentCabin.milesValue > 1.3 ? (
                          <div className="space-y-2">
                            <p className="text-sm font-medium text-green-700">
                              Use your miles for this {currentCabin.name} flight - it's a good value!
                            </p>
                            <p className="text-sm">
                              At {currentCabin.milesValue}¢ per mile, this redemption exceeds the average value of 1.3¢
                              per mile. This is an efficient use of your miles.
                            </p>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <p className="text-sm font-medium text-amber-700">
                              Pay cash for this {currentCabin.name} flight and earn miles instead.
                            </p>
                            <p className="text-sm">
                              At {currentCabin.milesValue}¢ per mile, this redemption is below the average value of 1.3¢
                              per mile. By paying cash, you'll earn {currentCabin.potentialMiles.toLocaleString()} miles
                              that you can use for a higher-value redemption later.
                            </p>
                          </div>
                        )}
                      </div>
                    </TabsContent>

                    <TabsContent value="earn" className="space-y-4">
                      <div className="bg-muted/50 p-4 rounded-lg">
                        <h3 className="font-medium mb-2">Miles You'll Earn ({currentCabin.name})</h3>
                        <div className="text-2xl font-bold">{currentCabin.potentialMiles.toLocaleString()} miles</div>
                        <div className="mt-2 grid grid-cols-3 gap-2">
                          <div className="text-sm">
                            <span className="text-muted-foreground">Base miles:</span>
                            <div className="font-medium">3,458 miles</div>
                          </div>
                          <div className="text-sm">
                            <span className="text-muted-foreground">Cabin bonus:</span>
                            <div className="font-medium">{currentCabin.statusMultiplier}x multiplier</div>
                          </div>
                          <div className="text-sm">
                            <span className="text-muted-foreground">Status bonus:</span>
                            <div className="font-medium">
                              +{Math.round((currentCabin.potentialMiles - 3458) * 0.5).toLocaleString()} miles
                            </div>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mt-2">
                          Based on your {flight.alliance} status and {currentCabin.name} cabin
                        </p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="border p-4 rounded-lg">
                          <h4 className="font-medium text-sm mb-2">Miles Earning by Cabin</h4>
                          <div className="space-y-2">
                            {Object.entries(flight.cabins).map(([key, cabin]) => (
                              <div key={key} className="flex justify-between text-sm">
                                <span className={key === (selectedCabin[flight.id] || "economy") ? "font-medium" : ""}>
                                  {cabin.name}:
                                </span>
                                <span className={key === (selectedCabin[flight.id] || "economy") ? "font-medium" : ""}>
                                  {cabin.potentialMiles.toLocaleString()} miles
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div className="border p-4 rounded-lg">
                          <h4 className="font-medium text-sm mb-2">Alliance Partners</h4>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>American AAdvantage:</span>
                              <span>{Math.round(currentCabin.potentialMiles * 1.1).toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>British Airways Avios:</span>
                              <span>{Math.round(currentCabin.potentialMiles * 0.9).toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Cathay Pacific:</span>
                              <span>{currentCabin.potentialMiles.toLocaleString()}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="card" className="space-y-4">
                      <div className="bg-muted/50 p-4 rounded-lg">
                        <h3 className="font-medium mb-2 flex items-center">
                          <CreditCard className="h-4 w-4 mr-1" />
                          Best Card for This Purchase ({currentCabin.name})
                        </h3>
                        <div className="flex items-center gap-3 mt-3">
                          <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                          <div>
                            <div className="font-medium">{flight.bestCreditCard}</div>
                            <div className="text-sm text-muted-foreground">{flight.cardBonus} points on travel</div>
                            <div className="text-sm font-medium">
                              Earn {Math.round(currentCabin.price * Number.parseInt(flight.cardBonus)).toLocaleString()}{" "}
                              points
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="border p-4 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <div className="w-8 h-8 bg-gray-200 rounded-lg"></div>
                            <h4 className="font-medium text-sm">Chase Sapphire Reserve</h4>
                          </div>
                          <div className="text-sm text-muted-foreground mb-2">3x points on travel</div>
                          <div className="font-medium">
                            {Math.round(currentCabin.price * 3).toLocaleString()} points
                          </div>
                        </div>
                        <div className="border p-4 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <div className="w-8 h-8 bg-gray-200 rounded-lg"></div>
                            <h4 className="font-medium text-sm">Amex Platinum</h4>
                          </div>
                          <div className="text-sm text-muted-foreground mb-2">5x points on flights</div>
                          <div className="font-medium">
                            {Math.round(currentCabin.price * 5).toLocaleString()} points
                          </div>
                        </div>
                        <div className="border p-4 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <div className="w-8 h-8 bg-gray-200 rounded-lg"></div>
                            <h4 className="font-medium text-sm">Citi Premier</h4>
                          </div>
                          <div className="text-sm text-muted-foreground mb-2">3x points on air travel</div>
                          <div className="font-medium">
                            {Math.round(currentCabin.price * 3).toLocaleString()} points
                          </div>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="redeem" className="space-y-4">
                      <div className="bg-muted/50 p-4 rounded-lg">
                        <h3 className="font-medium mb-2">Redemption Options ({currentCabin.name})</h3>
                        <p className="text-sm text-muted-foreground">
                          Here are the best ways to redeem points or miles for this {currentCabin.name} flight
                        </p>
                      </div>
                      <div className="space-y-4">
                        <div className="border p-4 rounded-lg">
                          <h4 className="font-medium mb-2">Option 1: Transfer Chase Points to British Airways</h4>
                          <div className="text-sm space-y-2">
                            <p>
                              Transfer {Math.round(currentCabin.milesPrice * 0.8).toLocaleString()} Chase Ultimate
                              Rewards points to British Airways Avios
                            </p>
                            <p>Book the {currentCabin.name} flight through British Airways Executive Club</p>
                            <p className="font-medium text-primary">Value: {currentCabin.milesValue}¢ per point</p>
                          </div>
                        </div>
                        <div className="border p-4 rounded-lg">
                          <h4 className="font-medium mb-2">Option 2: Use American AAdvantage Miles</h4>
                          <div className="text-sm space-y-2">
                            <p>Redeem {currentCabin.milesPrice.toLocaleString()} American AAdvantage miles</p>
                            <p>Book {currentCabin.name} directly through American Airlines website</p>
                            <p className="font-medium">
                              Value: {(currentCabin.milesValue * 0.85).toFixed(2)}¢ per mile
                            </p>
                          </div>
                        </div>
                        <div className="border p-4 rounded-lg">
                          <h4 className="font-medium mb-2">Option 3: Transfer Amex Points to Virgin Atlantic</h4>
                          <div className="text-sm space-y-2">
                            <p>
                              Transfer {Math.round(currentCabin.milesPrice * 0.9).toLocaleString()} Amex Membership
                              Rewards points to Virgin Atlantic Flying Club
                            </p>
                            <p>Book the {currentCabin.name} flight through Virgin Atlantic</p>
                            <p className="font-medium text-primary">
                              Best value: {(currentCabin.milesValue * 1.1).toFixed(2)}¢ per point
                            </p>
                          </div>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between p-4 pt-0">
              <Button
                variant="outline"
                size="sm"
                onClick={() => toggleFavorite(flight.id)}
                className={favoriteFlights.includes(flight.id) ? "text-red-500" : ""}
              >
                <Heart className={`h-4 w-4 mr-2 ${favoriteFlights.includes(flight.id) ? "fill-red-500" : ""}`} />
                {favoriteFlights.includes(flight.id) ? "Saved" : "Save"}
              </Button>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedFlightId(selectedFlightId === flight.id ? null : flight.id)}
                >
                  {selectedFlightId === flight.id ? "Hide Details" : "View Details"}
                </Button>
                <Link href={`/checkout/${flight.id}`}>
                  <Button size="sm">Select</Button>
                </Link>
              </div>
            </CardFooter>
          </Card>
        )
      })}
    </div>
  )
}
