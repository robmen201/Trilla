"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Plane,
  MapPin,
  Star,
  Bell,
  Settings,
  TrendingUp,
  Wallet,
  Clock,
  Award,
  Search,
  Heart,
  ChevronRight,
  DollarSign,
  Globe,
  Shield,
  Zap,
  Plus,
  CreditCard,
  Edit,
  Trash2,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  Gift,
  Crown,
  Building,
  Hotel,
} from "lucide-react"

const allBookings = [
  {
    id: "1",
    type: "flight",
    route: "NYC → London",
    date: "Dec 15, 2024",
    returnDate: "Dec 22, 2024",
    status: "confirmed",
    price: "$1,245",
    points: "2,500",
    airline: "British Airways",
    class: "Business",
    confirmation: "BA4567",
    passengers: 1,
  },
  {
    id: "2",
    type: "hotel",
    location: "Paris, France",
    date: "Nov 28, 2024",
    returnDate: "Dec 1, 2024",
    status: "completed",
    price: "$890",
    points: "1,780",
    provider: "Marriott",
    nights: "3 nights",
    confirmation: "MAR789123",
    passengers: 2,
  },
  {
    id: "3",
    type: "flight",
    route: "LA → Tokyo",
    date: "Jan 8, 2025",
    returnDate: "Jan 15, 2025",
    status: "pending",
    price: "$2,100",
    points: "4,200",
    airline: "ANA",
    class: "Premium Economy",
    confirmation: "ANA9876",
    passengers: 1,
  },
  {
    id: "4",
    type: "flight",
    route: "Miami → Barcelona",
    date: "Feb 14, 2025",
    returnDate: "Feb 21, 2025",
    status: "confirmed",
    price: "$850",
    points: "1,700",
    airline: "Iberia",
    class: "Economy",
    confirmation: "IB2345",
    passengers: 2,
  },
  {
    id: "5",
    type: "hotel",
    location: "Rome, Italy",
    date: "Mar 10, 2025",
    returnDate: "Mar 14, 2025",
    status: "confirmed",
    price: "$1,200",
    points: "2,400",
    provider: "Hilton",
    nights: "4 nights",
    confirmation: "HIL456789",
    passengers: 2,
  },
  {
    id: "6",
    type: "flight",
    route: "Chicago → Amsterdam",
    date: "Apr 5, 2025",
    returnDate: "Apr 12, 2025",
    status: "cancelled",
    price: "$950",
    points: "1,900",
    airline: "KLM",
    class: "Economy Plus",
    confirmation: "KL7890",
    passengers: 1,
  },
]

const allSavedSearches = [
  {
    id: "1",
    route: "NYC → Paris",
    from: "New York (JFK)",
    to: "Paris (CDG)",
    dates: "Flexible",
    passengers: 1,
    class: "Business",
    alerts: true,
    created: "Nov 15, 2024",
    lastChecked: "2 hours ago",
  },
  {
    id: "2",
    route: "LA → London",
    from: "Los Angeles (LAX)",
    to: "London (LHR)",
    dates: "Mar 15-22, 2025",
    passengers: 2,
    class: "Premium Economy",
    alerts: true,
    created: "Nov 20, 2024",
    lastChecked: "1 day ago",
  },
  {
    id: "3",
    route: "Miami → Barcelona",
    from: "Miami (MIA)",
    to: "Barcelona (BCN)",
    dates: "Summer 2025",
    passengers: 1,
    class: "Economy",
    alerts: false,
    created: "Oct 30, 2024",
    lastChecked: "1 week ago",
  },
  {
    id: "4",
    route: "San Francisco → Tokyo",
    from: "San Francisco (SFO)",
    to: "Tokyo (NRT)",
    dates: "May 1-10, 2025",
    passengers: 2,
    class: "Business",
    alerts: true,
    created: "Nov 25, 2024",
    lastChecked: "4 hours ago",
  },
  {
    id: "5",
    route: "Boston → Rome",
    from: "Boston (BOS)",
    to: "Rome (FCO)",
    dates: "Jun 2025",
    passengers: 1,
    class: "Economy Plus",
    alerts: false,
    created: "Nov 10, 2024",
    lastChecked: "3 days ago",
  },
]

const priceAlerts = [
  {
    id: "1",
    route: "NYC → Paris",
    currentPrice: "$1,245",
    targetPrice: "$1,000",
    difference: "+$245",
    trend: "up",
    status: "active",
    created: "Nov 15, 2024",
    triggered: false,
    airline: "Air France",
    dates: "Dec 20-27, 2024",
  },
  {
    id: "2",
    route: "LA → London",
    currentPrice: "$850",
    targetPrice: "$900",
    difference: "-$50",
    trend: "down",
    status: "triggered",
    created: "Nov 20, 2024",
    triggered: true,
    airline: "Virgin Atlantic",
    dates: "Mar 15-22, 2025",
  },
  {
    id: "3",
    route: "Miami → Barcelona",
    currentPrice: "$650",
    targetPrice: "$600",
    difference: "+$50",
    trend: "up",
    status: "active",
    created: "Oct 30, 2024",
    triggered: false,
    airline: "Iberia",
    dates: "Summer 2025",
  },
  {
    id: "4",
    route: "San Francisco → Tokyo",
    currentPrice: "$1,890",
    targetPrice: "$1,500",
    difference: "+$390",
    trend: "up",
    status: "paused",
    created: "Nov 25, 2024",
    triggered: false,
    airline: "United",
    dates: "May 1-10, 2025",
  },
  {
    id: "5",
    route: "Chicago → Rome",
    currentPrice: "$780",
    targetPrice: "$800",
    difference: "-$20",
    trend: "down",
    status: "triggered",
    created: "Nov 18, 2024",
    triggered: true,
    airline: "Lufthansa",
    dates: "Apr 10-17, 2025",
  },
]

const recentBookings = allBookings.slice(0, 3)
const savedSearches = allSavedSearches.slice(0, 3)

// Available programs from admin dashboard - this would come from API in real app
const availablePrograms = [
  {
    id: 1,
    name: "United MileagePlus",
    partner: "United Airlines",
    type: "airline",
    commission: 2.8,
    pointValue: 0.012,
    status: "active",
    contract: "2025-12-31",
    perks: ["Priority boarding", "Free checked bags", "Lounge access", "Upgrade priority"],
  },
  {
    id: 2,
    name: "Delta SkyMiles",
    partner: "Delta Airlines",
    type: "airline",
    commission: 2.6,
    pointValue: 0.011,
    status: "active",
    contract: "2025-08-15",
    perks: ["Sky Priority", "Free seat selection", "Complimentary drinks", "Miles bonus"],
  },
  {
    id: 3,
    name: "American AAdvantage",
    partner: "American Airlines",
    type: "airline",
    commission: 2.9,
    pointValue: 0.013,
    status: "active",
    contract: "2024-12-31",
    perks: ["Priority check-in", "Free bags", "Admirals Club access", "Upgrade certificates"],
  },
  {
    id: 4,
    name: "Marriott Bonvoy",
    partner: "Marriott International",
    type: "hotel",
    commission: 3.2,
    pointValue: 0.008,
    status: "active",
    contract: "2025-06-30",
    perks: ["Late checkout", "Room upgrades", "Free WiFi", "Elite night credits"],
  },
  {
    id: 5,
    name: "Chase Sapphire Reserve",
    partner: "Chase Bank",
    type: "credit_card",
    commission: 4.5,
    pointValue: 0.02,
    status: "active",
    contract: "2025-12-31",
    perks: ["3x points on travel", "Travel insurance", "Airport lounge access", "No foreign fees"],
  },
  {
    id: 6,
    name: "Hilton Honors",
    partner: "Hilton Hotels",
    type: "hotel",
    commission: 3.0,
    pointValue: 0.005,
    status: "active",
    contract: "2025-09-30",
    perks: ["Free breakfast", "Room upgrades", "Late checkout", "Digital key"],
  },
  {
    id: 7,
    name: "Amex Platinum",
    partner: "American Express",
    type: "credit_card",
    commission: 5.0,
    pointValue: 0.022,
    status: "active",
    contract: "2025-12-31",
    perks: ["5x points on flights", "Centurion Lounge access", "Hotel status", "Uber credits"],
  },
  {
    id: 8,
    name: "Southwest Rapid Rewards",
    partner: "Southwest Airlines",
    type: "airline",
    commission: 2.4,
    pointValue: 0.014,
    status: "active",
    contract: "2025-07-15",
    perks: ["No blackout dates", "Companion pass eligible", "Free bags", "Flexible cancellation"],
  },
]

const subscriptionPlans = [
  {
    id: 1,
    name: "Freemium",
    price: 0,
    period: "Forever",
    description: "Perfect for occasional travelers who want basic flight search and comparison",
    features: [
      "5 flight searches per month",
      "Basic price comparison",
      "Email price alerts (1 active)",
      "Standard customer support",
      "Mobile app access",
    ],
    color: "bg-gray-500",
    icon: Gift,
    current: false,
  },
  {
    id: 2,
    name: "Basic",
    price: 9,
    period: "month",
    description: "Ideal for regular travelers who need unlimited searches and smart alerts",
    features: [
      "Unlimited flight searches",
      "Advanced price comparison",
      "Email & SMS price alerts (5 active)",
      "Basic loyalty program integration",
      "Priority email support",
      "Mobile app with offline access",
      "Price history charts",
    ],
    color: "bg-blue-500",
    icon: Zap,
    current: false,
  },
  {
    id: 3,
    name: "Pro",
    price: 20,
    period: "month",
    description: "Advanced features for frequent travelers and travel enthusiasts",
    features: [
      "Everything in Basic",
      "AI-powered flight recommendations",
      "Real-time price tracking",
      "Unlimited price alerts",
      "Credit card points optimization",
      "Calendar integration",
      "Seat map & amenity details",
      "24/7 priority support",
      "Advanced booking analytics",
    ],
    color: "bg-purple-500",
    icon: Crown,
    current: true,
  },
  {
    id: 4,
    name: "Business",
    price: 60,
    period: "month",
    description: "Enterprise-grade solution for businesses and travel managers",
    features: [
      "Everything in Pro",
      "Team management dashboard",
      "Corporate booking tools",
      "Expense reporting & analytics",
      "API access for integrations",
      "Dedicated account manager",
      "Custom approval workflows",
      "Bulk booking discounts",
      "Advanced reporting & insights",
      "White-label options",
    ],
    color: "bg-emerald-500",
    icon: Building,
    current: false,
  },
]

export function UserDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [selectedProgram, setSelectedProgram] = useState(null)
  const [showAddProgramModal, setShowAddProgramModal] = useState(false)
  const [showAddCardModal, setShowAddCardModal] = useState(false)
  const [selectedProgramsToAdd, setSelectedProgramsToAdd] = useState([])
  const [searchQuery, setSearchQuery] = useState("")

  // User's current loyalty programs (initially empty, user can add from available programs)
  const [userLoyaltyPrograms, setUserLoyaltyPrograms] = useState([
    {
      id: 1,
      name: "United MileagePlus",
      points: "45,230",
      tier: "Gold",
      progress: 75,
      cashValue: "$587.99",
      type: "airline",
      perks: ["Priority boarding", "Free checked bags", "Seat upgrades", "Lounge access", "Priority check-in"],
    },
    {
      id: 4,
      name: "Marriott Bonvoy",
      points: "128,450",
      tier: "Platinum",
      progress: 90,
      cashValue: "$1,284",
      type: "hotel",
      perks: ["Room upgrades", "Late checkout", "Free breakfast", "Lounge access", "Free WiFi"],
    },
    {
      id: 5,
      name: "Chase Sapphire Reserve",
      points: "89,340",
      tier: "Premium",
      progress: null,
      cashValue: "$1,786",
      type: "credit_card",
      perks: [
        "2x points on travel",
        "1.5x point value",
        "Travel insurance",
        "No foreign fees",
        "Airport lounge access",
      ],
    },
  ])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "confirmed":
        return <Shield className="h-4 w-4 text-green-500" />
      case "completed":
        return <Award className="h-4 w-4 text-blue-500" />
      case "pending":
        return <Clock className="h-4 w-4 text-orange-500" />
      case "cancelled":
        return <AlertTriangle className="h-4 w-4 text-red-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "flight":
        return <Plane className="h-4 w-4 text-teal-500" />
      case "hotel":
        return <MapPin className="h-4 w-4 text-purple-500" />
      default:
        return <Globe className="h-4 w-4 text-gray-500" />
    }
  }

  const getProgramIcon = (type: string) => {
    switch (type) {
      case "airline":
        return <Plane className="h-5 w-5 text-blue-500" />
      case "hotel":
        return <Hotel className="h-5 w-5 text-green-500" />
      case "credit_card":
        return <CreditCard className="h-5 w-5 text-purple-500" />
      default:
        return <Star className="h-5 w-5 text-gray-500" />
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "airline":
        return "bg-blue-500"
      case "hotel":
        return "bg-green-500"
      case "credit_card":
        return "bg-purple-500"
      default:
        return "bg-yellow-500"
    }
  }

  const getTrendIcon = (trend: string) => {
    return trend === "up" ? (
      <TrendingUp className="h-4 w-4 text-red-500" />
    ) : (
      <TrendingDown className="h-4 w-4 text-green-500" />
    )
  }

  const handleAddPrograms = () => {
    const programsToAdd = availablePrograms.filter((program) => selectedProgramsToAdd.includes(program.id))

    const newUserPrograms = programsToAdd.map((program) => ({
      id: program.id,
      name: program.name,
      points: "0", // New program starts with 0 points
      tier: "Basic", // Default tier
      progress: 0,
      cashValue: "$0.00",
      type: program.type,
      perks: program.perks,
    }))

    // Add new programs to user's list (avoid duplicates)
    const existingIds = userLoyaltyPrograms.map((p) => p.id)
    const uniqueNewPrograms = newUserPrograms.filter((p) => !existingIds.includes(p.id))

    setUserLoyaltyPrograms([...userLoyaltyPrograms, ...uniqueNewPrograms])
    setSelectedProgramsToAdd([])
    setShowAddProgramModal(false)
    setShowAddCardModal(false)
  }

  const handleProgramSelection = (programId: number) => {
    setSelectedProgramsToAdd((prev) =>
      prev.includes(programId) ? prev.filter((id) => id !== programId) : [...prev, programId],
    )
  }

  const filteredAvailablePrograms = availablePrograms.filter(
    (program) =>
      program.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      program.partner.toLowerCase().includes(searchQuery.toLowerCase()) ||
      program.type.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const availableProgramsNotAdded = filteredAvailablePrograms.filter(
    (program) => !userLoyaltyPrograms.some((userProgram) => userProgram.id === program.id),
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="text-2xl font-bold">
            <span className="text-teal-500">TRILL</span>
            <span className="text-gray-800">A</span>
          </div>

          {/* User Profile & Stats */}
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-4 text-sm">
              <div className="text-center">
                <div className="text-xs text-gray-500">Total Trips</div>
                <div className="text-lg font-bold text-teal-500">23</div>
              </div>
              <div className="text-center">
                <div className="text-xs text-gray-500">Points Balance</div>
                <div className="text-lg font-bold text-teal-500">262K</div>
              </div>
              <div className="text-center">
                <div className="text-xs text-gray-500">Portfolio Value</div>
                <div className="text-lg font-bold text-teal-500">$3,658</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                Alerts
              </Button>
              <Avatar>
                <AvatarImage src="/placeholder.svg?height=32&width=32" />
                <AvatarFallback className="bg-teal-500 text-white">NH</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-gray-200 min-h-screen relative">
          <div className="p-4">
            <div className="space-y-1">
              <Button
                variant={activeTab === "overview" ? "default" : "ghost"}
                className={`w-full justify-start ${
                  activeTab === "overview"
                    ? "bg-teal-500 text-white hover:bg-teal-600"
                    : "text-gray-600 hover:bg-gray-100"
                }`}
                onClick={() => setActiveTab("overview")}
              >
                <TrendingUp className="mr-3 h-4 w-4" />
                Overview
              </Button>

              <Button
                variant="ghost"
                className={`w-full justify-start ${
                  activeTab === "bookings" ? "bg-teal-500 text-white" : "text-gray-600"
                }`}
                onClick={() => setActiveTab("bookings")}
              >
                <Plane className="mr-3 h-4 w-4" />
                My Bookings
              </Button>

              <Button
                variant="ghost"
                className={`w-full justify-start ${
                  activeTab === "searches" ? "bg-teal-500 text-white" : "text-gray-600"
                }`}
                onClick={() => setActiveTab("searches")}
              >
                <Search className="mr-3 h-4 w-4" />
                Saved Searches
              </Button>

              <Button
                variant="ghost"
                className={`w-full justify-start ${
                  activeTab === "loyalty" ? "bg-teal-500 text-white" : "text-gray-600"
                }`}
                onClick={() => setActiveTab("loyalty")}
              >
                <Star className="mr-3 h-4 w-4" />
                Loyalty Programs
              </Button>

              <Button
                variant="ghost"
                className={`w-full justify-start ${
                  activeTab === "alerts" ? "bg-teal-500 text-white" : "text-gray-600"
                }`}
                onClick={() => setActiveTab("alerts")}
              >
                <Bell className="mr-3 h-4 w-4" />
                Price Alerts
              </Button>

              <Button
                variant="ghost"
                className={`w-full justify-start ${
                  activeTab === "wallet" ? "bg-teal-500 text-white" : "text-gray-600"
                }`}
                onClick={() => setActiveTab("wallet")}
              >
                <Wallet className="mr-3 h-4 w-4" />
                Wallet & Cards
              </Button>

              <Button
                variant="ghost"
                className={`w-full justify-start ${
                  activeTab === "settings" ? "bg-teal-500 text-white" : "text-gray-600"
                }`}
                onClick={() => setActiveTab("settings")}
              >
                <Settings className="mr-3 h-4 w-4" />
                Settings
              </Button>
            </div>
          </div>

          {/* Compact Subscription Status */}
          <div className="absolute bottom-4 left-4 right-4">
            <Dialog>
              <DialogTrigger asChild>
                <div className="bg-gradient-to-r from-teal-500 to-teal-600 text-white rounded-lg p-3 cursor-pointer hover:from-teal-600 hover:to-teal-700 transition-colors">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-medium">Pro Plan</div>
                      <div className="text-xs opacity-90">$20/month</div>
                    </div>
                    <Badge className="bg-white/20 text-white hover:bg-white/30 text-xs">
                      <Zap className="h-3 w-3 mr-1" />
                      Active
                    </Badge>
                  </div>
                </div>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Subscription Plans</DialogTitle>
                </DialogHeader>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                  {subscriptionPlans.map((plan) => {
                    const IconComponent = plan.icon
                    return (
                      <Card key={plan.id} className={`relative ${plan.current ? "ring-2 ring-teal-500" : ""}`}>
                        <CardHeader className="pb-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div
                                className={`w-10 h-10 ${plan.color} rounded-lg flex items-center justify-center text-white`}
                              >
                                <IconComponent className="h-5 w-5" />
                              </div>
                              <div>
                                <CardTitle className="text-lg">{plan.name}</CardTitle>
                                <div className="flex items-baseline gap-1">
                                  <span className="text-xl font-bold">
                                    {plan.price === 0 ? "Free" : `$${plan.price}`}
                                  </span>
                                  {plan.price > 0 && <span className="text-gray-500">/{plan.period}</span>}
                                </div>
                              </div>
                            </div>
                            {plan.current && <Badge className="bg-teal-500 text-white">Current Plan</Badge>}
                          </div>
                          <p className="text-sm text-gray-600 mt-2">{plan.description}</p>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="space-y-2">
                            <h4 className="font-medium text-sm">Features:</h4>
                            <div className="space-y-1">
                              {plan.features.map((feature, index) => (
                                <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                                  <CheckCircle className="h-3 w-3 text-green-500 flex-shrink-0" />
                                  <span>{feature}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                          {!plan.current && (
                            <Button className="w-full bg-teal-500 hover:bg-teal-600">
                              {plan.price === 0
                                ? "Downgrade to Free"
                                : plan.id < 3 // Pro plan has id 3, so anything less should be downgrade
                                  ? `Downgrade to ${plan.name}`
                                  : `Upgrade to ${plan.name}`}
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {activeTab === "overview" && (
            <div className="space-y-6">
              {/* Welcome Section */}
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Welcome back, Nathan!</h1>
                  <p className="text-gray-600">Here's what's happening with your travel plans</p>
                </div>
                <Button className="bg-teal-500 hover:bg-teal-600">
                  <Search className="h-4 w-4 mr-2" />
                  Search Flights
                </Button>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Active Bookings</p>
                        <p className="text-2xl font-bold text-gray-900">3</p>
                      </div>
                      <div className="h-12 w-12 bg-teal-100 rounded-lg flex items-center justify-center">
                        <Plane className="h-6 w-6 text-teal-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Total Points</p>
                        <p className="text-2xl font-bold text-gray-900">262K</p>
                      </div>
                      <div className="h-12 w-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <Star className="h-6 w-6 text-purple-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Money Saved</p>
                        <p className="text-2xl font-bold text-gray-900">$3,450</p>
                      </div>
                      <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <DollarSign className="h-6 w-6 text-green-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Price Alerts</p>
                        <p className="text-2xl font-bold text-gray-900">7</p>
                      </div>
                      <div className="h-12 w-12 bg-orange-100 rounded-lg flex items-center justify-center">
                        <Bell className="h-6 w-6 text-orange-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Recent Bookings */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      Recent Bookings
                      <Button variant="outline" size="sm" onClick={() => setActiveTab("bookings")}>
                        View All
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentBookings.map((booking) => (
                        <div key={booking.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            {getTypeIcon(booking.type)}
                            <div>
                              <div className="font-medium text-sm">
                                {booking.type === "flight" ? booking.route : booking.location}
                              </div>
                              <div className="text-xs text-gray-500">
                                {booking.date} • {booking.type === "flight" ? booking.airline : booking.provider}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center gap-2">
                              {getStatusIcon(booking.status)}
                              <Badge variant={booking.status === "confirmed" ? "default" : "secondary"}>
                                {booking.status}
                              </Badge>
                            </div>
                            <div className="text-xs text-gray-500 mt-1">{booking.price}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Saved Searches */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      Saved Searches & Alerts
                      <Button variant="outline" size="sm" onClick={() => setActiveTab("searches")}>
                        View All
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {savedSearches.map((search, index) => (
                        <div key={index} className="p-4 border border-gray-200 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div className="font-medium text-sm">{search.route}</div>
                            <Button variant="ghost" size="sm">
                              <Heart className="h-4 w-4" />
                            </Button>
                          </div>
                          <div className="text-xs text-gray-500 mb-3">
                            {search.dates} • {search.passengers} passenger{search.passengers > 1 ? "s" : ""}
                          </div>
                          <div className="flex items-center justify-between">
                            <Badge variant={search.alerts ? "default" : "secondary"}>
                              {search.alerts ? "Alerts On" : "Alerts Off"}
                            </Badge>
                            <Button variant="outline" size="sm">
                              Search
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* My Bookings Tab */}
          {activeTab === "bookings" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">My Bookings</h1>
                  <p className="text-gray-600">Manage your travel reservations and bookings</p>
                </div>
                <Button className="bg-teal-500 hover:bg-teal-600">
                  <Plus className="h-4 w-4 mr-2" />
                  New Booking
                </Button>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {allBookings.map((booking) => (
                  <Card key={booking.id}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-3">
                            {getTypeIcon(booking.type)}
                            <div>
                              <div className="font-medium">
                                {booking.type === "flight" ? booking.route : booking.location}
                              </div>
                              <div className="text-sm text-gray-500">
                                {booking.type === "flight" ? booking.airline : booking.provider} •{" "}
                                {booking.confirmation}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-6">
                          <div className="text-center">
                            <div className="text-sm font-medium">{booking.date}</div>
                            <div className="text-xs text-gray-500">
                              {booking.returnDate && `to ${booking.returnDate}`}
                            </div>
                          </div>
                          <div className="text-center">
                            <div className="text-sm font-medium">
                              {booking.passengers} passenger{booking.passengers > 1 ? "s" : ""}
                            </div>
                            <div className="text-xs text-gray-500">
                              {booking.type === "flight" ? booking.class : booking.nights}
                            </div>
                          </div>
                          <div className="text-center">
                            <div className="text-sm font-medium">{booking.price}</div>
                            <div className="text-xs text-gray-500">{booking.points} pts</div>
                          </div>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(booking.status)}
                            <Badge
                              variant={
                                booking.status === "confirmed"
                                  ? "default"
                                  : booking.status === "completed"
                                    ? "secondary"
                                    : booking.status === "cancelled"
                                      ? "destructive"
                                      : "secondary"
                              }
                            >
                              {booking.status}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button size="sm" variant="outline">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              View Details
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Saved Searches Tab */}
          {activeTab === "searches" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Saved Searches</h1>
                  <p className="text-gray-600">Manage your saved flight searches and preferences</p>
                </div>
                <Button className="bg-teal-500 hover:bg-teal-600">
                  <Plus className="h-4 w-4 mr-2" />
                  Save New Search
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {allSavedSearches.map((search) => (
                  <Card key={search.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="font-medium">{search.route}</div>
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <div className="text-xs text-gray-500">Route</div>
                          <div className="text-sm">
                            {search.from} → {search.to}
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <div className="text-xs text-gray-500">Dates</div>
                            <div className="text-sm">{search.dates}</div>
                          </div>
                          <div>
                            <div className="text-xs text-gray-500">Passengers</div>
                            <div className="text-sm">{search.passengers}</div>
                          </div>
                        </div>

                        <div>
                          <div className="text-xs text-gray-500">Class</div>
                          <div className="text-sm">{search.class}</div>
                        </div>

                        <div className="flex items-center justify-between pt-2">
                          <Badge variant={search.alerts ? "default" : "secondary"}>
                            {search.alerts ? "Alerts On" : "Alerts Off"}
                          </Badge>
                          <div className="text-xs text-gray-500">Last checked: {search.lastChecked}</div>
                        </div>

                        <div className="flex gap-2 pt-2">
                          <Button size="sm" className="flex-1 bg-teal-500 hover:bg-teal-600">
                            Search Now
                          </Button>
                          <Button size="sm" variant="outline">
                            <Bell className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Price Alerts Tab */}
          {activeTab === "alerts" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Price Alerts</h1>
                  <p className="text-gray-600">Monitor flight prices and get notified when they drop</p>
                </div>
                <Button className="bg-teal-500 hover:bg-teal-600">
                  <Plus className="h-4 w-4 mr-2" />
                  Create Alert
                </Button>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {priceAlerts.map((alert) => (
                  <Card key={alert.id}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-3">
                            <Plane className="h-5 w-5 text-teal-500" />
                            <div>
                              <div className="font-medium">{alert.route}</div>
                              <div className="text-sm text-gray-500">
                                {alert.airline} • {alert.dates}
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-6">
                          <div className="text-center">
                            <div className="text-sm font-medium">Current Price</div>
                            <div className="text-lg font-bold">{alert.currentPrice}</div>
                          </div>

                          <div className="text-center">
                            <div className="text-sm font-medium">Target Price</div>
                            <div className="text-lg font-bold text-teal-600">{alert.targetPrice}</div>
                          </div>

                          <div className="text-center">
                            <div className="text-sm font-medium">Difference</div>
                            <div
                              className={`text-lg font-bold flex items-center gap-1 ${
                                alert.trend === "up" ? "text-red-500" : "text-green-500"
                              }`}
                            >
                              {getTrendIcon(alert.trend)}
                              {alert.difference}
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <Badge
                              variant={
                                alert.status === "triggered"
                                  ? "default"
                                  : alert.status === "active"
                                    ? "secondary"
                                    : "outline"
                              }
                              className={
                                alert.status === "triggered"
                                  ? "bg-green-100 text-green-800"
                                  : alert.status === "active"
                                    ? "bg-blue-100 text-blue-800"
                                    : "bg-gray-100 text-gray-800"
                              }
                            >
                              {alert.triggered && <CheckCircle className="h-3 w-3 mr-1" />}
                              {alert.status}
                            </Badge>
                          </div>

                          <div className="flex items-center gap-2">
                            <Button size="sm" variant="outline">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Loyalty Programs Tab */}
          {activeTab === "loyalty" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Loyalty Programs</h1>
                  <p className="text-gray-600">Manage your loyalty accounts and track your progress</p>
                </div>
                <Button className="bg-teal-500 hover:bg-teal-600" onClick={() => setShowAddProgramModal(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Program
                </Button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                  {userLoyaltyPrograms.map((program, index) => (
                    <Card
                      key={index}
                      className="cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => setSelectedProgram(program)}
                    >
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3">
                            {getProgramIcon(program.type)}
                            <div>
                              <div className="font-medium">{program.name}</div>
                              <div className="text-sm text-gray-500">{program.points} points</div>
                            </div>
                          </div>
                          <Badge variant="outline">{program.tier}</Badge>
                        </div>
                        {program.progress !== null && (
                          <>
                            <Progress value={program.progress} className="h-2 mb-2" />
                            <div className="text-xs text-gray-500">{program.progress}% to next tier</div>
                          </>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Program Details */}
                {selectedProgram && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-3">
                        {getProgramIcon(selectedProgram.type)}
                        {selectedProgram.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="text-sm text-gray-500">Current Balance</div>
                          <div className="text-2xl font-bold">{selectedProgram.points} points</div>
                          <div className="text-sm text-teal-600">{selectedProgram.cashValue}</div>
                        </div>

                        <div>
                          <div className="text-sm font-medium mb-2">Program Perks</div>
                          <div className="space-y-2">
                            {selectedProgram.perks.map((perk, index) => (
                              <div key={index} className="flex items-center gap-2 text-sm">
                                <div className="w-2 h-2 bg-teal-500 rounded-full"></div>
                                {perk}
                              </div>
                            ))}
                          </div>
                        </div>

                        {selectedProgram.progress !== null && (
                          <div>
                            <div className="text-sm font-medium mb-2">Tier Progress</div>
                            <Progress value={selectedProgram.progress} className="h-3" />
                            <div className="text-xs text-gray-500 mt-1">{selectedProgram.progress}% to next tier</div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          )}

          {/* Wallet & Cards Tab */}
          {activeTab === "wallet" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Wallet & Cards</h1>
                  <p className="text-gray-600">Manage your loyalty points and credit cards</p>
                </div>
                <Button className="bg-teal-500 hover:bg-teal-600" onClick={() => setShowAddCardModal(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Card
                </Button>
              </div>

              {/* Loyalty Points Value */}
              <Card>
                <CardHeader>
                  <CardTitle>Loyalty Points Portfolio</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {userLoyaltyPrograms.map((program, index) => (
                      <div
                        key={index}
                        className="p-4 border border-gray-200 rounded-lg cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => setSelectedProgram(program)}
                      >
                        <div className="flex items-center gap-3 mb-3">
                          {getProgramIcon(program.type)}
                          <div>
                            <div className="font-medium text-sm">{program.name}</div>
                            <div className="text-xs text-gray-500">{program.points} points</div>
                          </div>
                        </div>
                        <div className="text-lg font-bold text-teal-600">{program.cashValue}</div>
                        <div className="text-xs text-gray-500">Estimated cash value</div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 p-4 bg-teal-50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Total Portfolio Value</div>
                        <div className="text-xs text-gray-500">Combined cash equivalent</div>
                      </div>
                      <div className="text-2xl font-bold text-teal-600">
                        $
                        {userLoyaltyPrograms
                          .reduce((total, program) => {
                            const value = Number.parseFloat(program.cashValue.replace("$", "").replace(",", ""))
                            return total + value
                          }, 0)
                          .toLocaleString()}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Program Details in Wallet */}
              {selectedProgram && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      {getProgramIcon(selectedProgram.type)}
                      {selectedProgram.name} Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <div className="space-y-4">
                          <div>
                            <div className="text-sm text-gray-500">Points Balance</div>
                            <div className="text-xl font-bold">{selectedProgram.points}</div>
                          </div>
                          <div>
                            <div className="text-sm text-gray-500">Cash Value</div>
                            <div className="text-xl font-bold text-teal-600">{selectedProgram.cashValue}</div>
                          </div>
                          {selectedProgram.tier && (
                            <div>
                              <div className="text-sm text-gray-500">Current Tier</div>
                              <Badge variant="outline">{selectedProgram.tier}</Badge>
                            </div>
                          )}
                        </div>
                      </div>

                      <div>
                        <div className="text-sm font-medium mb-3">Available Perks</div>
                        <div className="space-y-2">
                          {selectedProgram.perks.map((perk, index) => (
                            <div key={index} className="flex items-center gap-2 text-sm">
                              <div className="w-2 h-2 bg-teal-500 rounded-full"></div>
                              {perk}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {/* Other tabs content */}
          {activeTab === "settings" && (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="text-gray-400 mb-2">
                  <Settings className="h-12 w-12 mx-auto" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 capitalize">Settings</h3>
                <p className="text-gray-500">This section is coming soon!</p>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Add Program Modal */}
      <Dialog open={showAddProgramModal} onOpenChange={setShowAddProgramModal}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add Loyalty Programs</DialogTitle>
            <p className="text-sm text-gray-600">Select from available programs to add to your account</p>
          </DialogHeader>

          <div className="space-y-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search programs..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Available Programs */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
              {availableProgramsNotAdded.map((program) => (
                <Card key={program.id} className="relative">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Checkbox
                        checked={selectedProgramsToAdd.includes(program.id)}
                        onCheckedChange={() => handleProgramSelection(program.id)}
                        className="mt-1"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <div
                            className={`w-8 h-8 ${getTypeColor(program.type)} rounded-lg flex items-center justify-center text-white`}
                          >
                            {getProgramIcon(program.type)}
                          </div>
                          <div>
                            <div className="font-medium">{program.name}</div>
                            <div className="text-sm text-gray-500">{program.partner}</div>
                          </div>
                        </div>

                        <div className="flex items-center gap-4 mb-2">
                          <Badge
                            className={
                              program.type === "airline"
                                ? "bg-blue-100 text-blue-800"
                                : program.type === "hotel"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-purple-100 text-purple-800"
                            }
                          >
                            {program.type.replace("_", " ")}
                          </Badge>
                          <div className="text-sm text-gray-600">{program.pointValue}¢ per point</div>
                        </div>

                        <div className="space-y-1">
                          <div className="text-xs font-medium text-gray-700">Key Perks:</div>
                          {program.perks.slice(0, 3).map((perk, index) => (
                            <div key={index} className="flex items-center gap-2 text-xs text-gray-600">
                              <div className="w-1 h-1 bg-teal-500 rounded-full"></div>
                              {perk}
                            </div>
                          ))}
                          {program.perks.length > 3 && (
                            <div className="text-xs text-gray-500">+{program.perks.length - 3} more perks</div>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {availableProgramsNotAdded.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                {searchQuery
                  ? "No programs found matching your search."
                  : "You've already added all available programs!"}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center gap-3 pt-4 border-t">
              <Button
                onClick={handleAddPrograms}
                disabled={selectedProgramsToAdd.length === 0}
                className="flex-1 bg-teal-500 hover:bg-teal-600"
              >
                Add {selectedProgramsToAdd.length} Program{selectedProgramsToAdd.length !== 1 ? "s" : ""}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setShowAddProgramModal(false)
                  setSelectedProgramsToAdd([])
                  setSearchQuery("")
                }}
                className="flex-1 bg-transparent"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Card Modal (same as Add Program Modal) */}
      <Dialog open={showAddCardModal} onOpenChange={setShowAddCardModal}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add Cards & Programs</DialogTitle>
            <p className="text-sm text-gray-600">Select from available programs to add to your wallet</p>
          </DialogHeader>

          <div className="space-y-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search programs..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Available Programs */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
              {availableProgramsNotAdded.map((program) => (
                <Card key={program.id} className="relative">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Checkbox
                        checked={selectedProgramsToAdd.includes(program.id)}
                        onCheckedChange={() => handleProgramSelection(program.id)}
                        className="mt-1"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <div
                            className={`w-8 h-8 ${getTypeColor(program.type)} rounded-lg flex items-center justify-center text-white`}
                          >
                            {getProgramIcon(program.type)}
                          </div>
                          <div>
                            <div className="font-medium">{program.name}</div>
                            <div className="text-sm text-gray-500">{program.partner}</div>
                          </div>
                        </div>

                        <div className="flex items-center gap-4 mb-2">
                          <Badge
                            className={
                              program.type === "airline"
                                ? "bg-blue-100 text-blue-800"
                                : program.type === "hotel"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-purple-100 text-purple-800"
                            }
                          >
                            {program.type.replace("_", " ")}
                          </Badge>
                          <div className="text-sm text-gray-600">{program.pointValue}¢ per point</div>
                        </div>

                        <div className="space-y-1">
                          <div className="text-xs font-medium text-gray-700">Key Perks:</div>
                          {program.perks.slice(0, 3).map((perk, index) => (
                            <div key={index} className="flex items-center gap-2 text-xs text-gray-600">
                              <div className="w-1 h-1 bg-teal-500 rounded-full"></div>
                              {perk}
                            </div>
                          ))}
                          {program.perks.length > 3 && (
                            <div className="text-xs text-gray-500">+{program.perks.length - 3} more perks</div>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {availableProgramsNotAdded.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                {searchQuery
                  ? "No programs found matching your search."
                  : "You've already added all available programs!"}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center gap-3 pt-4 border-t">
              <Button
                onClick={handleAddPrograms}
                disabled={selectedProgramsToAdd.length === 0}
                className="flex-1 bg-teal-500 hover:bg-teal-600"
              >
                Add {selectedProgramsToAdd.length} Program{selectedProgramsToAdd.length !== 1 ? "s" : ""}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setShowAddCardModal(false)
                  setSelectedProgramsToAdd([])
                  setSearchQuery("")
                }}
                className="flex-1 bg-transparent"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
