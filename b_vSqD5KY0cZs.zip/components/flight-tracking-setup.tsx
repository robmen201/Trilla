"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Bell, Plane, DollarSign, Calendar, Users } from "lucide-react"

interface FlightTracker {
  id: string
  route: string
  dates: string
  passengers: number
  currentPrice: number
  targetPrice: number
  alertTypes: string[]
  isActive: boolean
}

export function FlightTrackingSetup() {
  const [trackers, setTrackers] = useState<FlightTracker[]>([
    {
      id: "1",
      route: "JFK → LHR",
      dates: "Jun 25 - Jul 5",
      passengers: 1,
      currentPrice: 850,
      targetPrice: 750,
      alertTypes: ["price_drop", "award_availability"],
      isActive: true,
    },
  ])

  const [newTracker, setNewTracker] = useState({
    origin: "",
    destination: "",
    departDate: "",
    returnDate: "",
    passengers: 1,
    targetPrice: "",
    alertTypes: [] as string[],
  })

  const addTracker = () => {
    const tracker: FlightTracker = {
      id: Date.now().toString(),
      route: `${newTracker.origin} → ${newTracker.destination}`,
      dates: `${newTracker.departDate} - ${newTracker.returnDate}`,
      passengers: newTracker.passengers,
      currentPrice: 0, // Would be fetched from API
      targetPrice: Number(newTracker.targetPrice),
      alertTypes: newTracker.alertTypes,
      isActive: true,
    }

    setTrackers([...trackers, tracker])
    setNewTracker({
      origin: "",
      destination: "",
      departDate: "",
      returnDate: "",
      passengers: 1,
      targetPrice: "",
      alertTypes: [],
    })
  }

  const toggleTracker = (id: string) => {
    setTrackers(trackers.map((tracker) => (tracker.id === id ? { ...tracker, isActive: !tracker.isActive } : tracker)))
  }

  const removeTracker = (id: string) => {
    setTrackers(trackers.filter((tracker) => tracker.id !== id))
  }

  return (
    <div className="space-y-6">
      {/* Create New Tracker */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Set Up Flight Alerts
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="origin">From</Label>
              <Input
                id="origin"
                placeholder="Origin city or airport"
                value={newTracker.origin}
                onChange={(e) => setNewTracker({ ...newTracker, origin: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="destination">To</Label>
              <Input
                id="destination"
                placeholder="Destination city or airport"
                value={newTracker.destination}
                onChange={(e) => setNewTracker({ ...newTracker, destination: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="depart-date">Departure Date</Label>
              <Input
                id="depart-date"
                type="date"
                value={newTracker.departDate}
                onChange={(e) => setNewTracker({ ...newTracker, departDate: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="return-date">Return Date</Label>
              <Input
                id="return-date"
                type="date"
                value={newTracker.returnDate}
                onChange={(e) => setNewTracker({ ...newTracker, returnDate: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="passengers">Passengers</Label>
              <Select
                value={newTracker.passengers.toString()}
                onValueChange={(value) => setNewTracker({ ...newTracker, passengers: Number(value) })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Passenger</SelectItem>
                  <SelectItem value="2">2 Passengers</SelectItem>
                  <SelectItem value="3">3 Passengers</SelectItem>
                  <SelectItem value="4">4+ Passengers</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="target-price">Target Price (Optional)</Label>
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              <Input
                id="target-price"
                type="number"
                placeholder="Alert me when price drops below..."
                value={newTracker.targetPrice}
                onChange={(e) => setNewTracker({ ...newTracker, targetPrice: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-3">
            <Label>Alert Types</Label>
            <div className="grid grid-cols-2 gap-3">
              {[
                { id: "price_drop", label: "Price Drops", desc: "When prices decrease" },
                { id: "award_availability", label: "Award Seats", desc: "When miles/points seats open" },
                { id: "upgrade_deals", label: "Upgrade Offers", desc: "Discounted cabin upgrades" },
                { id: "schedule_changes", label: "Schedule Changes", desc: "Flight time changes" },
              ].map((alertType) => (
                <div key={alertType.id} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id={alertType.id}
                    checked={newTracker.alertTypes.includes(alertType.id)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setNewTracker({
                          ...newTracker,
                          alertTypes: [...newTracker.alertTypes, alertType.id],
                        })
                      } else {
                        setNewTracker({
                          ...newTracker,
                          alertTypes: newTracker.alertTypes.filter((type) => type !== alertType.id),
                        })
                      }
                    }}
                  />
                  <div>
                    <Label htmlFor={alertType.id} className="text-sm font-medium">
                      {alertType.label}
                    </Label>
                    <p className="text-xs text-muted-foreground">{alertType.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Button
            onClick={addTracker}
            disabled={!newTracker.origin || !newTracker.destination || !newTracker.departDate}
            className="w-full"
          >
            <Bell className="h-4 w-4 mr-2" />
            Start Tracking This Flight
          </Button>
        </CardContent>
      </Card>

      {/* Active Trackers */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold">Active Flight Trackers</h2>
        {trackers.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center">
              <Plane className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-medium mb-2">No active trackers</h3>
              <p className="text-sm text-muted-foreground">
                Set up flight tracking above to get notified of better deals.
              </p>
            </CardContent>
          </Card>
        ) : (
          trackers.map((tracker) => (
            <Card key={tracker.id} className={tracker.isActive ? "border-primary/20" : "opacity-60"}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Switch checked={tracker.isActive} onCheckedChange={() => toggleTracker(tracker.id)} />
                      <div>
                        <h3 className="font-medium">{tracker.route}</h3>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {tracker.dates}
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            {tracker.passengers} passenger{tracker.passengers > 1 ? "s" : ""}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-sm text-muted-foreground">Target Price</div>
                      <div className="font-medium">${tracker.targetPrice}</div>
                    </div>
                    <div className="flex gap-1">
                      {tracker.alertTypes.map((type) => (
                        <Badge key={type} variant="outline" className="text-xs">
                          {type.replace("_", " ")}
                        </Badge>
                      ))}
                    </div>
                    <Button variant="outline" size="sm" onClick={() => removeTracker(tracker.id)}>
                      Remove
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
