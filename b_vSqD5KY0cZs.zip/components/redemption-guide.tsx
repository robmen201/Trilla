"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Plane, CreditCard, ArrowRight, Star, Zap, TrendingUp, Info } from "lucide-react"

interface RedemptionGuideProps {
  flightPrice: number
  milesPrice: number
  airline: string
}

export function RedemptionGuide({ flightPrice, milesPrice, airline }: RedemptionGuideProps) {
  const [selectedOption, setSelectedOption] = useState("option1")

  const redemptionOptions = [
    {
      id: "option1",
      title: "Transfer Chase Points to British Airways",
      miles: 55000,
      transferRatio: "1:1",
      steps: [
        "Log into Chase Ultimate Rewards",
        "Transfer 55,000 points to British Airways Executive Club",
        "Book through ba.com using 55,000 Avios + taxes",
        "Enjoy your flight!",
      ],
      value: "2.67¢ per point",
      recommended: false,
      icon: <CreditCard className="h-5 w-5" />,
      color: "blue",
    },
    {
      id: "option2",
      title: "Transfer Amex Points to Lufthansa (30% Bonus)",
      miles: 42350, // 30% bonus means you need fewer points
      transferRatio: "1:1 + 30% bonus",
      steps: [
        "Log into Amex Membership Rewards",
        "Transfer 42,350 points to Lufthansa Miles & More",
        "Get 55,000 miles with 30% transfer bonus",
        "Book through lufthansa.com using miles + taxes",
      ],
      value: "3.47¢ per point",
      recommended: true,
      icon: <Zap className="h-5 w-5" />,
      color: "orange",
      bonus: "30% Transfer Bonus",
    },
    {
      id: "option3",
      title: "Use American AAdvantage Miles",
      miles: 55000,
      transferRatio: "Direct redemption",
      steps: [
        "Log into aa.com",
        "Search for award flights on partner airlines",
        "Book using 55,000 AAdvantage miles + taxes",
        "Complete your booking",
      ],
      value: "2.67¢ per mile",
      recommended: false,
      icon: <Plane className="h-5 w-5" />,
      color: "red",
    },
  ]

  const selectedRedemption = redemptionOptions.find((option) => option.id === selectedOption)

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Plane className="h-5 w-5" />
          Miles/Points Redemption Options
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Choose the best way to redeem your points or miles for this flight
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Value Comparison */}
        <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            <span className="font-medium text-primary">Best Value Analysis</span>
          </div>
          <p className="text-sm">
            The Amex transfer with 30% bonus offers the best value at 3.47¢ per point. You'll only need{" "}
            <strong>42,350 Amex points</strong> instead of 55,000!
          </p>
        </div>

        {/* Redemption Options */}
        <RadioGroup value={selectedOption} onValueChange={setSelectedOption} className="space-y-4">
          {redemptionOptions.map((option) => (
            <div key={option.id} className="flex items-start space-x-3">
              <RadioGroupItem value={option.id} id={option.id} className="mt-1" />
              <Label htmlFor={option.id} className="flex-1 cursor-pointer">
                <Card
                  className={`transition-all hover:shadow-md ${
                    selectedOption === option.id ? "border-primary bg-primary/5" : "hover:border-gray-300"
                  }`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className={`p-2 rounded-lg bg-${option.color}-100`}>{option.icon}</div>
                        <div>
                          <h3 className="font-medium">{option.title}</h3>
                          <p className="text-sm text-muted-foreground">{option.transferRatio}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        {option.recommended && (
                          <Badge className="bg-green-600 text-white mb-1">
                            <Star className="h-3 w-3 mr-1" />
                            Best Value
                          </Badge>
                        )}
                        {option.bonus && (
                          <Badge className="bg-orange-500 text-white mb-1">
                            <Zap className="h-3 w-3 mr-1" />
                            {option.bonus}
                          </Badge>
                        )}
                        <div className="text-lg font-bold">{option.miles.toLocaleString()}</div>
                        <div className="text-xs text-muted-foreground">
                          {option.id === "option2" ? "Amex points needed" : "miles needed"}
                        </div>
                      </div>
                    </div>

                    <div className="text-sm font-medium text-primary mb-2">Value: {option.value}</div>

                    {selectedOption === option.id && (
                      <div className="mt-4 pt-4 border-t">
                        <h4 className="font-medium mb-2 flex items-center gap-2">
                          <Info className="h-4 w-4" />
                          How to redeem:
                        </h4>
                        <ol className="space-y-2">
                          {option.steps.map((step, index) => (
                            <li key={index} className="flex items-start gap-2 text-sm">
                              <span className="flex-shrink-0 w-5 h-5 bg-primary text-white rounded-full text-xs flex items-center justify-center">
                                {index + 1}
                              </span>
                              <span>{step}</span>
                            </li>
                          ))}
                        </ol>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </Label>
            </div>
          ))}
        </RadioGroup>

        {/* Selected Option Summary */}
        {selectedRedemption && (
          <div className="bg-muted/50 rounded-lg p-4">
            <h3 className="font-medium mb-2">Your Selection Summary</h3>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">{selectedRedemption.title}</div>
                <div className="text-sm text-muted-foreground">
                  {selectedRedemption.miles.toLocaleString()}{" "}
                  {selectedRedemption.id === "option2" ? "Amex points" : "miles"} + taxes
                </div>
              </div>
              <div className="text-right">
                <div className="font-bold text-lg">{selectedRedemption.value}</div>
                <div className="text-xs text-muted-foreground">per point/mile</div>
              </div>
            </div>
          </div>
        )}

        <Button className="w-full" size="lg">
          <ArrowRight className="h-4 w-4 mr-2" />
          Proceed with {selectedRedemption?.title}
        </Button>
      </CardContent>
    </Card>
  )
}

export default RedemptionGuide
