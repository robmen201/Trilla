"use client"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CalendarIcon, Search, Plane, Building, ArrowUpDown, User, Flame } from "lucide-react"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format, addMonths } from "date-fns"
import Image from "next/image"
import Link from "next/link"

export function TrillaSearchPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("Round Trip")
  const [activeNavTab, setActiveNavTab] = useState("Flights")
  const [departDate, setDepartDate] = useState<Date>()
  const [returnDate, setReturnDate] = useState<Date>()
  const [origin, setOrigin] = useState("")
  const [destination, setDestination] = useState("")
  const [travelers, setTravelers] = useState("1 Traveler")
  const [travelClass, setTravelClass] = useState("Economy")
  const [showOriginDropdown, setShowOriginDropdown] = useState(false)
  const [showDestinationDropdown, setShowDestinationDropdown] = useState(false)

  const originCities = [
    { code: "JFK", name: "New York", full: "New York (JFK)" },
    { code: "LAX", name: "Los Angeles", full: "Los Angeles (LAX)" },
    { code: "MIA", name: "Miami", full: "Miami (MIA)" },
    { code: "ORD", name: "Chicago", full: "Chicago (ORD)" },
  ]

  const destinationCities = [
    { code: "LHR", name: "London", full: "London (LHR)" },
    { code: "CDG", name: "Paris", full: "Paris (CDG)" },
    { code: "NRT", name: "Tokyo", full: "Tokyo (NRT)" },
    { code: "SYD", name: "Sydney", full: "Sydney (SYD)" },
  ]

  const handleSearch = () => {
    if (!origin || !destination || !departDate) {
      alert("Please select origin, destination, and departure date")
      return
    }

    const searchParams = new URLSearchParams({
      origin: origin.split("(")[1]?.replace(")", "") || "",
      destination: destination.split("(")[1]?.replace(")", "") || "",
      departureDate: format(departDate, "yyyy-MM-dd"),
      adults: travelers.split(" ")[0],
      travelClass: travelClass.toUpperCase(),
    })

    if (activeTab === "Round Trip" && returnDate) {
      searchParams.append("returnDate", format(returnDate, "yyyy-MM-dd"))
    }

    router.push(`/search-results?${searchParams.toString()}`)
  }

  const handleTabClick = (tab: string) => {
    if (tab === "Hot Deals") {
      router.push("/hot-deals")
    } else {
      setActiveTab(tab)
    }
  }

  const destinations = [
    { name: "MEXICO", image: "/images/destinations/mexico.jpg", slug: "mexico" },
    { name: "ITALY", image: "/images/destinations/italy.jpg", slug: "italy" },
    { name: "VENEZUELA", image: "/images/destinations/venezuela.jpg", slug: "venezuela" },
    { name: "EGYPT", image: "/images/destinations/egypt.jpg", slug: "egypt" },
    { name: "PANAMA", image: "/images/destinations/panama.jpg", slug: "panama" },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Logo */}
          <div className="text-2xl font-bold">
            <span className="text-teal-500">TRILL</span>
            <span className="text-gray-800">A</span>
          </div>

          {/* Navigation */}
          <div className="flex items-center gap-8">
            <button
              onClick={() => setActiveNavTab("Flights")}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                activeNavTab === "Flights"
                  ? "text-teal-500 bg-teal-50"
                  : "text-gray-600 hover:text-teal-500 hover:bg-teal-50"
              }`}
            >
              <Plane className="h-5 w-5" />
              Flights
            </button>
            <button
              onClick={() => setActiveNavTab("Hotels")}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                activeNavTab === "Hotels"
                  ? "text-teal-500 bg-teal-50"
                  : "text-gray-600 hover:text-teal-500 hover:bg-teal-50"
              }`}
            >
              <Building className="h-5 w-5" />
              Hotels
            </button>
          </div>

          {/* User Profile - Now Clickable */}
          <Link href="/dashboard">
            <div className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-3 rounded-lg transition-colors bg-green-600 text-white hover:bg-green-700">
              <User className="h-5 w-5" />
              <div className="text-sm">
                <div className="font-medium">Hi Nathan</div>
                <div className="text-green-100">My Wallet</div>
              </div>
            </div>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-16">
        {/* Hero Title */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-teal-500 mb-8">Travel & Rewards. Simplified.</h1>
        </div>

        {/* Search Form */}
        <div className="max-w-5xl mx-auto mb-16">
          {/* Trip Type Tabs and Options */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-6">
              {["Round Trip", "One Way", "Multi City", "Hot Deals"].map((tab) => (
                <button
                  key={tab}
                  onClick={() => handleTabClick(tab)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                    activeTab === tab
                      ? "text-teal-500 bg-teal-50 border border-teal-200"
                      : "text-gray-600 hover:text-teal-500 hover:bg-teal-50"
                  }`}
                >
                  {tab === "Round Trip" && <ArrowUpDown className="h-4 w-4" />}
                  {tab === "One Way" && <Plane className="h-4 w-4" />}
                  {tab === "Multi City" && <Building className="h-4 w-4" />}
                  {tab === "Hot Deals" && <Flame className="h-4 w-4 text-orange-500" />}
                  {tab}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-4">
              <Select value={travelClass} onValueChange={setTravelClass}>
                <SelectTrigger className="w-32 border-gray-300">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Economy">Economy</SelectItem>
                  <SelectItem value="Premium">Premium</SelectItem>
                  <SelectItem value="Business">Business</SelectItem>
                  <SelectItem value="First">First</SelectItem>
                </SelectContent>
              </Select>

              <Select value={travelers} onValueChange={setTravelers}>
                <SelectTrigger className="w-32 border-gray-300">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1 Traveler">1 Traveler</SelectItem>
                  <SelectItem value="2 Travelers">2 Travelers</SelectItem>
                  <SelectItem value="3 Travelers">3 Travelers</SelectItem>
                  <SelectItem value="4 Travelers">4 Travelers</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Main Search Bar */}
          <div className="bg-white rounded-full border-4 border-teal-400 p-2 shadow-lg">
            <div className="flex items-center">
              {/* From */}
              <div className="flex-1 px-6 py-4 relative">
                <div className="flex items-center gap-3">
                  <Plane className="h-5 w-5 text-gray-400" />
                  <div className="w-full">
                    <div className="text-sm text-gray-500 mb-1">From</div>
                    <button
                      onClick={() => setShowOriginDropdown(!showOriginDropdown)}
                      className="text-left w-full text-lg font-medium text-gray-800 hover:text-teal-600"
                    >
                      {origin || "From"}
                    </button>
                    {showOriginDropdown && (
                      <div className="absolute top-full left-0 mt-2 w-64 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
                        {originCities.map((city) => (
                          <button
                            key={city.code}
                            onClick={() => {
                              setOrigin(city.full)
                              setShowOriginDropdown(false)
                            }}
                            className="w-full text-left px-4 py-3 hover:bg-teal-50 hover:text-teal-600 border-b border-gray-100 last:border-b-0"
                          >
                            <div className="font-medium">{city.name}</div>
                            <div className="text-sm text-gray-500">{city.code}</div>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Swap Button */}
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <ArrowUpDown className="h-5 w-5 text-teal-500" />
              </button>

              {/* To */}
              <div className="flex-1 px-6 py-4 relative">
                <div className="flex items-center gap-3">
                  <Plane className="h-5 w-5 text-gray-400" />
                  <div className="w-full">
                    <div className="text-sm text-gray-500 mb-1">To</div>
                    <button
                      onClick={() => setShowDestinationDropdown(!showDestinationDropdown)}
                      className="text-left w-full text-lg font-medium text-gray-800 hover:text-teal-600"
                    >
                      {destination || "To"}
                    </button>
                    {showDestinationDropdown && (
                      <div className="absolute top-full left-0 mt-2 w-64 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
                        {destinationCities.map((city) => (
                          <button
                            key={city.code}
                            onClick={() => {
                              setDestination(city.full)
                              setShowDestinationDropdown(false)
                            }}
                            className="w-full text-left px-4 py-3 hover:bg-teal-50 hover:text-teal-600 border-b border-gray-100 last:border-b-0"
                          >
                            <div className="font-medium">{city.name}</div>
                            <div className="text-sm text-gray-500">{city.code}</div>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Dates */}
              <div className="flex-1 px-6 py-4">
                <div className="flex items-center gap-3">
                  <CalendarIcon className="h-5 w-5 text-gray-400" />
                  <div>
                    <div className="text-sm text-gray-500 mb-1">Departure Dates</div>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="ghost"
                          className="p-0 h-auto text-lg font-medium text-left justify-start hover:bg-transparent"
                        >
                          {departDate && returnDate
                            ? `${format(departDate, "MMM d, yyyy")} - ${format(returnDate, "MMM d, yyyy")}`
                            : departDate
                              ? format(departDate, "MMM d, yyyy")
                              : "Select dates"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <div className="flex">
                          <Calendar
                            mode="single"
                            selected={departDate}
                            onSelect={setDepartDate}
                            disabled={(date) => date < new Date()}
                            month={new Date()}
                          />
                          {activeTab === "Round Trip" && (
                            <Calendar
                              mode="single"
                              selected={returnDate}
                              onSelect={setReturnDate}
                              disabled={(date) => date < (departDate || new Date())}
                              month={addMonths(new Date(), 1)}
                            />
                          )}
                        </div>
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              </div>

              {/* Search Button */}
              <Button
                onClick={handleSearch}
                className="bg-teal-500 hover:bg-teal-600 text-white rounded-full h-16 w-16 p-0 ml-4"
              >
                <Search className="h-6 w-6" />
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="text-center mb-12">
          <h2 className="text-2xl text-gray-700 mb-8">
            <span className="text-teal-500 font-semibold">Explore the world</span>, earn rewards, and unlock endless
            possibilities with <span className="text-teal-500 font-semibold">Trilla</span>!
          </h2>
        </div>

        {/* Destination Cards - Now Clickable */}
        <div className="grid grid-cols-5 gap-6">
          {destinations.map((destination, index) => (
            <Link key={destination.name} href={`/deals/${destination.slug}`}>
              <div className="text-center cursor-pointer group">
                <div className="relative h-48 w-full rounded-2xl overflow-hidden mb-4 shadow-lg group-hover:shadow-xl transition-shadow">
                  <Image
                    src={destination.image || "/placeholder.svg"}
                    alt={destination.name}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300 flex items-center justify-center">
                    <div className="text-white font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
                      View Hot Deals
                    </div>
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-gray-800 group-hover:text-teal-600 transition-colors">
                  {destination.name}
                </h3>
              </div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  )
}
